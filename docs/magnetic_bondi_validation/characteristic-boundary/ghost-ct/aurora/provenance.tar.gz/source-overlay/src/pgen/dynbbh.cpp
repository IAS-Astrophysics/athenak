#include <stdio.h>
#include <math.h>

#if MPI_PARALLEL_ENABLED
#include <mpi.h>
#endif

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "athena.hpp"
#include "parameter_input.hpp"
#include "mesh/mesh.hpp"
#include "coordinates/adm.hpp"
#include "coordinates/coordinates.hpp"
#include "coordinates/cartesian_ks.hpp"
#include "coordinates/cell_locations.hpp"
#include "eos/eos.hpp"
#include "hydro/hydro.hpp"
#include "mhd/mhd.hpp"
#include "diffusion/current_density.hpp"
#include "dyn_grmhd/dyn_grmhd.hpp"
#include "cyclic_zoom/cyclic_zoom.hpp"
#include "dyn_radiation/dyn_radiation.hpp"
#include "utils/flux_generalized.hpp"
#include "units/units.hpp"
#include "srcterms/ismcooling.hpp"
#include "pgen/bondi_profile.hpp"



#include <Kokkos_Random.hpp>


namespace {

enum {
  TT, XX, YY, ZZ, NDIM
};

enum {
  X1, Y1, Z1, X2, Y2, Z2,
  VX1, VY1, VZ1, VX2, VY2, VZ2,
  AX1, AY1, AZ1, AX2, AY2, AZ2,
  M1T, M2T, NTRAJ
};

constexpr Real metric_fd_step = 5.0e-5;

struct dd_sym {
  Real tt;
  Real tx;
  Real ty;
  Real tz;
  Real xx;
  Real xy;
  Real xz;
  Real yy;
  Real yz;
  Real zz;
};

struct four_metric {
  struct dd_sym g;
  struct dd_sym g_t;
  struct dd_sym g_x;
  struct dd_sym g_y;
  struct dd_sym g_z;
};

KOKKOS_INLINE_FUNCTION Real metric_sqrt(Real a) { return sqrt(a); }
KOKKOS_INLINE_FUNCTION Real value_of(Real a) { return a; }

struct dual1_real {
  Real val, d;
  KOKKOS_INLINE_FUNCTION dual1_real() : val(0.0), d(0.0) {}
  KOKKOS_INLINE_FUNCTION dual1_real(Real v) : val(v), d(0.0) {}
  KOKKOS_INLINE_FUNCTION dual1_real(Real v, Real deriv) : val(v), d(deriv) {}
};
KOKKOS_INLINE_FUNCTION dual1_real operator+(const dual1_real &a,
                                            const dual1_real &b) {
  return dual1_real(a.val + b.val, a.d + b.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator+(const dual1_real &a, Real b) {
  return dual1_real(a.val + b, a.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator+(Real a, const dual1_real &b) {
  return b + a;
}
KOKKOS_INLINE_FUNCTION dual1_real operator-(const dual1_real &a,
                                            const dual1_real &b) {
  return dual1_real(a.val - b.val, a.d - b.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator-(const dual1_real &a, Real b) {
  return dual1_real(a.val - b, a.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator-(Real a, const dual1_real &b) {
  return dual1_real(a - b.val, -b.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator-(const dual1_real &a) {
  return dual1_real(-a.val, -a.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator*(const dual1_real &a,
                                            const dual1_real &b) {
  return dual1_real(a.val * b.val, a.d * b.val + a.val * b.d);
}
KOKKOS_INLINE_FUNCTION dual1_real operator*(const dual1_real &a, Real b) {
  return dual1_real(a.val * b, a.d * b);
}
KOKKOS_INLINE_FUNCTION dual1_real operator*(Real a, const dual1_real &b) {
  return b * a;
}
KOKKOS_INLINE_FUNCTION dual1_real operator/(const dual1_real &a,
                                            const dual1_real &b) {
  const Real inv = 1.0 / b.val;
  return dual1_real(a.val * inv, (a.d * b.val - a.val * b.d) * inv * inv);
}
KOKKOS_INLINE_FUNCTION dual1_real operator/(const dual1_real &a, Real b) {
  const Real inv = 1.0 / b;
  return dual1_real(a.val * inv, a.d * inv);
}
KOKKOS_INLINE_FUNCTION dual1_real operator/(Real a, const dual1_real &b) {
  const Real inv = 1.0 / b.val;
  return dual1_real(a * inv, -a * b.d * inv * inv);
}
KOKKOS_INLINE_FUNCTION dual1_real metric_sqrt(const dual1_real &a) {
  const Real s = sqrt(a.val);
  return dual1_real(s, 0.5 * a.d / s);
}
KOKKOS_INLINE_FUNCTION Real value_of(const dual1_real &a) { return a.val; }
KOKKOS_INLINE_FUNCTION Real deriv_of(const dual1_real &a) { return a.d; }

template <typename T>
KOKKOS_INLINE_FUNCTION T metric_norm3(T x, T y, T z) {
  T r2 = x * x + y * y + z * z;
  if (value_of(r2) <= 0.0) {
    return T(0.0);
  }
  return metric_sqrt(r2);
}

struct three_metric {
  Real gxx;
  Real gxy;
  Real gxz;
  Real gyy;
  Real gyz;
  Real gzz;
  Real alpha;
  Real betax;
  Real betay;
  Real betaz;
  Real kxx;
  Real kxy;
  Real kxz;
  Real kyy;
  Real kyz;
  Real kzz;
};

struct bbh_traj_state {
  Real q[NTRAJ];
  Real dq[NTRAJ];
};

enum class MetricDerivativeMethod {
  ad,
  finite_difference
};

enum class CoolingSource {
  none,
  ism,
  thin_disk
};

struct bbh_pgen {
  Real sep;
  Real om;
  Real frame_omega;
  Real q;
  Real a1, a2;
  Real th_a1, th_a2;
  Real ph_a1, ph_a2;
  Real spin_ramp_timescale;
  Real spin_ramp_start_time;
  Real d;
  Real gamma_adi;
  Real a1_buffer, a2_buffer;
  Real cutoff_floor;
  Real metric_fd_step;
  Real alpha_thr;
  Real radius_thr;
  Real smooth_b_damping_eta;
  Real smooth_b_damping_cfl;
  Real restart_precondition_radius;
  Real restart_precondition_rho_floor;
  Real restart_precondition_temp_floor;
  Real restart_precondition_temp_ceil;
  Real restart_precondition_sigma_max;
  Real restart_precondition_velocity_max;
  Real puncture_excise_rad1;
  Real puncture_excise_rad2;
  Real puncture_excise_shrink_timescale;
  Real puncture_excise_shrink_start_time;
  Real thin_cooling_h_over_r;
  Real thin_cooling_timescale_orbits;
  Real thin_cooling_cfl;
  Real thin_cooling_r_inner;
  Real thin_cooling_r_outer;
  bool corotating;
  bool single_black_hole;
  bool use_traj_table;
  bool spin_ramp;
  bool smooth_b_damping;
  bool restart_precondition_mhd;
  bool restart_precondition_verbose;
  bool puncture_excise_cap_to_horizon;
  bool puncture_excise_to_horizon;
  bool puncture_excise_shrink_to_horizon;
  bool require_resolved_horizon;
  CoolingSource cooling_source;
  MetricDerivativeMethod metric_derivative_method;

  Real spin;

  Real dexcise, pexcise;                      // excision parameters
  Real arad;                                  // radiation constant
  Real restart_seed_erad_fraction;            // multiplier for old GRMHD restart rad seed
  Real r_edge, r_peak, l, rho_max;            // fixed torus parameters
  Real l_peak;                                // fixed torus parameters
  Real c_param;                               // calculated chakrabarti parameter
  Real n_param;                               // fixed or calculated chakrabarti parameter
  Real log_h_edge, log_h_peak;                // calculated torus parameters
  Real ptot_over_rho_peak, rho_peak;          // more calculated torus parameters
  Real r_outer_edge;                          // even more calculated torus parameters
  Real psi, sin_psi, cos_psi;                 // tilt parameters
  Real rho_min, rho_pow, pgas_min, pgas_pow;  // background parameters
  bool is_vertical_field;                     // use vertical field configuration
  Real potential_cutoff, potential_falloff;   // sets region of torus to magnetize
  Real potential_r_pow;                       // set how vector potential scales
  Real potential_beta_min;                    // set how vector potential scales (cont.)
  Real potential_rho_pow;                     // set vector potential dependence on rho
};

// a separate struc for refinement method, etc.
struct bbh_refine {
  bool AlphaMin = false;
  bool Tracker = false;
  Real tracker_radius[2] = {0.0, 0.0};
  int tracker_reflevel[2] = {-1, -1};
  std::vector<Real> radius;
  std::vector<int> reflevel;
};

struct bbh_pgen bbh;
struct bbh_refine bbh_ref;
struct bbh_traj_table {
  std::vector<Real> t;
  std::vector<Real> x1, y1, z1, x2, y2, z2;
  std::vector<Real> vx1, vy1, vz1, vx2, vy2, vz2;
  std::vector<Real> ax1, ay1, az1, ax2, ay2, az2;
  std::vector<Real> m1, m2;
  std::size_t active_segment = 0;
};
struct bbh_traj_table bbh_table;

bool SpinVectorWithinExtremality(Real chix, Real chiy, Real chiz) {
  Real chi2 = SQR(chix) + SQR(chiy) + SQR(chiz);
  return std::isfinite(chi2) && chi2 <= 1.0;
}

bool SpinMagnitudeWithinExtremality(Real chi) {
  return std::isfinite(chi) && chi >= 0.0 && SQR(chi) <= 1.0;
}

void find_traj_t(Real tt, Real traj_array[NTRAJ]);
void find_traj_t_with_deriv(Real tt, Real traj_array[NTRAJ],
                            Real dtraj_array[NTRAJ]);

Real LocalFinestMeshSpacing(MeshBlockPack *pmbp) {
  Real min_dx = std::numeric_limits<Real>::max();
  auto &mb_size = pmbp->pmb->mb_size;
  auto &indcs = pmbp->pmesh->mb_indcs;
  for (int m = 0; m < pmbp->nmb_thispack; ++m) {
    min_dx = std::min(min_dx, mb_size.h_view(m).dx1);
    if (indcs.nx2 > 1) min_dx = std::min(min_dx, mb_size.h_view(m).dx2);
    if (indcs.nx3 > 1) min_dx = std::min(min_dx, mb_size.h_view(m).dx3);
  }
#if MPI_PARALLEL_ENABLED
  MPI_Allreduce(MPI_IN_PLACE, &min_dx, 1, MPI_ATHENA_REAL, MPI_MIN, MPI_COMM_WORLD);
#endif
  return min_dx;
}

Real LocalMeshSpacingAtPoint(MeshBlockPack *pmbp, Real x, Real y, Real z) {
  Real local_dx = std::numeric_limits<Real>::max();
  auto &mb_size = pmbp->pmb->mb_size;
  auto &indcs = pmbp->pmesh->mb_indcs;
  for (int m = 0; m < pmbp->nmb_thispack; ++m) {
    auto mb = mb_size.h_view(m);
    Real eps1 = 16.0*std::numeric_limits<Real>::epsilon()*
                std::max({1.0, std::abs(mb.x1min), std::abs(mb.x1max)});
    Real eps2 = 16.0*std::numeric_limits<Real>::epsilon()*
                std::max({1.0, std::abs(mb.x2min), std::abs(mb.x2max)});
    Real eps3 = 16.0*std::numeric_limits<Real>::epsilon()*
                std::max({1.0, std::abs(mb.x3min), std::abs(mb.x3max)});
    bool contains = (x >= mb.x1min - eps1 && x <= mb.x1max + eps1);
    if (indcs.nx2 > 1) contains = contains &&
        (y >= mb.x2min - eps2 && y <= mb.x2max + eps2);
    if (indcs.nx3 > 1) contains = contains &&
        (z >= mb.x3min - eps3 && z <= mb.x3max + eps3);
    if (contains) {
      Real dx = mb.dx1;
      if (indcs.nx2 > 1) dx = std::max(dx, mb.dx2);
      if (indcs.nx3 > 1) dx = std::max(dx, mb.dx3);
      local_dx = std::min(local_dx, dx);
    }
  }
#if MPI_PARALLEL_ENABLED
  MPI_Allreduce(MPI_IN_PLACE, &local_dx, 1, MPI_ATHENA_REAL, MPI_MIN, MPI_COMM_WORLD);
#endif
  if (local_dx == std::numeric_limits<Real>::max()) {
    local_dx = LocalFinestMeshSpacing(pmbp);
  }
  return local_dx;
}

Real HorizonRadiusFromMassAndChi(Real mass, Real chix, Real chiy, Real chiz) {
  Real chi2 = SQR(chix) + SQR(chiy) + SQR(chiz);
  return mass * (1.0 + std::sqrt(std::max(1.0 - chi2, 0.0)));
}

Real SmoothExcisionRadiusToHorizon(const Real requested_radius,
                                   const Real horizon_radius,
                                   const Real time,
                                   const Real timescale,
                                   const bool set_to_horizon,
                                   const bool shrink_to_horizon) {
  Real start_radius = (requested_radius > 0.0) ? requested_radius : horizon_radius;
  if (set_to_horizon) return horizon_radius;
  if (!shrink_to_horizon) return start_radius;
  start_radius = std::max(start_radius, horizon_radius);
  if (!(timescale > 0.0)) return horizon_radius;
  Real f = std::min(std::max(time/timescale, 0.0), 1.0);
  f = f*f*(3.0 - 2.0*f);
  return (1.0 - f)*start_radius + f*horizon_radius;
}

Real SmoothRamp01(const Real time, const Real start_time, const Real timescale,
                  Real *dfdt) {
  *dfdt = 0.0;
  if (!(timescale > 0.0)) return (time >= start_time) ? 1.0 : 0.0;
  Real u = (time - start_time) / timescale;
  if (u <= 0.0) return 0.0;
  if (u >= 1.0) return 1.0;
  *dfdt = 6.0*u*(1.0 - u) / timescale;
  return u*u*(3.0 - 2.0*u);
}

Real MinDynBBHHorizonRadius() {
  if (bbh.single_black_hole) return 2.0;
  if (bbh.use_traj_table && !bbh_table.t.empty()) {
    Real rmin = std::numeric_limits<Real>::max();
    for (std::size_t n = 0; n < bbh_table.t.size(); ++n) {
      Real m1 = bbh_table.m1[n];
      Real m2 = bbh_table.m2[n];
      rmin = std::min(rmin, HorizonRadiusFromMassAndChi(
          m1, bbh_table.ax1[n], bbh_table.ay1[n], bbh_table.az1[n]));
      rmin = std::min(rmin, HorizonRadiusFromMassAndChi(
          m2, bbh_table.ax2[n], bbh_table.ay2[n], bbh_table.az2[n]));
    }
    return rmin;
  }
  Real state[NTRAJ];
  find_traj_t(0.0, state);
  Real m1 = state[M1T];
  Real m2 = state[M2T];
  return std::min(
      HorizonRadiusFromMassAndChi(m1, state[AX1], state[AY1], state[AZ1]),
      HorizonRadiusFromMassAndChi(m2, state[AX2], state[AY2], state[AZ2]));
}

void CheckPunctureExcisionResolution(MeshBlockPack *pmbp, const bbh_traj_state &traj,
                                     const Real r0, const Real r1,
                                     const char *context) {
  constexpr Real min_cells_across = 10.0;
  Real dx0 = LocalMeshSpacingAtPoint(pmbp, traj.q[X1], traj.q[Y1], traj.q[Z1]);
  Real dx1 = LocalMeshSpacingAtPoint(pmbp, traj.q[X2], traj.q[Y2], traj.q[Z2]);
  Real cells0 = (r0 > 0.0) ? 2.0*r0/std::max(dx0, 1.0e-300) : 0.0;
  Real cells1 = bbh.single_black_hole ? min_cells_across :
      ((r1 > 0.0) ? 2.0*r1/std::max(dx1, 1.0e-300) : 0.0);
  if ((cells0 < min_cells_across || cells1 < min_cells_across) &&
      global_variable::my_rank == 0) {
    std::cout << "WARNING: puncture excision radius is under-resolved during "
              << context << ": cells across excision diameter are "
              << "hole1=" << cells0 << " (r=" << r0 << ", dx=" << dx0 << "), "
              << "hole2=" << cells1 << " (r=" << r1 << ", dx=" << dx1 << "); "
              << "recommended minimum is " << min_cells_across << std::endl;
  }
}

/* Declare functions */
void find_traj_t(Real tt, Real traj_array[NTRAJ]);
void find_traj_t_with_deriv(Real tt, Real traj_array[NTRAJ],
                            Real dtraj_array[NTRAJ]);
bbh_traj_state find_traj_state(Real tt);
void LoadTrajectoryTable(const std::string &fname);

int four_metric_to_three_metric(const struct four_metric &met,
                                struct three_metric &gam);
KOKKOS_INLINE_FUNCTION
void get_metric(const Real t, const Real x, const Real y, const Real z,
                struct four_metric &met, const Real bbh_traj_loc[NTRAJ],
                const bbh_pgen bbh_);
KOKKOS_INLINE_FUNCTION
void numerical_4metric(const Real t, const Real x, const Real y,
                       const Real z, struct four_metric &outmet,
                       const Real traj_m[NTRAJ], const Real traj_0[NTRAJ],
                       const Real traj_p[NTRAJ], const Real hm, const Real hp,
                       const bbh_pgen bbh_);
KOKKOS_INLINE_FUNCTION
void get_metric_and_derivatives(const Real t, const Real x, const Real y,
                                const Real z, struct four_metric &met,
                                const Real bbh_traj_loc[NTRAJ],
                                const Real dtraj_array[NTRAJ],
                                const bbh_pgen bbh_);
KOKKOS_INLINE_FUNCTION
void SuperposedBBH(const Real time, const Real x, const Real y, const Real z,
                   Real gcov[][NDIM], const Real traj_array[NTRAJ],
                   const bbh_pgen bbh_);
void SetADMVariablesToBBH(MeshBlockPack *pmbp);
void InitializeBinaryReservoir(Mesh *pm, ParameterInput *pin, bool restart);
void BinaryReservoirBoundary(Mesh *pm);
Real reservoir_density, reservoir_pressure, reservoir_bz;
bool use_bondi_inflow = false;
bool reservoir_test_flat_metric = false;
bool cache_bondi_boundary = true;
Real reservoir_perturbation = 0.0;
std::uint64_t bondi_metric_revision = 0;
struct BondiBoundaryCache {
  DvceArray5D<Real> primitive;
  std::uint64_t revision = 0;
};
bondi_profile::Solution inflow_solution;
void RefineAlphaMin(MeshBlockPack* pmbp);
void RefineTracker(MeshBlockPack* pmbp);
void RefineRadii(MeshBlockPack* pmbp);
void Refine(MeshBlockPack* pmbp);
void AddValenciaGRCooling(Mesh *pm, const Real bdt);
void AddThinDiskCooling(Mesh *pm, const Real bdt);
void AddDynBBHUserSources(Mesh *pm, const Real bdt);
void AddSmoothExcisionMagneticDamping(Mesh *pm, DvceEdgeFld4D<Real> &efld);
void InitializeDynBBHPreRestart(Mesh *pm);
void InitializeDynBBHPostRestart(Mesh *pm);
void PreconditionDynBBHRestartMHD(Mesh *pm);

//----------------------------------------------------------------------------------------
//! \fn void TorusHistory(HistoryData *pdata, Mesh *pm)
//! \brief User history function that centers horizon grids and calls flux integrator.
//----------------------------------------------------------------------------------------
void TorusHistory(HistoryData *pdata, Mesh *pm) {
    ProblemGenerator *pgen = pm->pgen.get();
    if (pgen->surface_grids.empty()) {
        pdata->nhist = 0;
        return;
    }
    MeshBlockPack *pmbp = pm->pmb_pack;

    // 1. Calculate current Black Hole Trajectory
    Real tt = bbh.corotating ? 0.0 : pm->time;
    Real btraj[NTRAJ];

    // Ensure find_traj_t is visible here (it is declared global in your snippet)
    find_traj_t(tt, btraj);

    // 2. Update Surface Grid Centers
    // We iterate through all grids and check labels to see if they are horizons
    for(auto& grid_ptr : pgen->surface_grids) {
        if (grid_ptr->Label() == "H1") {
            // Move grid to BH1 location (Indices 0, 1, 2)
            grid_ptr->SetCenter(&btraj[0]);
        }
        else if (grid_ptr->Label() == "H2") {
            // Move grid to BH2 location (Indices 3, 4, 5)
            grid_ptr->SetCenter(&btraj[3]);
        }
    }

    // 3. Prepare pointers for the flux calculator
    std::vector<SphericalSurfaceGrid*> surf_raw_ptrs;
    surf_raw_ptrs.reserve(pgen->surface_grids.size());
    for(const auto& s : pgen->surface_grids) {
        surf_raw_ptrs.push_back(s.get());
    }

    // 4. Calculate fluxes
    TorusFluxes_General(pdata, pmbp, surf_raw_ptrs);
}


KOKKOS_INLINE_FUNCTION
static void GetSuperposedAndInverse(const Real t,
                            const Real x, const Real y, const Real z,
                            Real gcov[][NDIM], Real gcon[][NDIM], const Real bbh_traj_loc[NTRAJ],
                            const bbh_pgen bbh_);



KOKKOS_INLINE_FUNCTION
static void CalculateCN(struct bbh_pgen pgen, Real *cparam, Real *nparam);

KOKKOS_INLINE_FUNCTION
static Real CalculateL(struct bbh_pgen pgen, Real r, Real sin_theta);

KOKKOS_INLINE_FUNCTION
static Real CalculateCovariantUT(struct bbh_pgen pgen, Real r, Real sin_theta, Real l);

KOKKOS_INLINE_FUNCTION
static Real LogHAux(struct bbh_pgen pgen, Real r, Real sin_theta);

KOKKOS_INLINE_FUNCTION
static Real CalculateT(struct bbh_pgen pgen, Real rho, Real ptot_over_rho);

KOKKOS_INLINE_FUNCTION
static Real LogHAux(struct bbh_pgen pgen, Real r, Real sin_theta);

KOKKOS_INLINE_FUNCTION
static void CalculateVelocityInTiltedTorus(struct bbh_pgen pgen,
                                           Real r, Real theta, Real phi, Real *pu0,
                                           Real *pu1, Real *pu2, Real *pu3);
KOKKOS_INLINE_FUNCTION
static void CalculateVelocityInTorus(struct bbh_pgen pgen,
                                     Real r, Real sin_theta, Real *pu0, Real *pu3);

KOKKOS_INLINE_FUNCTION
static void TransformVector(struct bbh_pgen pgen,
                            Real a0_bl, Real a1_bl, Real a2_bl, Real a3_bl,
                            Real x1, Real x2, Real x3,
                            Real *pa0, Real *pa1, Real *pa2, Real *pa3);

KOKKOS_INLINE_FUNCTION
static void CalculateVectorPotentialInTiltedTorus(struct bbh_pgen pgen,
                                                  Real r, Real theta, Real phi,
                                                  Real *patheta, Real *paphi);


KOKKOS_INLINE_FUNCTION
static void GetBoyerLindquistCoordinates(struct bbh_pgen pgen,
                                         Real x1, Real x2, Real x3,
                                         Real *pr, Real *ptheta, Real *pphi);

KOKKOS_INLINE_FUNCTION
static void InvertMetric(Real gcov[][NDIM], Real gcon[][NDIM]);

KOKKOS_INLINE_FUNCTION
Real A1(struct bbh_pgen pgen, Real x1, Real x2, Real x3);
KOKKOS_INLINE_FUNCTION
Real A2(struct bbh_pgen pgen, Real x1, Real x2, Real x3);
KOKKOS_INLINE_FUNCTION
Real A3(struct bbh_pgen pgen, Real x1, Real x2, Real x3);

void InitializeDynBBHRestartDynRadiation(Mesh *pm);
} // namespace

//----------------------------------------------------------------------------------------
//! \fn ProblemGenerator::ShockTube_()
//! \brief Problem Generator for the shock tube (Riemann problem) tests

void ProblemGenerator::UserProblem(ParameterInput *pin, const bool restart) {
  // Keep the upstream/Minghao hydro control available in this same executable.
  if (pin->DoesParameterExist("problem","pgen_name") &&
      pin->GetString("problem","pgen_name") == "gr_bondi") {
    BondiAccretion(pin,restart);
    return;
  }

  MeshBlockPack *pmbp = pmy_mesh_->pmb_pack;
  if (!pmbp->pcoord->is_general_relativistic &&
      !pmbp->pcoord->is_dynamical_relativistic) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "BBH problem can only be run when GR defined in <coord> block"
              << std::endl;
    exit(EXIT_FAILURE);
  }

  bbh.spin = 0.0;

  bbh.corotating = pin->GetOrAddBoolean("problem", "corotating", false);
  bbh.single_black_hole = pin->GetOrAddBoolean("problem", "single_black_hole", false);
  reservoir_test_flat_metric=pin->GetOrAddBoolean("problem","reservoir_test_flat_metric",false);
  if(reservoir_test_flat_metric && (pmy_mesh_->pzoom!=nullptr || pmbp->pz4c!=nullptr || pin->GetOrAddBoolean("coord","excise",true)))
    Kokkos::abort("Flat reservoir validation requires no zoom, no Z4c and excise=false");
  bbh.sep = pin->GetOrAddReal("problem", "sep", 25.0);
  bbh.om = std::pow(bbh.sep, -1.5);
  bbh.frame_omega = pin->GetOrAddReal("problem", "frame_omega",
                                    bbh.corotating ? bbh.om : 0.0);
  if (!std::isfinite(bbh.frame_omega) ||
      (!bbh.corotating && bbh.frame_omega != 0.0) ||
      (bbh.corotating && !bbh.single_black_hole &&
       fabs(bbh.frame_omega-bbh.om) > 1.0e-12*bbh.om)) {
    Kokkos::abort("Invalid frame_omega: stationary binary requires orbital frequency");
  }
  bbh.q = pin->GetOrAddReal("problem", "q", 1.0);
  bbh.a1 = pin->GetOrAddReal("problem", "a1", 0.0);
  bbh.a2 = pin->GetOrAddReal("problem", "a2", 0.0);
  bbh.th_a1 = pin->GetOrAddReal("problem", "th_a1", 0.0) * (M_PI/180.0);
  bbh.th_a2 = pin->GetOrAddReal("problem", "th_a2", 0.0) * (M_PI/180.0);
  bbh.ph_a1 = pin->GetOrAddReal("problem", "ph_a1", 0.0) * (M_PI/180.0);
  bbh.ph_a2 = pin->GetOrAddReal("problem", "ph_a2", 0.0) * (M_PI/180.0);
  bbh.spin_ramp = pin->GetOrAddBoolean("problem", "spin_ramp", false);
  bbh.spin_ramp_timescale = pin->GetOrAddReal(
      "problem", "spin_ramp_timescale", 50.0);
  bbh.spin_ramp_start_time = pin->GetOrAddReal(
      "problem", "spin_ramp_start_time", pmbp->pmesh->time);
  bbh.d = pin->GetOrAddReal("problem", "duniform", 1.0);
  bbh.gamma_adi = pin->GetOrAddReal("problem", "gamma_adi", 1.6666666);
  if (!SpinMagnitudeWithinExtremality(bbh.a1) ||
      !SpinMagnitudeWithinExtremality(bbh.a2)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "Dimensionless spin magnitudes problem/a1 and problem/a2 "
              << "must satisfy 0 <= chi <= 1"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (bbh.spin_ramp && (!(bbh.spin_ramp_timescale > 0.0) ||
                        !std::isfinite(bbh.spin_ramp_start_time))) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "problem/spin_ramp requires positive spin_ramp_timescale "
              << "and finite spin_ramp_start_time" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.a1_buffer = pin->GetOrAddReal("problem", "a1_buffer", 0.01);
  bbh.a2_buffer = pin->GetOrAddReal("problem", "a2_buffer", 0.01);
  bbh.cutoff_floor = pin->GetOrAddReal("problem", "cutoff_floor", 1e-4);
  bbh.metric_fd_step = pin->GetOrAddReal("problem", "metric_fd_step", metric_fd_step);
  if (!(bbh.metric_fd_step > 0.0)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "problem/metric_fd_step must be positive" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  std::string metric_derivative = pin->GetOrAddString(
      "problem", "metric_derivative", "ad");
  if (metric_derivative == "ad") {
    bbh.metric_derivative_method = MetricDerivativeMethod::ad;
  } else if (metric_derivative == "finite_difference" || metric_derivative == "fd") {
    bbh.metric_derivative_method = MetricDerivativeMethod::finite_difference;
  } else {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "Unknown problem/metric_derivative='" << metric_derivative
              << "'. Use 'ad' or 'finite_difference'." << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.alpha_thr = pin->GetOrAddReal("problem", "alpha_thr", 0.2);
  bbh.radius_thr = pin->GetOrAddReal("problem", "radius_thr", 2.);
  int tracker_reflevel = pin->GetOrAddInteger("problem", "tracker_reflevel", -1);
  bbh_ref.tracker_radius[0] = pin->GetOrAddReal("problem", "tracker_1_rad",
                                                bbh.radius_thr);
  bbh_ref.tracker_radius[1] = pin->GetOrAddReal("problem", "tracker_2_rad",
                                                bbh.radius_thr);
  bbh_ref.tracker_reflevel[0] = pin->GetOrAddInteger(
      "problem", "tracker_1_reflevel", tracker_reflevel);
  bbh_ref.tracker_reflevel[1] = pin->GetOrAddInteger(
      "problem", "tracker_2_reflevel", tracker_reflevel);
  if (!(bbh_ref.tracker_radius[0] > 0.0) || !(bbh_ref.tracker_radius[1] > 0.0) ||
      bbh_ref.tracker_reflevel[0] < -1 || bbh_ref.tracker_reflevel[1] < -1) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "tracker radii must be positive and tracker reflevels must be >= -1"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (user_srcs) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "dynbbh cooling is selected with problem/cooling_source; "
              << "use cooling_source=ism instead of problem/user_srcs=true"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (pin->DoesParameterExist("problem", "thin_disk_cooling")) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "problem/thin_disk_cooling is deprecated for dynbbh; use "
              << "problem/cooling_source=thin_disk instead" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  std::string cooling_source = pin->GetOrAddString(
      "problem", "cooling_source", "none");
  if (cooling_source == "none") {
    bbh.cooling_source = CoolingSource::none;
  } else if (cooling_source == "ism") {
    bbh.cooling_source = CoolingSource::ism;
  } else if (cooling_source == "thin_disk") {
    bbh.cooling_source = CoolingSource::thin_disk;
  } else {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "Unknown problem/cooling_source='" << cooling_source
              << "'. Use 'none', 'ism', or 'thin_disk'." << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.smooth_b_damping = pin->GetOrAddBoolean(
      "coord", "smooth_excision_b_damping", false);
  bbh.smooth_b_damping_eta = pin->GetOrAddReal(
      "coord", "smooth_excision_b_damping_eta", 0.0);
  bbh.smooth_b_damping_cfl = pin->GetOrAddReal(
      "coord", "smooth_excision_b_damping_cfl", 0.25);
  if (bbh.smooth_b_damping &&
      (!(bbh.smooth_b_damping_eta > 0.0) || bbh.smooth_b_damping_cfl < 0.0)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "smooth_excision_b_damping requires positive eta and "
              << "non-negative cfl cap" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.restart_precondition_mhd = pin->GetOrAddBoolean(
      "problem", "restart_precondition_mhd", false);
  bbh.restart_precondition_radius = pin->GetOrAddReal(
      "problem", "restart_precondition_radius", 0.0);
  bbh.restart_precondition_rho_floor = pin->GetOrAddReal(
      "problem", "restart_precondition_rho_floor", 0.0);
  bbh.restart_precondition_temp_floor = pin->GetOrAddReal(
      "problem", "restart_precondition_temp_floor", 0.0);
  bbh.restart_precondition_temp_ceil = pin->GetOrAddReal(
      "problem", "restart_precondition_temp_ceil", 0.0);
  bbh.restart_precondition_sigma_max = pin->GetOrAddReal(
      "problem", "restart_precondition_sigma_max", 0.0);
  bbh.restart_precondition_velocity_max = pin->GetOrAddReal(
      "problem", "restart_precondition_velocity_max", 0.0);
  bbh.restart_precondition_verbose = pin->GetOrAddBoolean(
      "problem", "restart_precondition_verbose", true);
  if (bbh.restart_precondition_mhd) {
    if (!(bbh.restart_precondition_radius > 0.0) ||
        !(bbh.restart_precondition_rho_floor > 0.0) ||
        bbh.restart_precondition_temp_floor < 0.0 ||
        bbh.restart_precondition_temp_ceil < 0.0 ||
        bbh.restart_precondition_sigma_max < 0.0 ||
        bbh.restart_precondition_velocity_max < 0.0 ||
        !std::isfinite(bbh.restart_precondition_radius) ||
        !std::isfinite(bbh.restart_precondition_rho_floor) ||
        !std::isfinite(bbh.restart_precondition_temp_floor) ||
        !std::isfinite(bbh.restart_precondition_temp_ceil) ||
        !std::isfinite(bbh.restart_precondition_sigma_max) ||
        !std::isfinite(bbh.restart_precondition_velocity_max)) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "problem/restart_precondition_mhd requires positive finite "
                << "restart_precondition_radius and restart_precondition_rho_floor, "
                << "and non-negative finite temperature/sigma/velocity controls"
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
    if (bbh.restart_precondition_temp_ceil > 0.0 &&
        bbh.restart_precondition_temp_floor > bbh.restart_precondition_temp_ceil) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "restart_precondition_temp_floor must not exceed "
                << "restart_precondition_temp_ceil" << std::endl;
      std::exit(EXIT_FAILURE);
    }
    if (restart && (pmbp->pmhd == nullptr || pmbp->pdyngr == nullptr ||
                    pmbp->padm == nullptr)) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "problem/restart_precondition_mhd requires MHD, Valencia GRMHD, "
                << "and ADM variables on restart" << std::endl;
      std::exit(EXIT_FAILURE);
    }
  }
  bbh.require_resolved_horizon = pin->GetOrAddBoolean(
      "coord", "require_resolved_horizon", false);
  bbh.puncture_excise_rad1 = pin->GetOrAddReal("coord", "excise_1_rad", -1.0);
  bbh.puncture_excise_rad2 = pin->GetOrAddReal("coord", "excise_2_rad", -1.0);
  bbh.puncture_excise_cap_to_horizon = pin->GetOrAddBoolean(
      "coord", "excise_cap_to_horizon", false);
  bbh.puncture_excise_to_horizon = pin->GetOrAddBoolean(
      "coord", "excise_to_horizon", false);
  bbh.puncture_excise_shrink_to_horizon = pin->GetOrAddBoolean(
      "coord", "excise_shrink_to_horizon", false);
  bbh.puncture_excise_shrink_timescale = pin->GetOrAddReal(
      "coord", "excise_shrink_timescale", 50.0);
  bbh.puncture_excise_shrink_start_time = pmbp->pmesh->time;
  if (bbh.puncture_excise_shrink_to_horizon &&
      !(bbh.puncture_excise_shrink_timescale > 0.0)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "excise_shrink_to_horizon requires positive "
              << "coord/excise_shrink_timescale" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.thin_cooling_h_over_r = pin->GetOrAddReal(
      "problem", "thin_cooling_h_over_r", 0.03);
  bbh.thin_cooling_timescale_orbits = pin->GetOrAddReal(
      "problem", "thin_cooling_timescale_orbits", 1.0);
  bbh.thin_cooling_cfl = pin->GetOrAddReal("problem", "thin_cooling_cfl", 0.5);
  bbh.thin_cooling_r_inner = pin->GetOrAddReal(
      "problem", "thin_cooling_r_inner", 0.0);
  bbh.thin_cooling_r_outer = pin->GetOrAddReal(
      "problem", "thin_cooling_r_outer", std::numeric_limits<Real>::max());
  if (bbh.cooling_source == CoolingSource::thin_disk &&
      (!(bbh.thin_cooling_h_over_r > 0.0) ||
       !(bbh.thin_cooling_timescale_orbits > 0.0) ||
       bbh.thin_cooling_cfl < 0.0 ||
       bbh.thin_cooling_r_inner < 0.0 ||
       !(bbh.thin_cooling_r_outer > bbh.thin_cooling_r_inner))) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "cooling_source=thin_disk requires positive thin_cooling_h_over_r "
              << "and thin_cooling_timescale_orbits, non-negative "
              << "thin_cooling_cfl and thin_cooling_r_inner, and "
              << "thin_cooling_r_outer > thin_cooling_r_inner" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh.use_traj_table = pin->GetOrAddBoolean("problem", "use_traj_table", false);
  std::string traj_file = pin->GetOrAddString("problem", "traj_file", "");
  if (bbh.use_traj_table && bbh.spin_ramp) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "problem/spin_ramp only applies to the analytic circular "
              << "orbit path; encode time-dependent spins in traj_file when "
              << "use_traj_table=true" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (bbh.use_traj_table) {
    if (traj_file.empty()) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "use_traj_table=true requires traj_file" << std::endl;
      std::exit(EXIT_FAILURE);
    }
    LoadTrajectoryTable(traj_file);
    Real tlim = pin->GetReal("time", "tlim");
    Real tfinal = bbh_table.t.back();
    Real tol = 64.0*std::numeric_limits<Real>::epsilon()*
               std::max({1.0, std::abs(tlim), std::abs(tfinal)});
    if (tlim > tfinal + tol) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "time/tlim=" << tlim
                << " exceeds final trajectory-table time=" << tfinal
                << " from traj_file='" << traj_file << "'" << std::endl
                << "Extend the trajectory table or reduce time/tlim." << std::endl;
      std::exit(EXIT_FAILURE);
    }
  }

  auto &coord_data = pmbp->pcoord->coord_data;
  if (coord_data.bh_excise && coord_data.excision_scheme == ExcisionScheme::puncture &&
      !(restart && pmy_mesh_->pzoom != nullptr)) {
    Real finest_dx = LocalFinestMeshSpacing(pmbp);
    Real min_horizon = MinDynBBHHorizonRadius();
    if (finest_dx > min_horizon) {
      if (bbh.require_resolved_horizon) {
        std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                  << std::endl
                  << "puncture excision is under-resolved: finest active dx=" << finest_dx
                  << " exceeds minimum horizon radius=" << min_horizon << std::endl
                  << "Refine the mesh or set coord/require_resolved_horizon=false."
                  << std::endl;
        std::exit(EXIT_FAILURE);
      } else if (global_variable::my_rank == 0) {
        std::cout << "WARNING: puncture excision is under-resolved: finest active dx="
                  << finest_dx
                  << " exceeds minimum horizon radius=" << min_horizon << std::endl;
      }
    }
    bbh_traj_state traj0 = find_traj_state(0.0);
    Real m1 = traj0.q[M1T];
    Real m2 = traj0.q[M2T];
    Real rH1 = HorizonRadiusFromMassAndChi(m1, traj0.q[AX1], traj0.q[AY1],
                                           traj0.q[AZ1]);
    Real rH2 = HorizonRadiusFromMassAndChi(m2, traj0.q[AX2], traj0.q[AY2],
                                           traj0.q[AZ2]);
    Real r0 = SmoothExcisionRadiusToHorizon(
        bbh.puncture_excise_rad1, rH1, 0.0, bbh.puncture_excise_shrink_timescale,
        bbh.puncture_excise_to_horizon, bbh.puncture_excise_shrink_to_horizon);
    Real r1 = SmoothExcisionRadiusToHorizon(
        bbh.puncture_excise_rad2, rH2, 0.0, bbh.puncture_excise_shrink_timescale,
        bbh.puncture_excise_to_horizon, bbh.puncture_excise_shrink_to_horizon);
    if (bbh.puncture_excise_cap_to_horizon &&
        !bbh.puncture_excise_to_horizon &&
        !bbh.puncture_excise_shrink_to_horizon) {
      r0 = std::min(r0, rH1);
      r1 = std::min(r1, rH2);
    }
    CheckPunctureExcisionResolution(pmbp, traj0, r0, r1, "initialization");
  }

  for (int nr = 0; nr < 16; ++nr) {
    std::string name = "radius_" + std::to_string(nr) + "_rad";
    if (pin->DoesParameterExist("problem", name)) {
      bbh_ref.radius.push_back(pin->GetReal("problem", name));
      bbh_ref.reflevel.push_back(pin->GetOrAddInteger(
          "problem", "radius_" + std::to_string(nr) + "_reflevel", -1));
    } else {
      break;
    }
  }

  std::string amr_cond = pin->GetOrAddString("problem", "amr_condition", "none");
  if (amr_cond == "alpha_min") {
    std::cout << "Using Lapse-Based Refinement" << std::endl;
    bbh_ref.AlphaMin = true;
  } else if (amr_cond == "tracker") {
    std::cout << "Using Tracker-Based Refinement" << std::endl;
    bbh_ref.Tracker = true;
  }

  user_ref_func = Refine;
  user_hist_func = TorusHistory;
  if (bbh.cooling_source == CoolingSource::ism &&
      (pmbp->pmhd == nullptr || pmbp->padm == nullptr)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "ISM cooling currently requires MHD and ADM variables"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (bbh.cooling_source == CoolingSource::thin_disk &&
      (pmbp->pmhd == nullptr || pmbp->padm == nullptr)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "cooling_source=thin_disk currently requires MHD and ADM variables"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (pmbp->pmhd != nullptr &&
      bbh.cooling_source != CoolingSource::none) {
    user_srcs = true;
    user_srcs_func = AddDynBBHUserSources;
  }
  if (bbh.smooth_b_damping) {
    if (pmbp->pmhd == nullptr) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "smooth_excision_b_damping requires MHD" << std::endl;
      std::exit(EXIT_FAILURE);
    }
    auto &coord_data = pmbp->pcoord->coord_data;
    if (!coord_data.bh_excise || !coord_data.smooth_excise ||
        coord_data.excision_scheme != ExcisionScheme::puncture) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "smooth_excision_b_damping requires coord/excise=true, "
                << "coord/smooth_excision=true, and "
                << "coord/excision_scheme=puncture" << std::endl;
      std::exit(EXIT_FAILURE);
    }
    user_efield = true;
    user_efield_func = AddSmoothExcisionMagneticDamping;
  }

  if (!(std::isfinite(bbh.sep) && bbh.sep > 1.0 &&
        std::isfinite(bbh.q) && bbh.q > 0.0)) {
    Kokkos::abort("dynbbh requires finite sep > 1 and q > 0 in total-mass units");
  }
  if (bbh.corotating && (bbh.use_traj_table || bbh.spin_ramp ||
      (fabs(bbh.a1*sin(bbh.th_a1)) > 1.0e-12) ||
      (fabs(bbh.a2*sin(bbh.th_a2)) > 1.0e-12) ||
      bbh.puncture_excise_shrink_to_horizon || pmbp->padm == nullptr ||
      pmbp->pz4c != nullptr)) {
    Kokkos::abort("corotating requires a fixed circular orbit, aligned spins, "
                  "stationary excision and prescribed ADM");
  }
  if (bbh.single_black_hole && (bbh.use_traj_table || bbh.spin_ramp ||
      bbh.a1 != 0.0 || bbh.a2 != 0.0)) {
    Kokkos::abort("single_black_hole Bondi control requires nonspinning fixed M=1");
  }
  if (pmy_mesh_->pzoom != nullptr && !bbh.corotating && !bbh.single_black_hole) {
    Kokkos::abort("dynbbh cyclic zoom requires problem/corotating=true");
  }
  if (pmbp->padm != nullptr) {
    if (bbh.corotating) pmbp->padm->is_dynamic = false;
    pmbp->padm->SetADMVariables = &SetADMVariablesToBBH;
  }
  if (pmbp->prad != nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl << "dynbbh uses ADM background data and is incompatible "
              << "with legacy <radiation>; use <dyn_radiation> instead." << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (pmbp->pdynrad != nullptr) {
    if (pmbp->padm == nullptr) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl << "dynbbh <dyn_radiation> requires ADM variables."
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
    if (!(pmbp->pdynrad->use_adm_geometry)) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl << "dynbbh <dyn_radiation> requires geometry='adm'."
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
    if (pmbp->pdynrad->are_units_enabled) {
      bbh.arad = (pmbp->punit->rad_constant_cgs*
                  SQR(SQR(pmbp->punit->temperature_cgs()))/
                  pmbp->punit->pressure_cgs());
    } else {
      bbh.arad = pin->GetReal("dyn_radiation","arad");
    }
    if (!(bbh.arad > 0.0) || !std::isfinite(bbh.arad)) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl << "dynbbh <dyn_radiation> requires a positive finite "
                << "radiation constant." << std::endl;
      std::exit(EXIT_FAILURE);
    }
    bbh.restart_seed_erad_fraction =
        pin->GetOrAddReal("dyn_radiation", "restart_seed_erad_fraction", 1.0);
    if (!(bbh.restart_seed_erad_fraction >= 0.0) ||
        !std::isfinite(bbh.restart_seed_erad_fraction)) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl << "dynbbh <dyn_radiation>/restart_seed_erad_fraction "
                << "must be finite and non-negative." << std::endl;
      std::exit(EXIT_FAILURE);
    }
    pmbp->padm->SetADMVariables(pmbp);
    pmbp->pdynrad->PrepareADMGeometry();
    if (restart_missing_dynrad_i0) {
      if (pmbp->pmhd == nullptr || pmbp->pdyngr == nullptr) {
        std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                  << std::endl << "dynbbh restart activation of <dyn_radiation> "
                  << "requires Valencia GRMHD." << std::endl;
        std::exit(EXIT_FAILURE);
      }
    }
  }
  if (pmbp->ppart != nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl << "circumbinary dynbbh does not initialize particles; "
              << "use pgen_name=dynbbh_beam for the radiation beam particle test."
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (restart && bbh.restart_precondition_mhd) {
    pre_restart_conserved_init_func = InitializeDynBBHPreRestart;
  }
  if (restart && restart_missing_dynrad_i0) {
    post_restart_primitive_init_func = InitializeDynBBHPostRestart;
  }

  auto initial_condition = pin->GetOrAddString("problem", "initial_condition", "torus");
  use_bondi_inflow = initial_condition == "bondi_inflow";
  if (initial_condition != "torus" && initial_condition != "bondi_reservoir" &&
      !use_bondi_inflow) {
    Kokkos::abort("dynbbh initial_condition must be torus, bondi_reservoir or bondi_inflow");
  }
  if ((bbh.corotating || bbh.single_black_hole) &&
      initial_condition != "bondi_reservoir" && !use_bondi_inflow) {
    Kokkos::abort("corotating/single_black_hole requires a Bondi initial condition");
  }
  if (!restart && pmy_mesh_->pzoom != nullptr && pmy_mesh_->pzoom->zstate.zone != 0) {
    Kokkos::abort("Start binary cyclic zoom at zone=0; other zones require a restart");
  }
  if (initial_condition == "bondi_reservoir" || use_bondi_inflow) {
    InitializeBinaryReservoir(pmy_mesh_, pin, restart);
    user_bcs_func = BinaryReservoirBoundary;
    return;
  }

  // Flux diagnostics setup
  // Resolution of surface grids
  const int ntheta = pin->GetOrAddInteger("problem", "flux_ntheta", 64);
  const int nphi = pin->GetOrAddInteger("problem", "flux_nphi", 128);
  // Setup Radius of surface grids
  const Real r_surf_inner = pin->GetOrAddReal("problem", "flux_rsurf_inner", 10.0);
  const Real dr_surf = pin->GetOrAddReal("problem", "flux_dr_surf", 5.0);
  const Real r_surf_outer = pin->GetOrAddReal("problem", "flux_rsurf_outer", 20.0);
  // Create surfaces at three different radii and store them in the class member
  // This avoids the crash-on-exit from using a static variable.
  for (Real r_surf = r_surf_inner; r_surf <= r_surf_outer; r_surf += dr_surf) {
    auto r_func = [=](Real th, Real ph){ return r_surf; };
    this->surface_grids.push_back(std::make_unique<SphericalSurfaceGrid>(
        pmbp, ntheta, nphi, r_func, "R" + std::to_string(static_cast<int>(r_surf))));
  }

  // Horizon 1
  bool do_h1 = pin->GetOrAddBoolean("problem", "flux_horizon1", false);
  if (do_h1) {
    Real r_h1 = pin->GetOrAddReal("problem", "flux_radius1", 1);
    // Initialize centered at 0,0,0; will be moved in TorusHistory
    this->surface_grids.push_back(std::make_unique<SphericalSurfaceGrid>(
        pmbp, ntheta, nphi,
        [=](Real th, Real ph){ return r_h1; },
        "H1"));
  }

  // Horizon 2
  bool do_h2 = pin->GetOrAddBoolean("problem", "flux_horizon2", false);
  if (do_h2) {
    Real r_h2 = pin->GetOrAddReal("problem", "flux_radius2", 1);
    // Initialize centered at 0,0,0; will be moved in TorusHistory
    this->surface_grids.push_back(std::make_unique<SphericalSurfaceGrid>(
        pmbp, ntheta, nphi,
        [=](Real th, Real ph){ return r_h2; },
        "H2"));
  }

  const bool is_radiation_enabled = (pmbp->pdynrad != nullptr);

  // capture variables for the kernel
  auto &indcs = pmy_mesh_->mb_indcs;
  int &is = indcs.is; int &ie = indcs.ie;
  int &js = indcs.js; int &je = indcs.je;
  int &ks = indcs.ks; int &ke = indcs.ke;
  auto &size = pmbp->pmb->mb_size;
  int nmb = pmbp->nmb_thispack;
  //auto bbh_ = bbh;
  auto &coord = pmbp->pcoord->coord_data;
  bool use_dyngr = (pmbp->pdyngr != nullptr);


  // copied form torus PG, needs to be rewritten?

  // return if restart
  if (restart) return;

  // Select either Hydro or MHD
  DvceArray5D<Real> u0_, w0_;
  if (pmbp->phydro != nullptr) {
    u0_ = pmbp->phydro->u0;
    w0_ = pmbp->phydro->w0;
  } else if (pmbp->pmhd != nullptr) {
    u0_ = pmbp->pmhd->u0;
    w0_ = pmbp->pmhd->w0;
  }

  // Extract radiation parameters if enabled
  int nangles_;
  DualArray2D<Real> nh_c_;
  DvceArray6D<Real> norm_to_tet_;
  DvceArray4D<Real> sqrt_detg_c_;
  DvceArray5D<Real> i0_;
  if (is_radiation_enabled) {
    nangles_ = pmbp->pdynrad->prgeo->nangles;
    nh_c_ = pmbp->pdynrad->nh_c;
    norm_to_tet_ = pmbp->pdynrad->norm_to_tet;
    sqrt_detg_c_ = pmbp->pdynrad->sqrt_detg_c;
    i0_ = pmbp->pdynrad->i0;
  }

  // Get ideal gas EOS data
  if (pmbp->phydro != nullptr) {
    bbh.gamma_adi = pmbp->phydro->peos->eos_data.gamma;
  } else if (pmbp->pmhd != nullptr) {
    bbh.gamma_adi = pmbp->pmhd->peos->eos_data.gamma;
  }
  Real gm1 = bbh.gamma_adi - 1.0;

  // global parameters
  bbh.rho_min = pin->GetReal("problem", "rho_min");
  bbh.rho_pow = pin->GetReal("problem", "rho_pow");
  bbh.pgas_min = pin->GetReal("problem", "pgas_min");
  bbh.pgas_pow = pin->GetReal("problem", "pgas_pow");
  bbh.psi = pin->GetOrAddReal("problem", "tilt_angle", 0.0) * (M_PI/180.0);
  bbh.sin_psi = sin(bbh.psi);
  bbh.cos_psi = cos(bbh.psi);
  bbh.rho_max = pin->GetReal("problem", "rho_max");
  bbh.r_edge = pin->GetReal("problem", "r_edge");
  bbh.r_peak = pin->GetReal("problem", "r_peak");
  bbh.n_param = pin->GetOrAddReal("problem", "n_param",0.0);

  // local parameters
  Real pert_amp = pin->GetOrAddReal("problem", "pert_amp", 0.0);

  // excision parameters
  bbh.dexcise = coord.dexcise;
  bbh.pexcise = coord.pexcise;

  // Compute angular momentum and prepare constants describing primitives
  CalculateCN(bbh, &bbh.c_param, &bbh.n_param);
  bbh.l_peak = CalculateL(bbh, bbh.r_peak, 1.0);
  // Common to both tori:
  bbh.log_h_edge = LogHAux(bbh, bbh.r_edge, 1.0);
  bbh.log_h_peak = LogHAux(bbh, bbh.r_peak, 1.0) - bbh.log_h_edge;
  bbh.ptot_over_rho_peak = gm1/bbh.gamma_adi * (exp(bbh.log_h_peak)-1.0);
  bbh.rho_peak = pow(bbh.ptot_over_rho_peak, 1.0/gm1) / bbh.rho_max;

  // find "outer edge" of torus (first place log_h > 0)
  Real ra = bbh.r_peak;
  Real rb = 2. * ra;
  Real log_h_trial = LogHAux(bbh, rb, 1.) - bbh.log_h_edge;
  for (int iter=0; iter<10000; ++iter) {
    if (log_h_trial <= 0) {
      break;
    }
    rb *= 2.;
    log_h_trial = LogHAux(bbh, rb, 1.) - bbh.log_h_edge;
  }
  for (int iter=0; iter<10000; ++iter) {
    if (fabs(ra - rb) < 1.e-3) {
      break;
    }
    Real r_trial = (ra + rb) / 2.;
    if (LogHAux(bbh, r_trial, 1.) > bbh.log_h_edge) {
      ra = r_trial;
    } else {
      rb = r_trial;
    }
  }
  bbh.r_outer_edge = ra;
  std::cout << "Found torus outer edge: " << bbh.r_outer_edge << std::endl;

  // initialize primitive variables for new run ---------------------------------------

  auto trs = bbh;
  Kokkos::Random_XorShift64_Pool<> rand_pool64(pmbp->gids);
  Real ptotmax = std::numeric_limits<float>::min();
  const int nmkji = (pmbp->nmb_thispack)*indcs.nx3*indcs.nx2*indcs.nx1;
  const int nkji = indcs.nx3*indcs.nx2*indcs.nx1;
  const int nji  = indcs.nx2*indcs.nx1;

  bbh_traj_state traj0 = find_traj_state(0.0);

  Kokkos::parallel_reduce("pgen_torus1", Kokkos::RangePolicy<>(DevExeSpace(), 0, nmkji),
  KOKKOS_LAMBDA(const int &idx, Real &max_ptot) {
    // compute m,k,j,i indices of thread and call function
    int m = (idx)/nkji;
    int k = (idx - m*nkji)/nji;
    int j = (idx - m*nkji - k*nji)/indcs.nx1;
    int i = (idx - m*nkji - k*nji - j*indcs.nx1) + is;
    k += ks;
    j += js;

    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);

    Real &dx1 = size.d_view(m).dx1;
    Real &dx2 = size.d_view(m).dx2;
    Real &dx3 = size.d_view(m).dx3;

    // Extract metric and inverse -- presumably should get actual metric?????
    Real glower[4][4], gupper[4][4];
    GetSuperposedAndInverse(0.0, x1v, x2v, x3v, glower, gupper, traj0.q, trs);

    // Calculate Boyer-Lindquist coordinates of cell
    Real r, theta, phi;
    GetBoyerLindquistCoordinates(trs, x1v, x2v, x3v, &r, &theta, &phi);
    Real sin_theta = sin(theta);
    Real cos_theta = cos(theta);
    Real sin_phi = sin(phi);
    Real cos_phi = cos(phi);

    // Account for tilt
    Real sin_vartheta;
    if (trs.psi != 0.0) {
      Real x = sin_theta * cos_phi;
      Real y = sin_theta * sin_phi;
      Real z = cos_theta;
      Real varx = trs.cos_psi * x - trs.sin_psi * z;
      Real vary = y;
      sin_vartheta = sqrt(SQR(varx) + SQR(vary));
    } else {
      sin_vartheta = fabs(sin_theta);
    }

    // Determine if we are in the torus
    Real log_h;
    bool in_torus = false;
    if (r >= trs.r_edge) {
      log_h = LogHAux(trs, r, sin_vartheta)- trs.log_h_edge;  // (FM 3.6)
      if (log_h >= 0.0) {
        in_torus = true;
      }
    }

    // Calculate background primitives -- to be consistent with the excision algorithm,
    // we have to recalculate r; we try to avoid excising cells within the horizon which
    // might have a corner sticking out of the horizon.
    Real r_excise, theta_excise, phi_excise;
    GetBoyerLindquistCoordinates(trs, x1v + copysign(0.5*dx1,x1v),
                                      x2v + copysign(0.5*dx2,x2v),
                                      x3v + copysign(0.5*dx3,x3v), &r_excise,
                                      &theta_excise, &phi_excise);
    Real rho_bg, pgas_bg;
    if (r_excise > 1.0) {
      rho_bg = trs.rho_min * pow(r, trs.rho_pow);
      pgas_bg = trs.pgas_min * pow(r, trs.pgas_pow);
    } else {
      rho_bg = trs.dexcise;
      pgas_bg = trs.pexcise;
    }

    Real rho = rho_bg;
    Real pgas = pgas_bg;
    Real uu1 = 0.0;
    Real uu2 = 0.0;
    Real uu3 = 0.0;
    Real urad = 0.0;

    Real perturbation = 0.0;
    // Overwrite primitives inside torus
    if (in_torus) {
      // Calculate perturbation
      auto rand_gen = rand_pool64.get_state(); // get random number state this thread
      perturbation = 2.0*pert_amp*(rand_gen.frand() - 0.5);
      rand_pool64.free_state(rand_gen);        // free state for use by other threads

      // Calculate thermodynamic variables
      Real ptot_over_rho = gm1/trs.gamma_adi * (exp(log_h) - 1.0);
      rho = pow(ptot_over_rho, 1.0/gm1) / trs.rho_peak;
      Real temp = ptot_over_rho;
      if (is_radiation_enabled) temp = CalculateT(trs, rho, ptot_over_rho);
      pgas = temp * rho;

      // Calculate radiation variables (if radiation enabled)
      if (is_radiation_enabled) urad = trs.arad * SQR(SQR(temp));

      // Calculate velocities in Boyer-Lindquist coordinates
      Real u0_bl, u1_bl, u2_bl, u3_bl;
      CalculateVelocityInTiltedTorus(trs, r, theta, phi,
                                     &u0_bl, &u1_bl, &u2_bl, &u3_bl);

      // Transform to preferred coordinates
      Real u0, u1, u2, u3;
      TransformVector(trs, u0_bl, 0.0, u2_bl, u3_bl,
                      x1v, x2v, x3v, &u0, &u1, &u2, &u3);

      Real glower[4][4], gupper[4][4];
      GetSuperposedAndInverse(0.0, x1v, x2v, x3v, glower, gupper, traj0.q, trs);

      uu1 = u1 - gupper[0][1]/gupper[0][0] * u0;
      uu2 = u2 - gupper[0][2]/gupper[0][0] * u0;
      uu3 = u3 - gupper[0][3]/gupper[0][0] * u0;
    }

    // Set primitive values, including random perturbations to pressure
    w0_(m,IDN,k,j,i) = fmax(rho, rho_bg);
    if (!use_dyngr) {
      w0_(m,IEN,k,j,i) = fmax(pgas, pgas_bg) * (1.0 + perturbation) / gm1;
    } else {
      w0_(m,IPR,k,j,i) = fmax(pgas, pgas_bg) * (1.0 + perturbation);
    }
    w0_(m,IVX,k,j,i) = uu1;
    w0_(m,IVY,k,j,i) = uu2;
    w0_(m,IVZ,k,j,i) = uu3;

    // Set coordinate frame intensity (if radiation enabled)
    if (is_radiation_enabled) {
      Real q = glower[1][1]*uu1*uu1 + 2.0*glower[1][2]*uu1*uu2 + 2.0*glower[1][3]*uu1*uu3
             + glower[2][2]*uu2*uu2 + 2.0*glower[2][3]*uu2*uu3
             + glower[3][3]*uu3*uu3;
      Real uu0 = sqrt(1.0 + q);
      Real u_tet_[4];
      u_tet_[0] = (norm_to_tet_(m,0,0,k,j,i)*uu0 + norm_to_tet_(m,0,1,k,j,i)*uu1 +
                   norm_to_tet_(m,0,2,k,j,i)*uu2 + norm_to_tet_(m,0,3,k,j,i)*uu3);
      u_tet_[1] = (norm_to_tet_(m,1,0,k,j,i)*uu0 + norm_to_tet_(m,1,1,k,j,i)*uu1 +
                   norm_to_tet_(m,1,2,k,j,i)*uu2 + norm_to_tet_(m,1,3,k,j,i)*uu3);
      u_tet_[2] = (norm_to_tet_(m,2,0,k,j,i)*uu0 + norm_to_tet_(m,2,1,k,j,i)*uu1 +
                   norm_to_tet_(m,2,2,k,j,i)*uu2 + norm_to_tet_(m,2,3,k,j,i)*uu3);
      u_tet_[3] = (norm_to_tet_(m,3,0,k,j,i)*uu0 + norm_to_tet_(m,3,1,k,j,i)*uu1 +
                   norm_to_tet_(m,3,2,k,j,i)*uu2 + norm_to_tet_(m,3,3,k,j,i)*uu3);

      // Go through each angle
      for (int n=0; n<nangles_; ++n) {
        // Calculate direction in fluid frame
        Real un_t = (u_tet_[1]*nh_c_.d_view(n,1) + u_tet_[2]*nh_c_.d_view(n,2) +
                     u_tet_[3]*nh_c_.d_view(n,3));
        Real n0_f = u_tet_[0]*nh_c_.d_view(n,0) - un_t;

        // Calculate intensity in tetrad frame
        i0_(m,n,k,j,i) =
            sqrt_detg_c_(m,k,j,i)*(urad/(4.0*M_PI))/SQR(SQR(n0_f));
      }
    }
    // Compute total pressure (equal to gas pressure in non-radiating runs)
    Real ptot;
    if (!use_dyngr) {
      ptot = gm1*w0_(m,IEN,k,j,i);
    } else {
      ptot = w0_(m,IPR,k,j,i);
    }
    if (is_radiation_enabled) ptot += urad/3.0;
    max_ptot = fmax(ptot, max_ptot);
  }, Kokkos::Max<Real>(ptotmax));

  // Initialize ADM variables -------------------------------
  if (pmbp->padm != nullptr) {
    pmbp->padm->SetADMVariables(pmbp);
    if (pmbp->pcoord->coord_data.bh_excise) {
      pmbp->pcoord->UpdateExcisionMasks();
    }
    pmbp->pdyngr->PrimToConInit(is, ie, js, je, ks, ke);
  }

  // initialize magnetic fields ---------------------------------------

  if (pmbp->pmhd != nullptr) {
    // parse some more parameters from input
    bbh.potential_beta_min = pin->GetOrAddReal("problem", "potential_beta_min", 100.0);
    bbh.potential_cutoff   = pin->GetOrAddReal("problem", "potential_cutoff", 0.2);

    bbh.is_vertical_field = pin->GetOrAddBoolean("problem", "vertical_field", false);

    bbh.potential_falloff  = pin->GetOrAddReal("problem", "potential_falloff", 0.0);
    bbh.potential_r_pow    = pin->GetOrAddReal("problem", "potential_r_pow", 0.0);
    bbh.potential_rho_pow  = pin->GetOrAddReal("problem", "potential_rho_pow", 1.0);

    // compute vector potential over all faces
    int ncells1 = indcs.nx1 + 2*(indcs.ng);
    int ncells2 = (indcs.nx2 > 1)? (indcs.nx2 + 2*(indcs.ng)) : 1;
    int ncells3 = (indcs.nx3 > 1)? (indcs.nx3 + 2*(indcs.ng)) : 1;
    DvceArray4D<Real> a1, a2, a3;
    Kokkos::realloc(a1, nmb,ncells3,ncells2,ncells1);
    Kokkos::realloc(a2, nmb,ncells3,ncells2,ncells1);
    Kokkos::realloc(a3, nmb,ncells3,ncells2,ncells1);

    auto &nghbr = pmbp->pmb->nghbr;
    auto &mblev = pmbp->pmb->mb_lev;
    auto trs = bbh;

    par_for("pgen_vector_potential", DevExeSpace(), 0,nmb-1,ks,ke+1,js,je+1,is,ie+1,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      int nx1 = indcs.nx1;
      Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
      Real x1f   = LeftEdgeX(i  -is, nx1, x1min, x1max);

      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      int nx2 = indcs.nx2;
      Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
      Real x2f   = LeftEdgeX(j  -js, nx2, x2min, x2max);

      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      int nx3 = indcs.nx3;
      Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
      Real x3f   = LeftEdgeX(k  -ks, nx3, x3min, x3max);

      Real dx1 = size.d_view(m).dx1;
      Real dx2 = size.d_view(m).dx2;
      Real dx3 = size.d_view(m).dx3;

      a1(m,k,j,i) = A1(trs, x1v, x2f, x3f);
      a2(m,k,j,i) = A2(trs, x1f, x2v, x3f);
      a3(m,k,j,i) = A3(trs, x1f, x2f, x3v);

      // When neighboring MeshBock is at finer level, compute vector potential as sum of
      // values at fine grid resolution.  This guarantees flux on shared fine/coarse
      // faces is identical.

      // Correct A1 at x2-faces, x3-faces, and x2x3-edges
      if ((nghbr.d_view(m,8 ).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,9 ).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,10).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,11).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,12).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,13).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,14).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,15).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,24).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,25).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,26).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,27).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,28).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,29).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,30).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,31).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,40).lev > mblev.d_view(m) && j==js && k==ks) ||
          (nghbr.d_view(m,41).lev > mblev.d_view(m) && j==js && k==ks) ||
          (nghbr.d_view(m,42).lev > mblev.d_view(m) && j==je+1 && k==ks) ||
          (nghbr.d_view(m,43).lev > mblev.d_view(m) && j==je+1 && k==ks) ||
          (nghbr.d_view(m,44).lev > mblev.d_view(m) && j==js && k==ke+1) ||
          (nghbr.d_view(m,45).lev > mblev.d_view(m) && j==js && k==ke+1) ||
          (nghbr.d_view(m,46).lev > mblev.d_view(m) && j==je+1 && k==ke+1) ||
          (nghbr.d_view(m,47).lev > mblev.d_view(m) && j==je+1 && k==ke+1)) {
        Real xl = x1v + 0.25*dx1;
        Real xr = x1v - 0.25*dx1;
        a1(m,k,j,i) = 0.5*(A1(trs, xl,x2f,x3f) + A1(trs, xr,x2f,x3f));
      }

      // Correct A2 at x1-faces, x3-faces, and x1x3-edges
      if ((nghbr.d_view(m,0 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,1 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,2 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,3 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,4 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,5 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,6 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,7 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,24).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,25).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,26).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,27).lev > mblev.d_view(m) && k==ks) ||
          (nghbr.d_view(m,28).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,29).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,30).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,31).lev > mblev.d_view(m) && k==ke+1) ||
          (nghbr.d_view(m,32).lev > mblev.d_view(m) && i==is && k==ks) ||
          (nghbr.d_view(m,33).lev > mblev.d_view(m) && i==is && k==ks) ||
          (nghbr.d_view(m,34).lev > mblev.d_view(m) && i==ie+1 && k==ks) ||
          (nghbr.d_view(m,35).lev > mblev.d_view(m) && i==ie+1 && k==ks) ||
          (nghbr.d_view(m,36).lev > mblev.d_view(m) && i==is && k==ke+1) ||
          (nghbr.d_view(m,37).lev > mblev.d_view(m) && i==is && k==ke+1) ||
          (nghbr.d_view(m,38).lev > mblev.d_view(m) && i==ie+1 && k==ke+1) ||
          (nghbr.d_view(m,39).lev > mblev.d_view(m) && i==ie+1 && k==ke+1)) {
        Real xl = x2v + 0.25*dx2;
        Real xr = x2v - 0.25*dx2;
        a2(m,k,j,i) = 0.5*(A2(trs, x1f,xl,x3f) + A2(trs, x1f,xr,x3f));
      }

      // Correct A3 at x1-faces, x2-faces, and x1x2-edges
      if ((nghbr.d_view(m,0 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,1 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,2 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,3 ).lev > mblev.d_view(m) && i==is) ||
          (nghbr.d_view(m,4 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,5 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,6 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,7 ).lev > mblev.d_view(m) && i==ie+1) ||
          (nghbr.d_view(m,8 ).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,9 ).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,10).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,11).lev > mblev.d_view(m) && j==js) ||
          (nghbr.d_view(m,12).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,13).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,14).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,15).lev > mblev.d_view(m) && j==je+1) ||
          (nghbr.d_view(m,16).lev > mblev.d_view(m) && i==is && j==js) ||
          (nghbr.d_view(m,17).lev > mblev.d_view(m) && i==is && j==js) ||
          (nghbr.d_view(m,18).lev > mblev.d_view(m) && i==ie+1 && j==js) ||
          (nghbr.d_view(m,19).lev > mblev.d_view(m) && i==ie+1 && j==js) ||
          (nghbr.d_view(m,20).lev > mblev.d_view(m) && i==is && j==je+1) ||
          (nghbr.d_view(m,21).lev > mblev.d_view(m) && i==is && j==je+1) ||
          (nghbr.d_view(m,22).lev > mblev.d_view(m) && i==ie+1 && j==je+1) ||
          (nghbr.d_view(m,23).lev > mblev.d_view(m) && i==ie+1 && j==je+1)) {
        Real xl = x3v + 0.25*dx3;
        Real xr = x3v - 0.25*dx3;
        a3(m,k,j,i) = 0.5*(A3(trs, x1f,x2f,xl) + A3(trs, x1f,x2f,xr));
      }
    });

    auto &b0 = pmbp->pmhd->b0;
    par_for("pgen_b0", DevExeSpace(), 0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      // Compute face-centered fields from curl(A).
      Real dx1 = size.d_view(m).dx1;
      Real dx2 = size.d_view(m).dx2;
      Real dx3 = size.d_view(m).dx3;

      b0.x1f(m,k,j,i) = ((a3(m,k,j+1,i) - a3(m,k,j,i))/dx2 -
                         (a2(m,k+1,j,i) - a2(m,k,j,i))/dx3);
      b0.x2f(m,k,j,i) = ((a1(m,k+1,j,i) - a1(m,k,j,i))/dx3 -
                         (a3(m,k,j,i+1) - a3(m,k,j,i))/dx1);
      b0.x3f(m,k,j,i) = ((a2(m,k,j,i+1) - a2(m,k,j,i))/dx1 -
                         (a1(m,k,j+1,i) - a1(m,k,j,i))/dx2);

      // Include extra face-component at edge of block in each direction
      if (i==ie) {
        b0.x1f(m,k,j,i+1) = ((a3(m,k,j+1,i+1) - a3(m,k,j,i+1))/dx2 -
                             (a2(m,k+1,j,i+1) - a2(m,k,j,i+1))/dx3);
      }
      if (j==je) {
        b0.x2f(m,k,j+1,i) = ((a1(m,k+1,j+1,i) - a1(m,k,j+1,i))/dx3 -
                             (a3(m,k,j+1,i+1) - a3(m,k,j+1,i))/dx1);
      }
      if (k==ke) {
        b0.x3f(m,k+1,j,i) = ((a2(m,k+1,j,i+1) - a2(m,k+1,j,i))/dx1 -
                             (a1(m,k+1,j+1,i) - a1(m,k+1,j,i))/dx2);
      }
    });

    // Compute cell-centered fields
    auto &bcc_ = pmbp->pmhd->bcc0;
    par_for("pgen_bcc", DevExeSpace(), 0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      // cell-centered fields are simple linear average of face-centered fields
      Real& w_bx = bcc_(m,IBX,k,j,i);
      Real& w_by = bcc_(m,IBY,k,j,i);
      Real& w_bz = bcc_(m,IBZ,k,j,i);
      w_bx = 0.5*(b0.x1f(m,k,j,i) + b0.x1f(m,k,j,i+1));
      w_by = 0.5*(b0.x2f(m,k,j,i) + b0.x2f(m,k,j+1,i));
      w_bz = 0.5*(b0.x3f(m,k,j,i) + b0.x3f(m,k+1,j,i));
    });


    // find maximum bsq
    Real bsqmax = std::numeric_limits<float>::min();
    Real bsqmax_intorus = std::numeric_limits<float>::min();
    const int nmkji = (pmbp->nmb_thispack)*indcs.nx3*indcs.nx2*indcs.nx1;
    const int nkji = indcs.nx3*indcs.nx2*indcs.nx1;
    const int nji  = indcs.nx2*indcs.nx1;
    Kokkos::parallel_reduce("torus_beta", Kokkos::RangePolicy<>(DevExeSpace(), 0, nmkji),
    KOKKOS_LAMBDA(const int &idx, Real &max_bsq, Real &max_bsq_intorus) {
      // compute m,k,j,i indices of thread and call function
      int m = (idx)/nkji;
      int k = (idx - m*nkji)/nji;
      int j = (idx - m*nkji - k*nji)/indcs.nx1;
      int i = (idx - m*nkji - k*nji - j*indcs.nx1) + is;
      k += ks;
      j += js;

      // Extract metric components
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);
      Real glower[4][4], gupper[4][4];
      GetSuperposedAndInverse(0.0, x1v, x2v, x3v, glower, gupper, traj0.q, trs);

      // Calculate Boyer-Lindquist coordinates of cell
      Real r, theta, phi;
      GetBoyerLindquistCoordinates(trs, x1v, x2v, x3v, &r, &theta, &phi);
      Real sin_theta = sin(theta);
      Real cos_theta = cos(theta);
      Real sin_phi = sin(phi);
      Real cos_phi = cos(phi);

      // Account for tilt
      Real sin_vartheta;
      if (trs.psi != 0.0) {
        Real x = sin_theta * cos_phi;
        Real y = sin_theta * sin_phi;
        Real z = cos_theta;
        Real varx = trs.cos_psi * x - trs.sin_psi * z;
        Real vary = y;
        sin_vartheta = sqrt(SQR(varx) + SQR(vary));
      } else {
	sin_vartheta = fabs(sin_theta);
      }

      // Determine if we are in the torus
      Real log_h;
      bool in_torus = false;
      if (r >= trs.r_edge) {
        log_h = LogHAux(trs, r, sin_vartheta) - trs.log_h_edge;  // (FM 3.6)
        if (log_h >= 0.0) {
          in_torus = true;
        }
      }

      // Extract primitive velocity, magnetic field B^i, and gas pressure
      Real &wvx = w0_(m,IVX,k,j,i);
      Real &wvy = w0_(m,IVY,k,j,i);
      Real &wvz = w0_(m,IVZ,k,j,i);
      Real &wbx = bcc_(m,IBX,k,j,i);
      Real &wby = bcc_(m,IBY,k,j,i);
      Real &wbz = bcc_(m,IBZ,k,j,i);

      // Calculate 4-velocity (exploiting symmetry of metric)
      Real q = glower[1][1]*wvx*wvx +2.0*glower[1][2]*wvx*wvy +2.0*glower[1][3]*wvx*wvz
             + glower[2][2]*wvy*wvy +2.0*glower[2][3]*wvy*wvz
             + glower[3][3]*wvz*wvz;
      Real alpha = sqrt(-1.0/gupper[0][0]);
      Real lor = sqrt(1.0 + q);
      Real u0 = lor / alpha;
      Real u1 = wvx - alpha * lor * gupper[0][1];
      Real u2 = wvy - alpha * lor * gupper[0][2];
      Real u3 = wvz - alpha * lor * gupper[0][3];

      // lower vector indices
      Real u_1 = glower[1][0]*u0 + glower[1][1]*u1 + glower[1][2]*u2 + glower[1][3]*u3;
      Real u_2 = glower[2][0]*u0 + glower[2][1]*u1 + glower[2][2]*u2 + glower[2][3]*u3;
      Real u_3 = glower[3][0]*u0 + glower[3][1]*u1 + glower[3][2]*u2 + glower[3][3]*u3;

      // Calculate 4-magnetic field
      Real b0 = u_1*wbx + u_2*wby + u_3*wbz;
      Real b1 = (wbx + b0 * u1) / u0;
      Real b2 = (wby + b0 * u2) / u0;
      Real b3 = (wbz + b0 * u3) / u0;

      // lower vector indices and compute bsq
      Real b_0 = glower[0][0]*b0 + glower[0][1]*b1 + glower[0][2]*b2 + glower[0][3]*b3;
      Real b_1 = glower[1][0]*b0 + glower[1][1]*b1 + glower[1][2]*b2 + glower[1][3]*b3;
      Real b_2 = glower[2][0]*b0 + glower[2][1]*b1 + glower[2][2]*b2 + glower[2][3]*b3;
      Real b_3 = glower[3][0]*b0 + glower[3][1]*b1 + glower[3][2]*b2 + glower[3][3]*b3;
      Real bsq = b0*b_0 + b1*b_1 + b2*b_2 + b3*b_3;

      max_bsq = fmax(bsq, max_bsq);
      if (in_torus) {
        max_bsq_intorus = fmax(bsq, max_bsq_intorus);
      }
    }, Kokkos::Max<Real>(bsqmax), Kokkos::Max<Real>(bsqmax_intorus));


#if MPI_PARALLEL_ENABLED
    // get maximum value of gas pressure and bsq over all MPI ranks
    MPI_Allreduce(MPI_IN_PLACE, &ptotmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(MPI_IN_PLACE, &bsqmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    MPI_Allreduce(MPI_IN_PLACE, &bsqmax_intorus, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
#endif

    // Apply renormalization of magnetic field
    Real bnorm = sqrt((ptotmax/(0.5*bsqmax))/trs.potential_beta_min);
    // Since vertical field extends beyond torus, normalize based on values in torus
    if (trs.is_vertical_field) {
      bnorm = sqrt((ptotmax/(0.5*bsqmax_intorus))/trs.potential_beta_min);
    }

    par_for("pgen_normb0", DevExeSpace(), 0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      b0.x1f(m,k,j,i) *= bnorm;
      b0.x2f(m,k,j,i) *= bnorm;
      b0.x3f(m,k,j,i) *= bnorm;
      if (i==ie) { b0.x1f(m,k,j,i+1) *= bnorm; }
      if (j==je) { b0.x2f(m,k,j+1,i) *= bnorm; }
      if (k==ke) { b0.x3f(m,k+1,j,i) *= bnorm; }
    });

    // Recompute cell-centered magnetic field
    par_for("pgen_normbcc", DevExeSpace(), 0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      // cell-centered fields are simple linear average of face-centered fields
      Real& w_bx = bcc_(m,IBX,k,j,i);
      Real& w_by = bcc_(m,IBY,k,j,i);
      Real& w_bz = bcc_(m,IBZ,k,j,i);
      w_bx = 0.5*(b0.x1f(m,k,j,i) + b0.x1f(m,k,j,i+1));
      w_by = 0.5*(b0.x2f(m,k,j,i) + b0.x2f(m,k,j+1,i));
      w_bz = 0.5*(b0.x3f(m,k,j,i) + b0.x3f(m,k+1,j,i));
    });
  }

  // Convert primitives to conserved
  if (pmbp->padm == nullptr) {
    if (pmbp->phydro != nullptr) {
      pmbp->phydro->peos->PrimToCons(w0_, u0_, is, ie, js, je, ks, ke);
    } else if (pmbp->pmhd != nullptr) {
      auto &bcc0_ = pmbp->pmhd->bcc0;
      pmbp->pmhd->peos->PrimToCons(w0_, bcc0_, u0_, is, ie, js, je, ks, ke);
    }
  } else {
    //pmbp->pdyngr->PrimToConInit(0, (n1-1), 0, (n2-1), 0, (n3-1));
    pmbp->pdyngr->PrimToConInit(is, ie, js, je, ks, ke);
  }
  return;
}

namespace {

void InitializeDynBBHPreRestart(Mesh *pm) {
  if (bbh.restart_precondition_mhd) {
    PreconditionDynBBHRestartMHD(pm);
  }
}

void InitializeDynBBHPostRestart(Mesh *pm) {
  if (pm->pgen->restart_missing_dynrad_i0) {
    InitializeDynBBHRestartDynRadiation(pm);
  }
}

void PreconditionDynBBHRestartMHD(Mesh *pm) {
  MeshBlockPack *pmbp = pm->pmb_pack;
  if (pmbp->pmhd == nullptr || pmbp->pdyngr == nullptr || pmbp->padm == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl << "dynbbh restart preconditioning requires MHD, "
              << "Valencia GRMHD, and ADM variables." << std::endl;
    std::exit(EXIT_FAILURE);
  }

  pmbp->padm->SetADMVariables(pmbp);
  if (pmbp->pcoord->coord_data.bh_excise) {
    pmbp->pcoord->UpdateExcisionMasks();
  }
  if (pmbp->nmb_thispack == 0) return;

  auto &indcs = pm->mb_indcs;
  int &is = indcs.is;
  int &ie = indcs.ie;
  int &js = indcs.js;
  int &je = indcs.je;
  int &ks = indcs.ks;
  int &ke = indcs.ke;
  int nmb1 = pmbp->nmb_thispack - 1;

  auto &u0 = pmbp->pmhd->u0;
  auto &w0 = pmbp->pmhd->w0;
  auto &b0 = pmbp->pmhd->b0;
  auto &bcc0 = pmbp->pmhd->bcc0;
  auto &adm = pmbp->padm->adm;
  auto &size = pmbp->pmb->mb_size;
  auto eos_data = pmbp->pmhd->peos->eos_data;
  int &nmhd = pmbp->pmhd->nmhd;
  int &nscal = pmbp->pmhd->nscalars;
  const Real radius = bbh.restart_precondition_radius;
  const Real rho_floor = bbh.restart_precondition_rho_floor;
  const Real temp_floor = bbh.restart_precondition_temp_floor;
  const Real temp_ceil = bbh.restart_precondition_temp_ceil;
  const Real sigma_max = bbh.restart_precondition_sigma_max;
  const Real velocity_max = bbh.restart_precondition_velocity_max;
  if (!(eos_data.is_ideal)) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl << "dynbbh restart preconditioning currently supports "
              << "only ideal-gas MHD, because it replaces masked Valencia "
              << "conserved cells directly." << std::endl;
    std::exit(EXIT_FAILURE);
  }

  DvceArray1D<int> counts("dynbbh_restart_precondition_counts", 10);
  Kokkos::deep_copy(DevExeSpace(), counts, 0);

  par_for("dynbbh_restart_precondition_mhd", DevExeSpace(),
          0, nmb1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(int m, int k, int j, int i) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);

    const Real old_d = u0(m,IDN,k,j,i);
    const Real old_m1 = u0(m,IM1,k,j,i);
    const Real old_m2 = u0(m,IM2,k,j,i);
    const Real old_m3 = u0(m,IM3,k,j,i);
    const Real old_e = u0(m,IEN,k,j,i);
    const bool old_cons_finite =
        Kokkos::isfinite(old_d) && Kokkos::isfinite(old_m1) &&
        Kokkos::isfinite(old_m2) && Kokkos::isfinite(old_m3) &&
        Kokkos::isfinite(old_e);
    const Real r = sqrt(SQR(x1v) + SQR(x2v) + SQR(x3v));
    const bool inside_radius = Kokkos::isfinite(r) && r <= radius;
    if (!(inside_radius) && old_cons_finite) return;
    Kokkos::atomic_add(&counts(0), 1);
    if (inside_radius) {
      Kokkos::atomic_add(&counts(8), 1);
    } else {
      Kokkos::atomic_add(&counts(9), 1);
    }
    if (!old_cons_finite) {
      Kokkos::atomic_add(&counts(5), 1);
    }

    Real bx_l = b0.x1f(m,k,j,i);
    Real bx_r = b0.x1f(m,k,j,i+1);
    Real by_l = b0.x2f(m,k,j,i);
    Real by_r = b0.x2f(m,k,j+1,i);
    Real bz_l = b0.x3f(m,k,j,i);
    Real bz_r = b0.x3f(m,k+1,j,i);
    int bbad = 0;
    Real bx;
    if (Kokkos::isfinite(bx_l) && Kokkos::isfinite(bx_r)) {
      bx = 0.5*(bx_l + bx_r);
    } else if (Kokkos::isfinite(bx_l)) {
      bx = bx_l;
      bbad = 1;
    } else if (Kokkos::isfinite(bx_r)) {
      bx = bx_r;
      bbad = 1;
    } else {
      bx = 0.0;
      bbad = 1;
    }
    Real by;
    if (Kokkos::isfinite(by_l) && Kokkos::isfinite(by_r)) {
      by = 0.5*(by_l + by_r);
    } else if (Kokkos::isfinite(by_l)) {
      by = by_l;
      bbad = 1;
    } else if (Kokkos::isfinite(by_r)) {
      by = by_r;
      bbad = 1;
    } else {
      by = 0.0;
      bbad = 1;
    }
    Real bz;
    if (Kokkos::isfinite(bz_l) && Kokkos::isfinite(bz_r)) {
      bz = 0.5*(bz_l + bz_r);
    } else if (Kokkos::isfinite(bz_l)) {
      bz = bz_l;
      bbad = 1;
    } else if (Kokkos::isfinite(bz_r)) {
      bz = bz_r;
      bbad = 1;
    } else {
      bz = 0.0;
      bbad = 1;
    }
    if (bbad != 0) {
      Kokkos::atomic_add(&counts(7), 1);
    }
    bcc0(m,IBX,k,j,i) = bx;
    bcc0(m,IBY,k,j,i) = by;
    bcc0(m,IBZ,k,j,i) = bz;

    const Real detg =
        adm.g_dd(m,0,0,k,j,i) *
            (adm.g_dd(m,1,1,k,j,i)*adm.g_dd(m,2,2,k,j,i) -
             SQR(adm.g_dd(m,1,2,k,j,i))) -
        adm.g_dd(m,0,1,k,j,i) *
            (adm.g_dd(m,0,1,k,j,i)*adm.g_dd(m,2,2,k,j,i) -
             adm.g_dd(m,0,2,k,j,i)*adm.g_dd(m,1,2,k,j,i)) +
        adm.g_dd(m,0,2,k,j,i) *
            (adm.g_dd(m,0,1,k,j,i)*adm.g_dd(m,1,2,k,j,i) -
             adm.g_dd(m,0,2,k,j,i)*adm.g_dd(m,1,1,k,j,i));
    if (!(detg > 0.0) || !(Kokkos::isfinite(detg))) {
      Kokkos::atomic_add(&counts(5), 1);
      return;
    }
    const Real sdetg = sqrt(detg);
    const Real isdetg = 1.0/sdetg;
    const Real bxu = bx*isdetg;
    const Real byu = by*isdetg;
    const Real bzu = bz*isdetg;
    const Real b2 =
        adm.g_dd(m,0,0,k,j,i)*SQR(bxu) +
        adm.g_dd(m,1,1,k,j,i)*SQR(byu) +
        adm.g_dd(m,2,2,k,j,i)*SQR(bzu) +
        2.0*adm.g_dd(m,0,1,k,j,i)*bxu*byu +
        2.0*adm.g_dd(m,0,2,k,j,i)*bxu*bzu +
        2.0*adm.g_dd(m,1,2,k,j,i)*byu*bzu;

    Real dtarget = rho_floor;
    if (!(inside_radius) && Kokkos::isfinite(old_d) && old_d > 0.0) {
      const Real old_rho = old_d*isdetg;
      if (Kokkos::isfinite(old_rho) && old_rho > dtarget) {
        dtarget = old_rho;
      }
    }
    if (sigma_max > 0.0 && Kokkos::isfinite(b2) && b2 > 0.0) {
      const Real dsigma = b2/sigma_max;
      if (dsigma > dtarget) {
        dtarget = dsigma;
        Kokkos::atomic_add(&counts(6), 1);
      }
    }

    Real press = (temp_floor > 0.0) ? dtarget*temp_floor : eos_data.pfloor;
    if (!(Kokkos::isfinite(press)) || !(press > 0.0)) {
      press = eos_data.pfloor;
    }
    if (temp_ceil > 0.0 && press > dtarget*temp_ceil) {
      press = dtarget*temp_ceil;
      Kokkos::atomic_add(&counts(3), 1);
    }
    Kokkos::atomic_add(&counts(1), 1);
    Kokkos::atomic_add(&counts(2), 1);
    Kokkos::atomic_add(&counts(4), 1);

    const Real eint = press/(eos_data.gamma - 1.0);
    u0(m,IDN,k,j,i) = dtarget*sdetg;
    u0(m,IM1,k,j,i) = 0.0;
    u0(m,IM2,k,j,i) = 0.0;
    u0(m,IM3,k,j,i) = 0.0;
    u0(m,IEN,k,j,i) = (eint + 0.5*b2)*sdetg;
    for (int n=0; n<nscal; ++n) {
      u0(m,nmhd+n,k,j,i) = 0.0;
    }

    w0(m,IDN,k,j,i) = dtarget;
    w0(m,IPR,k,j,i) = press;
    w0(m,IVX,k,j,i) = 0.0;
    w0(m,IVY,k,j,i) = 0.0;
    w0(m,IVZ,k,j,i) = 0.0;
  });
  DevExeSpace().fence();

  if (bbh.restart_precondition_verbose) {
    auto h_counts = Kokkos::create_mirror_view(counts);
    Kokkos::deep_copy(h_counts, counts);
    if (h_counts(1) > 0 || h_counts(2) > 0 || h_counts(3) > 0 ||
        h_counts(4) > 0 || h_counts(5) > 0 || h_counts(7) > 0) {
      std::cout << "dynbbh restart MHD precondition on rank "
                << global_variable::my_rank
                << " repaired=" << h_counts(0)
                << " conserved_replaced=" << h_counts(1)
                << " pressure_set=" << h_counts(2)
                << " pressure_ceiled=" << h_counts(3)
                << " velocity_reset=" << h_counts(4)
                << " nonfinite_conserved_old=" << h_counts(5)
                << " sigma_density_targets=" << h_counts(6)
                << " nonfinite_face_b=" << h_counts(7)
                << " radius_replacements=" << h_counts(8)
                << " nonfinite_only_replacements=" << h_counts(9)
                << " radius=" << radius
                << " rho_floor=" << rho_floor
                << " temp_floor=" << temp_floor
                << " temp_ceil=" << temp_ceil
                << " sigma_max=" << sigma_max
                << " velocity_max=" << velocity_max
                << std::endl;
    }
  }
}

void InitializeDynBBHRestartDynRadiation(Mesh *pm) {
  MeshBlockPack *pmbp = pm->pmb_pack;
  if (pmbp->pdynrad == nullptr || pmbp->pmhd == nullptr ||
      pmbp->pdyngr == nullptr || pmbp->padm == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl << "dynbbh restart radiation initialization requires "
              << "<dyn_radiation>, MHD, Valencia GRMHD, and ADM variables."
              << std::endl;
    std::exit(EXIT_FAILURE);
  }

  pmbp->padm->SetADMVariables(pmbp);
  pmbp->pdynrad->PrepareADMGeometry();
  if (pmbp->pcoord->coord_data.bh_excise) {
    pmbp->pcoord->UpdateExcisionMasks();
  }

  if (pmbp->nmb_thispack == 0) { return; }

  auto &indcs = pm->mb_indcs;
  int &is = indcs.is, &ie = indcs.ie;
  int &js = indcs.js, &je = indcs.je;
  int &ks = indcs.ks, &ke = indcs.ke;
  int nmb1 = pmbp->nmb_thispack - 1;
  int nang1 = pmbp->pdynrad->prgeo->nangles - 1;

  auto &w0 = pmbp->pmhd->w0;
  auto &i0 = pmbp->pdynrad->i0;
  auto &nh_c = pmbp->pdynrad->nh_c;
  auto &norm_to_tet = pmbp->pdynrad->norm_to_tet;
  auto &sqrt_detg_c = pmbp->pdynrad->sqrt_detg_c;
  auto &adm_g_dd_c = pmbp->pdynrad->adm_g_dd_c;
  const bool use_excise = pmbp->pcoord->coord_data.bh_excise;
  auto &excision_floor = pmbp->pcoord->excision_floor;

  const Real density_floor = 10.0*pmbp->pmhd->peos->eos_data.dfloor;
  const Real pressure_floor = pmbp->pmhd->peos->eos_data.pfloor;
  const Real arad = bbh.arad;
  const Real seed_erad_fraction = bbh.restart_seed_erad_fraction;

  par_for("dynbbh_restart_dynrad_i0", DevExeSpace(), 0,nmb1,0,nang1,ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(int m, int n, int k, int j, int i) {
    Real intensity = 0.0;
    bool seed_radiation = true;
    if (use_excise && excision_floor(m,k,j,i)) {
      seed_radiation = false;
    }

    const Real rho = w0(m,IDN,k,j,i);
    const Real pgas = w0(m,IPR,k,j,i);
    if (!(rho > density_floor) || !(pgas > pressure_floor) ||
        !(Kokkos::isfinite(rho)) || !(Kokkos::isfinite(pgas))) {
      seed_radiation = false;
    }

    if (seed_radiation) {
      const Real uu1 = w0(m,IVX,k,j,i);
      const Real uu2 = w0(m,IVY,k,j,i);
      const Real uu3 = w0(m,IVZ,k,j,i);
      const Real q = (adm_g_dd_c(m,0,0,k,j,i)*uu1*uu1 +
                      2.0*adm_g_dd_c(m,0,1,k,j,i)*uu1*uu2 +
                      2.0*adm_g_dd_c(m,0,2,k,j,i)*uu1*uu3 +
                      adm_g_dd_c(m,1,1,k,j,i)*uu2*uu2 +
                      2.0*adm_g_dd_c(m,1,2,k,j,i)*uu2*uu3 +
                      adm_g_dd_c(m,2,2,k,j,i)*uu3*uu3);
      if (Kokkos::isfinite(q) && 1.0 + q > 0.0) {
        const Real uu0 = sqrt(1.0 + q);
        Real u_tet[4];
        u_tet[0] = (norm_to_tet(m,0,0,k,j,i)*uu0 +
                    norm_to_tet(m,0,1,k,j,i)*uu1 +
                    norm_to_tet(m,0,2,k,j,i)*uu2 +
                    norm_to_tet(m,0,3,k,j,i)*uu3);
        u_tet[1] = (norm_to_tet(m,1,0,k,j,i)*uu0 +
                    norm_to_tet(m,1,1,k,j,i)*uu1 +
                    norm_to_tet(m,1,2,k,j,i)*uu2 +
                    norm_to_tet(m,1,3,k,j,i)*uu3);
        u_tet[2] = (norm_to_tet(m,2,0,k,j,i)*uu0 +
                    norm_to_tet(m,2,1,k,j,i)*uu1 +
                    norm_to_tet(m,2,2,k,j,i)*uu2 +
                    norm_to_tet(m,2,3,k,j,i)*uu3);
        u_tet[3] = (norm_to_tet(m,3,0,k,j,i)*uu0 +
                    norm_to_tet(m,3,1,k,j,i)*uu1 +
                    norm_to_tet(m,3,2,k,j,i)*uu2 +
                    norm_to_tet(m,3,3,k,j,i)*uu3);

        const Real un_t = (u_tet[1]*nh_c.d_view(n,1) +
                           u_tet[2]*nh_c.d_view(n,2) +
                           u_tet[3]*nh_c.d_view(n,3));
        const Real n0_f = u_tet[0]*nh_c.d_view(n,0) - un_t;
        const Real temp = pgas/rho;
        const Real urad = seed_erad_fraction*arad*SQR(SQR(temp));
        if (Kokkos::isfinite(n0_f) && n0_f != 0.0 &&
            Kokkos::isfinite(urad) && urad >= 0.0) {
          intensity = sqrt_detg_c(m,k,j,i)*(urad/(4.0*M_PI))/SQR(SQR(n0_f));
          if (!(Kokkos::isfinite(intensity)) || intensity < 0.0) {
            intensity = 0.0;
          }
        }
      }
    }

    i0(m,n,k,j,i) = intensity;
  });
  Kokkos::fence();
}

KOKKOS_INLINE_FUNCTION
Real BondiCavityWeight(Real radius, Real cutoff, Real core_fraction) {
  if (cutoff <= 0.0 || radius >= cutoff) return 1.0;
  Real q=fmax(0.0,(radius/cutoff-core_fraction)/(1.0-core_fraction));
  return q*q*q*(10.0+q*(-15.0+6.0*q));
}

KOKKOS_INLINE_FUNCTION
void BondiCoordinateVelocity(Real x, Real y, Real z, const adm::ADM::ADM_vars &adm,
                            int m, int k, int j, int i, Real omega, Real f,
                            bool initial, Real u[3], Real max_vsq=0.9) {
  // Specify the inertial KS coordinate velocity, pull it back to the rotating
  // coordinates, then convert using the actual local binary ADM fields.
  // The grid rotation cancels between v_coord and beta, even outside r_LC.
  Real vc[3] = {f*x+omega*y, f*y-omega*x, f*z};
  Real v[3];
  for (int a=0; a<3; ++a) v[a]=(vc[a]+adm.beta_u(m,a,k,j,i))/adm.alpha(m,k,j,i);
  Real vsq=0.0;
  for (int a=0; a<3; ++a) {
    for (int b=0; b<3; ++b) vsq += adm.g_dd(m,a,b,k,j,i)*v[a]*v[b];
  }
  if (!Kokkos::isfinite(vsq) || vsq < 0.0) Kokkos::abort("Invalid Bondi velocity norm");
  if (vsq >= max_vsq) {
    // A central monopole is not a solution near either individual horizon.
    // Limit only the initial binary seed, never the prescribed outer inflow.
    if (!initial) Kokkos::abort("Bondi boundary is not timelike; move it farther out");
    Real scale=sqrt(0.9/vsq);
    for (int a=0; a<3; ++a) v[a] *= scale;
    vsq=0.9;
  }
  Real w=1.0/sqrt(1.0-vsq);
  for (int a=0; a<3; ++a) u[a]=w*v[a];
}

KOKKOS_INLINE_FUNCTION
void BondiInflowPrimitive(Real x, Real y, Real z, const adm::ADM::ADM_vars &adm,
                         int m, int k, int j, int i, Real omega,
                         bondi_profile::Solution solution, bool initial,
                         Real &rho, Real &p, Real u[3], Real cavity_radius=0.0,
                         Real cavity_core_fraction=0.0) {
  Real radius=sqrt(x*x+y*y+z*z),ur,ut;
  solution.Sample(radius,rho,p,ur,ut);
  Real f=ur/(ut*fmax(radius,1.0));
  if (initial && cavity_radius>0.0 && radius<cavity_radius)
    f*=BondiCavityWeight(radius,cavity_radius,cavity_core_fraction);
  BondiCoordinateVelocity(x,y,z,adm,m,k,j,i,omega,f,initial,u);
}

// Uniform reservoir or a finite-radius Michel inflow, with total reference M=1.
// cs_inf is the relativistic adiabatic sound speed; r_B = 2 M / cs_inf^2.
void InitializeBinaryReservoir(Mesh *pm, ParameterInput *pin, bool restart) {
  auto pack = pm->pmb_pack;
  if (pack->pdyngr == nullptr || pack->padm == nullptr ||
      pack->pdyngr->eos_policy != DynGRMHD_EOS::eos_ideal) {
    Kokkos::abort("bondi_reservoir requires ideal Valencia MHD and prescribed ADM");
  }
  for (int face=0; face<6; ++face) {
    if (pm->mesh_bcs[face] != BoundaryFlag::user &&
        !(reservoir_test_flat_metric && bbh.frame_omega==0 && face<4 &&
          pm->mesh_bcs[face]==BoundaryFlag::periodic)) {
      Kokkos::abort("bondi_reservoir requires six user reservoir boundaries");
    }
  }
  reservoir_density = pin->GetOrAddReal("problem","rho_inf",1.0);
  Real rb = pin->GetOrAddReal("problem","r_bondi",2.0e4);
  Real cs = pin->GetOrAddReal("problem","cs_inf",sqrt(2.0/rb));
  Real gamma = pack->pmhd->peos->eos_data.gamma;
  if (!(reservoir_density > 0.0 && std::isfinite(reservoir_density) &&
        rb > 0.0 && std::isfinite(rb) && cs > 0.0 && std::isfinite(cs) &&
        cs*cs < gamma-1.0 && cs < 1.0)) {
    Kokkos::abort("Invalid Bondi reservoir density or sound speed");
  }
  reservoir_pressure = reservoir_density*cs*cs/(gamma*(1.0-cs*cs/(gamma-1.0)));
  reservoir_bz = pin->GetOrAddReal("problem","b_inf",0.0);
  if (!std::isfinite(reservoir_bz)) Kokkos::abort("b_inf must be finite");
  if (pin->DoesParameterExist("problem","beta_inf")) {
    Real beta=pin->GetReal("problem","beta_inf");
    if (use_bondi_inflow || reservoir_bz!=0.0 || !(beta>0.0 && std::isfinite(beta)))
      Kokkos::abort("beta_inf requires a uniform reservoir and no explicit b_inf");
    // Ambient asymptotic normalization: p_mag=B^2/2 in the rest frame.
    reservoir_bz=std::sqrt(2.0*reservoir_pressure/beta);
  }
  reservoir_perturbation=pin->GetOrAddReal("problem","reservoir_pressure_perturbation",0.0);
  if (!(reservoir_perturbation>=0.0 && reservoir_perturbation<1.0))
    Kokkos::abort("Invalid reservoir pressure perturbation amplitude");
  if (use_bondi_inflow) {
    Real rc=pin->GetOrAddReal("problem","r_crit",8.0);
    Real kadi=pin->GetOrAddReal("problem","k_adi",1.0);
    if (!(std::isfinite(rc) && rc > 0.5*(1.0/(gamma-1.0)+3.0) &&
          std::isfinite(kadi) && kadi > 0.0)) Kokkos::abort("Invalid Michel parameters");
    inflow_solution.Initialize(gamma,kadi,rc);
    Real hinf=sqrt(inflow_solution.c2);
    if (!(std::isfinite(hinf) && hinf > 1.0)) {
      Kokkos::abort("Michel parameters do not define a positive-temperature reservoir");
    }
    Real tinf=(hinf-1.0)/(inflow_solution.n+1.0);
    cs=sqrt(gamma*tinf/hinf);
    reservoir_density=pow(tinf/kadi,inflow_solution.n);
    reservoir_pressure=reservoir_density*tinf;
  }
  if (global_variable::my_rank == 0) {
    std::cout << "Binary Bondi reservoir: r_B=" << 2.0/(cs*cs)
              << " r_B/a=" << 2.0/(cs*cs*bbh.sep)
              << " Omega_frame=" << bbh.frame_omega
              << " corotating=" << bbh.corotating
              << " single_black_hole=" << bbh.single_black_hole
              << " M_total=1 boundary=" << (use_bondi_inflow ? "Michel" : "ambient")
              << std::endl;
  }
  cache_bondi_boundary=pin->GetOrAddBoolean("problem","bondi_cache_boundary",true);
  auto &cfg=pack->pcoord->coord_data;
  std::string boundary=pin->GetOrAddString("problem","reservoir_boundary","fixed");
  if(boundary!="fixed"&&boundary!="characteristic") Kokkos::abort("Unknown reservoir boundary");
  cfg.characteristic_reservoir=boundary=="characteristic";
  cfg.reservoir_ghost_ct=pin->GetOrAddBoolean("problem","reservoir_ghost_ct",false);
  if(cfg.reservoir_ghost_ct&&!cfg.characteristic_reservoir)
    Kokkos::abort("reservoir_ghost_ct requires characteristic reservoir");
  cfg.reservoir_trace_order=pin->GetOrAddInteger("problem","reservoir_trace_order",3);
  if(cfg.reservoir_trace_order<1||cfg.reservoir_trace_order>3)Kokkos::abort("Reservoir trace order must be 1, 2 or 3");
  if(cfg.characteristic_reservoir) {
    if(use_bondi_inflow||pack->pmhd->nscalars!=0||pin->GetString("mhd","rsolver")!="hlle")
      Kokkos::abort("Characteristic reservoir requires uniform ideal MHD, HLLE, no scalars");
    for(int f=0;f<6;++f)cfg.reservoir_user_faces[f]=pm->mesh_bcs[f]==BoundaryFlag::user;
    cfg.reservoir_rho=reservoir_density;cfg.reservoir_p=reservoir_pressure;
    cfg.reservoir_bz=reservoir_bz;cfg.reservoir_omega=bbh.frame_omega;
    cfg.reservoir_min[0]=pm->mesh_size.x1min;cfg.reservoir_max[0]=pm->mesh_size.x1max;
    cfg.reservoir_min[1]=pm->mesh_size.x2min;cfg.reservoir_max[1]=pm->mesh_size.x2max;
    cfg.reservoir_min[2]=pm->mesh_size.x3min;cfg.reservoir_max[2]=pm->mesh_size.x3max;
    pack->pcoord->characteristic_counts=DvceArray1D<int>("characteristic_counts",2);
    Kokkos::deep_copy(pack->pcoord->characteristic_counts,0);
    if(global_variable::my_rank==0) std::cout<<(cfg.reservoir_ghost_ct ? "Characteristic reservoir: reconstructed ghosts + native CT" :
      "Experimental characteristic reservoir face flux enabled")<<std::endl;
  }

  Real cavity_radius=pin->GetOrAddReal("problem","bondi_cavity_radius",0.0);
  Real cavity_core_fraction=pin->GetOrAddReal("problem","bondi_cavity_core_fraction",0.0);
  Real cavity_fraction=pin->GetOrAddReal("problem","bondi_cavity_fraction",0.0);
  if (!(std::isfinite(cavity_radius) && cavity_radius >= 0.0 &&
        std::isfinite(cavity_core_fraction) && cavity_core_fraction >= 0.0 &&
        cavity_core_fraction < 1.0 && std::isfinite(cavity_fraction) && cavity_fraction >= 0.0 && cavity_fraction <= 1.0)) {
    Kokkos::abort("Invalid Bondi initial cavity parameters");
  }
  if (cavity_radius > 0.0 && !use_bondi_inflow) {
    Kokkos::abort("Bondi initial cavity requires bondi_inflow");
  }
  Real cavity_density=0.0;
  if (cavity_radius > 0.0) {
    Real cp, cur, cut;
    inflow_solution.Sample(cavity_radius,cavity_density,cp,cur,cut);
    cavity_density = std::max(cavity_density*cavity_fraction,
                              pin->GetReal("mhd","dfloor"));
  }
  pack->padm->SetADMVariables(pack);
  if (pack->pcoord->coord_data.bh_excise) pack->pcoord->UpdateExcisionMasks();
  if (restart) return;
  auto ind = pm->mb_indcs;
  auto w = pack->pmhd->w0;
  auto adm = pack->padm->adm;
  auto size = pack->pmb->mb_size;
  auto b = pack->pmhd->b0;
  auto bc = pack->pmhd->bcc0;
  int n1=ind.nx1+2*ind.ng, n2=ind.nx2+2*ind.ng, n3=ind.nx3+2*ind.ng;
  Real rho=reservoir_density, pressure=reservoir_pressure, bz=reservoir_bz;
  Real initial_pfloor=pin->GetReal("mhd","pfloor");
  bool inflow=use_bondi_inflow;
  auto solution=inflow_solution;
  Real omega=bbh.frame_omega;
  Real perturbation=reservoir_perturbation;
  Real pulse=pin->GetOrAddReal("problem","reservoir_test_pulse",0.0);
  Real pulse_z=pin->GetOrAddReal("problem","reservoir_test_pulse_z",4.0);
  Real pulse_width=pin->GetOrAddReal("problem","reservoir_test_pulse_width",1.0);
  std::string pulse_mode=pin->GetOrAddString("problem","reservoir_test_pulse_mode","acoustic");
  bool alfven=pulse_mode=="alfven",compact=pulse_mode=="acoustic3d"||pulse_mode=="entropy";
  bool entropy=pulse_mode=="entropy";
  Real pulse_x=pin->GetOrAddReal("problem","reservoir_test_pulse_x",0.0);
  Real pulse_y=pin->GetOrAddReal("problem","reservoir_test_pulse_y",0.0);
  Real pulse_transverse=pin->GetOrAddReal("problem","reservoir_test_pulse_transverse",3.0);
  if(!(std::isfinite(pulse)&&pulse>=0&&pulse<.1&&pulse_width>0&&pulse_transverse>0) ||
      (!compact&&pulse_mode!="acoustic"&&pulse_mode!="alfven") || (pulse>0&&!reservoir_test_flat_metric))
    Kokkos::abort("Invalid flat reservoir pulse test configuration");
  if(pulse>0&&restart)Kokkos::abort("Pulse tests are fresh-start only");
  Real enthalpy_density=rho+gamma*pressure/(gamma-1);
  Real inertia=sqrt(enthalpy_density+bz*bz);

  Kokkos::Random_XorShift64_Pool<> reservoir_random(12345+global_variable::my_rank);
  int nv=pack->pmhd->nmhd+pack->pmhd->nscalars;
  Kokkos::deep_copy(b.x1f,0.0);
  Kokkos::deep_copy(b.x2f,0.0);
  Kokkos::deep_copy(b.x3f,bz);
  if(pulse>0&&alfven) {
    par_for("flat_alfven_Bx",DevExeSpace(),0,pack->nmb_thispack-1,0,n3-1,0,n2-1,0,n1,
      KOKKOS_LAMBDA(int m,int k,int j,int i){
        auto box=size.d_view(m);Real z=CellCenterX(k-ind.ks,ind.nx3,box.x3min,box.x3max);
        Real q=(z-pulse_z)/pulse_width;
        b.x1f(m,k,j,i)=-inertia*pulse*exp(-q*q);
      });
  }
  par_for("binary_reservoir_init",DevExeSpace(),0,pack->nmb_thispack-1,
          0,n3-1,0,n2-1,0,n1-1,
    KOKKOS_LAMBDA(int m,int k,int j,int i) {
      for (int n=0; n<nv; ++n) w(m,n,k,j,i)=0.0;
      w(m,IDN,k,j,i)=rho;
      w(m,IPR,k,j,i)=pressure;
      if (!inflow) {
        auto s=size.d_view(m);
        Real x=CellCenterX(i-ind.is,ind.nx1,s.x1min,s.x1max);
        Real y=CellCenterX(j-ind.js,ind.nx2,s.x2min,s.x2max);
        Real z=CellCenterX(k-ind.ks,ind.nx3,s.x3min,s.x3max);
        Real u[3];
        // Inertial-coordinate rest is impossible where its time direction is
        // spacelike. Limit only those initial cells, not valid exterior rest data.
        BondiCoordinateVelocity(x,y,z,adm,m,k,j,i,omega,0.0,true,u,1.0);
        for (int a=0;a<3;++a) w(m,IVX+a,k,j,i)=u[a];
        // Perturb active gas only; external reservoir ghosts stay unperturbed
        // even before the first boundary callback. Internal ghosts are exchanged.
        if (perturbation>0.0 && i>=ind.is && i<=ind.ie &&
            j>=ind.js && j<=ind.je && k>=ind.ks && k<=ind.ke) {
          auto random=reservoir_random.get_state();
          w(m,IPR,k,j,i)*=1.0+perturbation*(2.0*random.frand()-1.0);
          reservoir_random.free_state(random);
        }
      }
      if (inflow) {
        auto s=size.d_view(m);
        Real x=CellCenterX(i-ind.is,ind.nx1,s.x1min,s.x1max);
        Real y=CellCenterX(j-ind.js,ind.nx2,s.x2min,s.x2max);
        Real z=CellCenterX(k-ind.ks,ind.nx3,s.x3min,s.x3max);
        Real d, p, u[3];
        BondiInflowPrimitive(x,y,z,adm,m,k,j,i,omega,solution,true,d,p,u,cavity_radius,
                            cavity_core_fraction);
        Real radius=sqrt(x*x+y*y+z*z);
        if (cavity_radius > 0.0 && radius < cavity_radius) {
          Real blend=BondiCavityWeight(radius,cavity_radius,cavity_core_fraction);
          d=cavity_density+blend*(d-cavity_density);
          p=fmax(solution.k*pow(d,solution.gamma),initial_pfloor);
        }
        w(m,IDN,k,j,i)=d;
        w(m,IPR,k,j,i)=p;
        for (int a=0; a<3; ++a) w(m,IVX+a,k,j,i)=u[a];
      }
      if(pulse>0) {
        auto box=size.d_view(m);Real z=CellCenterX(k-ind.ks,ind.nx3,box.x3min,box.x3max);
        Real q=(z-pulse_z)/pulse_width,amp=pulse*exp(-q*q);
        if(compact) {
          Real x=CellCenterX(i-ind.is,ind.nx1,box.x1min,box.x1max);
          Real y=CellCenterX(j-ind.js,ind.nx2,box.x2min,box.x2max);
          Real r2=SQR((x-pulse_x)/pulse_transverse)+SQR((y-pulse_y)/pulse_transverse);
          Real z2=q*q;
          // Smooth finite support: no initial perturbation in physical ghosts.
          amp=(r2<1&&z2<1)?pulse*exp(2-1/(1-r2)-1/(1-z2)):0;
        }
        if(alfven)w(m,IVX,k,j,i)=amp/sqrt(1-amp*amp);
        else if(entropy)w(m,IDN,k,j,i)=rho*(1+amp);
        else {
          w(m,IDN,k,j,i)=rho*(1+amp);w(m,IPR,k,j,i)=pressure*(1+gamma*amp);
          Real velocity=cs*amp;w(m,IVZ,k,j,i)=velocity/sqrt(1-velocity*velocity);
        }
      }
      bc(m,IBX,k,j,i)=pulse>0&&alfven?-inertia*pulse*exp(-SQR((CellCenterX(k-ind.ks,ind.nx3,size.d_view(m).x3min,size.d_view(m).x3max)-pulse_z)/pulse_width)):0.0;
      bc(m,IBY,k,j,i)=0.0;
      bc(m,IBZ,k,j,i)=bz;
    });
  pack->pdyngr->PrimToConInit(0,n1-1,0,n2-1,0,n3-1);
}

void BinaryReservoirBoundary(Mesh *pm) {
  auto pack=pm->pmb_pack;
  auto ind=pm->mb_indcs;
  auto size=pack->pmb->mb_size;
  auto bounds=pm->mesh_size;
  // Flat wave benchmarks may use periodic transverse faces. Do not overwrite
  // their exchanged ghosts with ambient data.
  if(reservoir_test_flat_metric) {
    if(pm->mesh_bcs[0]==BoundaryFlag::periodic){bounds.x1min=-1e100;bounds.x1max=1e100;}
    if(pm->mesh_bcs[2]==BoundaryFlag::periodic){bounds.x2min=-1e100;bounds.x2max=1e100;}
  }
  auto w=pack->pmhd->w0;
  auto adm=pack->padm->adm;
  auto b=pack->pmhd->b0;
  Real bz=reservoir_bz;
  Real rho=reservoir_density, pressure=reservoir_pressure;
  bool inflow=use_bondi_inflow;
  auto solution=inflow_solution;
  Real omega=bbh.frame_omega;
  int nv=pack->pmhd->nmhd+pack->pmhd->nscalars;
  int n1=ind.nx1+2*ind.ng, n2=ind.nx2+2*ind.ng, n3=ind.nx3+2*ind.ng;
  // Cache only stationary analytic boundary primitives. The ADM callback
  // invalidates them whenever geometry or the local block layout changes.
  bool cached=inflow && cache_bondi_boundary && !pack->padm->is_dynamic;
  bool refresh=false;
  DvceArray5D<Real> boundary_state;
  std::shared_ptr<BondiBoundaryCache> cache;
  if (cached) {
    if (!pm->pgen->user_boundary_data) {
      pm->pgen->user_boundary_data=std::make_shared<BondiBoundaryCache>();
    }
    cache=std::static_pointer_cast<BondiBoundaryCache>(pm->pgen->user_boundary_data);
    refresh=cache->revision != bondi_metric_revision ||
            cache->primitive.extent(0) != static_cast<size_t>(pack->nmb_thispack);
    if (refresh) {
      Kokkos::realloc(cache->primitive,pack->nmb_thispack,5,n3,n2,n1);
    }
    boundary_state=cache->primitive;
  }
  // User BFieldBCs leaves magnetic ghost faces to this callback. Fill only
  // exterior faces; normal faces on the physical boundary remain CT-evolved.
  par_for("binary_reservoir_b_bc",DevExeSpace(),0,pack->nmb_thispack-1,
          0,n3,0,n2,0,n1,
    KOKKOS_LAMBDA(int m,int k,int j,int i) {
      auto s=size.d_view(m);
      Real x=CellCenterX(i-ind.is,ind.nx1,s.x1min,s.x1max);
      Real y=CellCenterX(j-ind.js,ind.nx2,s.x2min,s.x2max);
      Real z=CellCenterX(k-ind.ks,ind.nx3,s.x3min,s.x3max);
      Real xf=LeftEdgeX(i-ind.is,ind.nx1,s.x1min,s.x1max);
      Real yf=LeftEdgeX(j-ind.js,ind.nx2,s.x2min,s.x2max);
      Real zf=LeftEdgeX(k-ind.ks,ind.nx3,s.x3min,s.x3max);
      if (k<n3 && j<n2 &&
          (xf<bounds.x1min || xf>bounds.x1max || y<bounds.x2min || y>bounds.x2max ||
           z<bounds.x3min || z>bounds.x3max)) b.x1f(m,k,j,i)=0.0;
      if (k<n3 && i<n1 &&
          (x<bounds.x1min || x>bounds.x1max || yf<bounds.x2min || yf>bounds.x2max ||
           z<bounds.x3min || z>bounds.x3max)) b.x2f(m,k,j,i)=0.0;
      if (j<n2 && i<n1 &&
          (x<bounds.x1min || x>bounds.x1max || y<bounds.x2min || y>bounds.x2max ||
           zf<bounds.x3min || zf>bounds.x3max)) b.x3f(m,k,j,i)=bz;
    });
  // Only exterior ghost cells. Internal/AMR boundaries retain their exchanged data.
  par_for("binary_reservoir_bc",DevExeSpace(),0,pack->nmb_thispack-1,0,n3-1,0,n2-1,0,n1-1,
    KOKKOS_LAMBDA(int m,int k,int j,int i) {
      auto s=size.d_view(m);
      Real x=CellCenterX(i-ind.is,ind.nx1,s.x1min,s.x1max);
      Real y=CellCenterX(j-ind.js,ind.nx2,s.x2min,s.x2max);
      Real z=CellCenterX(k-ind.ks,ind.nx3,s.x3min,s.x3max);
      if (x<bounds.x1min || x>bounds.x1max || y<bounds.x2min || y>bounds.x2max ||
          z<bounds.x3min || z>bounds.x3max) {
        for (int n=0; n<nv; ++n) w(m,n,k,j,i)=0.0;
        w(m,IDN,k,j,i)=rho;
        w(m,IPR,k,j,i)=pressure;
        if (!inflow) {
          Real u[3];
          BondiCoordinateVelocity(x,y,z,adm,m,k,j,i,omega,0.0,false,u,1.0);
          for (int a=0;a<3;++a) w(m,IVX+a,k,j,i)=u[a];
        }
        if (inflow) {
          Real d, p, u[3];
          if (cached && !refresh) {
            d=boundary_state(m,0,k,j,i); p=boundary_state(m,1,k,j,i);
            for (int a=0; a<3; ++a) u[a]=boundary_state(m,2+a,k,j,i);
          } else {
            BondiInflowPrimitive(x,y,z,adm,m,k,j,i,omega,solution,false,d,p,u);
            if (cached) {
              boundary_state(m,0,k,j,i)=d; boundary_state(m,1,k,j,i)=p;
              for (int a=0; a<3; ++a) boundary_state(m,2+a,k,j,i)=u[a];
            }
          }
          w(m,IDN,k,j,i)=d;
          w(m,IPR,k,j,i)=p;
          for (int a=0; a<3; ++a) w(m,IVX+a,k,j,i)=u[a];
        }
      }
    });
  // Primitive-to-conserved conversion restricted to each exterior ghost slab.
  // The EOS filter overload keeps active cells and exchanged internal ghosts intact.
  // Implemented through the general masked conversion entry point below.
  if (cached) cache->revision=bondi_metric_revision;
  pack->pdyngr->PrimToConBoundary();
  if (pm->multilevel) {
    // Coarse-neighbor prolongation also reads coarse ghost corners at physical
    // faces. No MPI neighbor fills these slots. Populate them from the analytic
    // fine ghost state, rather than retaining values from a previous hierarchy.
    auto cons=pack->pmhd->u0;
    auto coarse=pack->pmhd->coarse_u0;
    int hg=ind.ng/2;
    par_for("bondi_coarse_boundary",DevExeSpace(),0,pack->nmb_thispack-1,
            ind.cks-hg,ind.cke+hg,ind.cjs-hg,ind.cje+hg,ind.cis-hg,ind.cie+hg,
      KOKKOS_LAMBDA(int m,int k,int j,int i) {
        auto s=size.d_view(m);
        Real x=CellCenterX(i-ind.cis,ind.cnx1,s.x1min,s.x1max);
        Real y=CellCenterX(j-ind.cjs,ind.cnx2,s.x2min,s.x2max);
        Real z=CellCenterX(k-ind.cks,ind.cnx3,s.x3min,s.x3max);
        if (x>=bounds.x1min && x<=bounds.x1max && y>=bounds.x2min &&
            y<=bounds.x2max && z>=bounds.x3min && z<=bounds.x3max) return;
        int fi=2*(i-ind.cis)+ind.is;
        int fj=2*(j-ind.cjs)+ind.js;
        int fk=2*(k-ind.cks)+ind.ks;
        for (int n=0; n<nv; ++n) {
          coarse(m,n,k,j,i)=0.125*(cons(m,n,fk,fj,fi)+cons(m,n,fk,fj,fi+1)+
              cons(m,n,fk,fj+1,fi)+cons(m,n,fk,fj+1,fi+1)+
              cons(m,n,fk+1,fj,fi)+cons(m,n,fk+1,fj,fi+1)+
              cons(m,n,fk+1,fj+1,fi)+cons(m,n,fk+1,fj+1,fi+1));
        }
      });
  }
}

template <typename ADMVars>
KOKKOS_INLINE_FUNCTION
void StoreADMVariables(ADMVars adm_vars, const int m, const int k,
                       const int j, const int i, const struct three_metric &met3) {
  adm_vars.g_dd(m,0,0,k,j,i) = met3.gxx;
  adm_vars.g_dd(m,0,1,k,j,i) = met3.gxy;
  adm_vars.g_dd(m,0,2,k,j,i) = met3.gxz;
  adm_vars.g_dd(m,1,1,k,j,i) = met3.gyy;
  adm_vars.g_dd(m,1,2,k,j,i) = met3.gyz;
  adm_vars.g_dd(m,2,2,k,j,i) = met3.gzz;

  adm_vars.vK_dd(m,0,0,k,j,i) = met3.kxx;
  adm_vars.vK_dd(m,0,1,k,j,i) = met3.kxy;
  adm_vars.vK_dd(m,0,2,k,j,i) = met3.kxz;
  adm_vars.vK_dd(m,1,1,k,j,i) = met3.kyy;
  adm_vars.vK_dd(m,1,2,k,j,i) = met3.kyz;
  adm_vars.vK_dd(m,2,2,k,j,i) = met3.kzz;

  adm_vars.psi4(m,k,j,i) = cbrt(adm::SpatialDet(met3.gxx,met3.gxy,met3.gxz,
                                             met3.gyy,met3.gyz,met3.gzz));
  adm_vars.alpha(m,k,j,i) = met3.alpha;
  adm_vars.beta_u(m,0,k,j,i) = met3.betax;
  adm_vars.beta_u(m,1,k,j,i) = met3.betay;
  adm_vars.beta_u(m,2,k,j,i) = met3.betaz;
}

void SetADMVariablesToBBH(MeshBlockPack *pmbp) {
  ++bondi_metric_revision;  // Includes mesh redistribution and restart initialization.
  const Real tt = bbh.corotating ? 0.0 : pmbp->pmesh->time;
  auto &adm = pmbp->padm->adm;
  auto &size = pmbp->pmb->mb_size;
  auto &indcs = pmbp->pmesh->mb_indcs;
  int &ng = indcs.ng;
  int is = indcs.is, js = indcs.js, ks = indcs.ks;
  int ie = indcs.ie, je = indcs.je, ke = indcs.ke;
  int nmb = pmbp->nmb_thispack;
  int n1 = indcs.nx1 + 2*ng;
  int n2 = (indcs.nx2 > 1) ? (indcs.nx2 + 2*ng) : 1;
  int n3 = (indcs.nx3 > 1) ? (indcs.nx3 + 2*ng) : 1;

  auto &coord = pmbp->pcoord->coord_data;
  if(reservoir_test_flat_metric) {
    Real omega=bbh.frame_omega;
    par_for("flat_reservoir_validation_ADM",DevExeSpace(),0,nmb-1,0,n3-1,0,n2-1,0,n1-1,
      KOKKOS_LAMBDA(int m,int k,int j,int i) {
        auto box=size.d_view(m);
        Real x=CellCenterX(i-is,indcs.nx1,box.x1min,box.x1max);
        Real y=CellCenterX(j-js,indcs.nx2,box.x2min,box.x2max);
        adm.alpha(m,k,j,i)=1;adm.psi4(m,k,j,i)=1;
        adm.beta_u(m,0,k,j,i)=-omega*y;adm.beta_u(m,1,k,j,i)=omega*x;adm.beta_u(m,2,k,j,i)=0;
        for(int a=0;a<3;++a)for(int b=a;b<3;++b){adm.g_dd(m,a,b,k,j,i)=a==b?1:0;adm.vK_dd(m,a,b,k,j,i)=0;}
      });
    return;
  }

  bbh_traj_state traj = find_traj_state(tt);
  auto bbh_ = bbh;

  // update punc location for excision
  coord.punc_0[0] = traj.q[X1];
  coord.punc_0[1] = traj.q[Y1];
  coord.punc_0[2] = traj.q[Z1];
  coord.punc_1[0] = traj.q[X2];
  coord.punc_1[1] = traj.q[Y2];
  coord.punc_1[2] = traj.q[Z2];
  Real m1_ex = traj.q[M1T];
  Real m2_ex = traj.q[M2T];
  Real a1x_ex = traj.q[AX1] * m1_ex;
  Real a1y_ex = traj.q[AY1] * m1_ex;
  Real a1z_ex = traj.q[AZ1] * m1_ex;
  Real a2x_ex = traj.q[AX2] * m2_ex;
  Real a2y_ex = traj.q[AY2] * m2_ex;
  Real a2z_ex = traj.q[AZ2] * m2_ex;
  coord.punc_0_spin[0] = a1x_ex;
  coord.punc_0_spin[1] = a1y_ex;
  coord.punc_0_spin[2] = a1z_ex;
  coord.punc_1_spin[0] = a2x_ex;
  coord.punc_1_spin[1] = a2y_ex;
  coord.punc_1_spin[2] = a2z_ex;
  coord.punc_0_vel[0] = traj.q[VX1];
  coord.punc_0_vel[1] = traj.q[VY1];
  coord.punc_0_vel[2] = traj.q[VZ1];
  coord.punc_1_vel[0] = traj.q[VX2];
  coord.punc_1_vel[1] = traj.q[VY2];
  coord.punc_1_vel[2] = traj.q[VZ2];
  Real rH1 = HorizonRadiusFromMassAndChi(m1_ex, traj.q[AX1], traj.q[AY1],
                                         traj.q[AZ1]);
  Real rH2 = HorizonRadiusFromMassAndChi(m2_ex, traj.q[AX2], traj.q[AY2],
                                         traj.q[AZ2]);
  coord.punc_0_rad = SmoothExcisionRadiusToHorizon(
      bbh_.puncture_excise_rad1, rH1, tt - bbh_.puncture_excise_shrink_start_time,
      bbh_.puncture_excise_shrink_timescale,
      bbh_.puncture_excise_to_horizon, bbh_.puncture_excise_shrink_to_horizon);
  coord.punc_1_rad = SmoothExcisionRadiusToHorizon(
      bbh_.puncture_excise_rad2, rH2, tt - bbh_.puncture_excise_shrink_start_time,
      bbh_.puncture_excise_shrink_timescale,
      bbh_.puncture_excise_to_horizon, bbh_.puncture_excise_shrink_to_horizon);
  if (bbh_.puncture_excise_cap_to_horizon &&
      !bbh_.puncture_excise_to_horizon &&
      !bbh_.puncture_excise_shrink_to_horizon) {
    coord.punc_0_rad = std::min(coord.punc_0_rad, rH1);
    coord.punc_1_rad = std::min(coord.punc_1_rad, rH2);
  }
  if (pmbp->pcoord->coord_data.bh_excise &&
      pmbp->pcoord->coord_data.excision_scheme == ExcisionScheme::puncture &&
      !(pmbp->pmesh->pzoom != nullptr && (pmbp->pmesh->pzoom->zstate.zone > 0 ||
        (pmbp->pmesh->ncycle > 0 && pmbp->pmesh->pzoom->zstate.id == 0)))) {
    CheckPunctureExcisionResolution(pmbp, traj, coord.punc_0_rad,
                                    coord.punc_1_rad, "ADM update");
  }

  if (bbh_.metric_derivative_method == MetricDerivativeMethod::ad) {
    par_for("update_adm_vars_ad", DevExeSpace(), 0,nmb-1,0,(n3-1),0,(n2-1),0,(n1-1),
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);

      struct four_metric met4;
      struct three_metric met3;
      get_metric_and_derivatives(tt, x1v, x2v, x3v, met4, traj.q, traj.dq, bbh_);
      four_metric_to_three_metric(met4, met3);
      StoreADMVariables(adm, m, k, j, i, met3);
    });
    return;
  }

  Real traj_m[NTRAJ], traj_p[NTRAJ];
  Real hm = bbh_.metric_fd_step, hp = bbh_.metric_fd_step;

  if (bbh_.use_traj_table && !bbh_table.t.empty()) {
    Real tmin = bbh_table.t.front();
    Real tmax = bbh_table.t.back();
    hm = fmin(metric_fd_step, fmax(tt - tmin, 0.0));
    hp = fmin(metric_fd_step, fmax(tmax - tt, 0.0));
    if (hm == 0.0 && hp == 0.0) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "trajectory table does not bracket time for metric derivatives"
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
  }
  if (hm > 0.0) {
    find_traj_t(tt - hm, traj_m);
  } else {
    for (int n = 0; n < NTRAJ; ++n) traj_m[n] = traj.q[n];
  }
  if (hp > 0.0) {
    find_traj_t(tt + hp, traj_p);
  } else {
    for (int n = 0; n < NTRAJ; ++n) traj_p[n] = traj.q[n];
  }

  par_for("update_adm_vars_fd", DevExeSpace(), 0,nmb-1,0,(n3-1),0,(n2-1),0,(n1-1),
  KOKKOS_LAMBDA(int m, int k, int j, int i) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);

    struct four_metric met4;
    struct three_metric met3;
    numerical_4metric(tt, x1v, x2v, x3v, met4, traj_m, traj.q, traj_p,
                      hm, hp, bbh_);

    four_metric_to_three_metric(met4, met3);
    StoreADMVariables(adm, m, k, j, i, met3);
  });
  return;
}

KOKKOS_INLINE_FUNCTION
int four_metric_to_three_metric(const struct four_metric &met,
                                struct three_metric &gam)
{
  /* Check determinant first */
  gam.gxx = met.g.xx;
  gam.gxy = met.g.xy;
  gam.gxz = met.g.xz;
  gam.gyy = met.g.yy;
  gam.gyz = met.g.yz;
  gam.gzz = met.g.zz;

  Real det = adm::SpatialDet(gam.gxx, gam.gxy, gam.gxz,
                                   gam.gyy, gam.gyz, gam.gzz);

  /* If determinant is not >0  something is wrong with the metric */
  /* This could occur during the transition to merger at certain points so here we restart to Minkowski */
  if (!(det > 0)) {
    det = 1.0;
    gam.gxx = 1.0;
    gam.gxy = 0.0;
    gam.gxz = 0.0;
    gam.gyy = 1.0;
    gam.gyz = 0.0;
    gam.gzz = 1.0;
    Real betadownx = 0.0;
    Real betadowny = 0.0;
    Real betadownz = 0.0;

    Real dbetadownxx = 0.0;
    Real dbetadownyx = 0.0;
    Real dbetadownzx = 0.0;

    Real dbetadownxy = 0.0;
    Real dbetadownyy = 0.0;
    Real dbetadownzy = 0.0;

    Real dbetadownxz = 0.0;
    Real dbetadownyz = 0.0;
    Real dbetadownzz = 0.0;

    Real dtgxx = 0.0;
    Real dtgxy = 0.0;
    Real dtgxz = 0.0;
    Real dtgyy = 0.0;
    Real dtgyz = 0.0;
    Real dtgzz = 0.0;

    Real dgxxx = 0.0;
    Real dgxyx = 0.0;
    Real dgxzx = 0.0;
    Real dgyyx = 0.0;
    Real dgyzx = 0.0;
    Real dgzzx = 0.0;

    Real dgxxy = 0.0;
    Real dgxyy = 0.0;
    Real dgxzy = 0.0;
    Real dgyyy = 0.0;
    Real dgyzy = 0.0;
    Real dgzzy = 0.0;

    Real dgxxz = 0.0;
    Real dgxyz = 0.0;
    Real dgxzz = 0.0;
    Real dgyyz = 0.0;
    Real dgyzz = 0.0;
    Real dgzzz = 0.0;

    Real idetgxx = -gam.gyz * gam.gyz + gam.gyy * gam.gzz;
    Real idetgxy = gam.gxz * gam.gyz - gam.gxy * gam.gzz;
    Real idetgxz = -(gam.gxz * gam.gyy) + gam.gxy * gam.gyz;
    Real idetgyy = -gam.gxz * gam.gxz + gam.gxx * gam.gzz;
    Real idetgyz = gam.gxy * gam.gxz - gam.gxx * gam.gyz;
    Real idetgzz = -gam.gxy * gam.gxy + gam.gxx * gam.gyy;
    Real invgxx = idetgxx / det;
    Real invgxy = idetgxy / det;
    Real invgxz = idetgxz / det;
    Real invgyy = idetgyy / det;
    Real invgyz = idetgyz / det;
    Real invgzz = idetgzz / det;

    gam.betax = 0.0;
    gam.betay = 0.0;
    gam.betaz = 0.0;

    gam.alpha = 1.0;
    gam.kxx = 0.0;
    gam.kxy = 0.0;
    gam.kxz = 0.0;
    gam.kyy = 0.0;
    gam.kyz = 0.0;
    gam.kzz = 0.0;

  } else {

    /* Compute components if detg is not <0 */
    Real betadownx = met.g.tx;
    Real betadowny = met.g.ty;
    Real betadownz = met.g.tz;

    Real dbetadownxx = met.g_x.tx;
    Real dbetadownyx = met.g_x.ty;
    Real dbetadownzx = met.g_x.tz;

    Real dbetadownxy = met.g_y.tx;
    Real dbetadownyy = met.g_y.ty;
    Real dbetadownzy = met.g_y.tz;

    Real dbetadownxz = met.g_z.tx;
    Real dbetadownyz = met.g_z.ty;
    Real dbetadownzz = met.g_z.tz;

    Real dtgxx = met.g_t.xx;
    Real dtgxy = met.g_t.xy;
    Real dtgxz = met.g_t.xz;
    Real dtgyy = met.g_t.yy;
    Real dtgyz = met.g_t.yz;
    Real dtgzz = met.g_t.zz;

    Real dgxxx = met.g_x.xx;
    Real dgxyx = met.g_x.xy;
    Real dgxzx = met.g_x.xz;
    Real dgyyx = met.g_x.yy;
    Real dgyzx = met.g_x.yz;
    Real dgzzx = met.g_x.zz;

    Real dgxxy = met.g_y.xx;
    Real dgxyy = met.g_y.xy;
    Real dgxzy = met.g_y.xz;
    Real dgyyy = met.g_y.yy;
    Real dgyzy = met.g_y.yz;
    Real dgzzy = met.g_y.zz;

    Real dgxxz = met.g_z.xx;
    Real dgxyz = met.g_z.xy;
    Real dgxzz = met.g_z.xz;
    Real dgyyz = met.g_z.yy;
    Real dgyzz = met.g_z.yz;
    Real dgzzz = met.g_z.zz;

    Real idetgxx = -gam.gyz * gam.gyz + gam.gyy * gam.gzz;
    Real idetgxy = gam.gxz * gam.gyz - gam.gxy * gam.gzz;
    Real idetgxz = -(gam.gxz * gam.gyy) + gam.gxy * gam.gyz;
    Real idetgyy = -gam.gxz * gam.gxz + gam.gxx * gam.gzz;
    Real idetgyz = gam.gxy * gam.gxz - gam.gxx * gam.gyz;
    Real idetgzz = -gam.gxy * gam.gxy + gam.gxx * gam.gyy;

    Real invgxx = idetgxx / det;
    Real invgxy = idetgxy / det;
    Real invgxz = idetgxz / det;
    Real invgyy = idetgyy / det;
    Real invgyz = idetgyz / det;
    Real invgzz = idetgzz / det;

    gam.betax =
      betadownx * invgxx + betadowny * invgxy + betadownz * invgxz;

    gam.betay =
      betadownx * invgxy + betadowny * invgyy + betadownz * invgyz;

    gam.betaz =
      betadownx * invgxz + betadowny * invgyz + betadownz * invgzz;

    Real b2 =
      betadownx * gam.betax + betadowny * gam.betay +
      betadownz * gam.betaz;


    gam.alpha = sqrt(fabs(b2 - met.g.tt));

    gam.kxx = -(-2 * dbetadownxx - gam.betax * dgxxx - gam.betay * dgxxy -
      gam.betaz * dgxxz + 2 * (gam.betax * dgxxx + gam.betay * dgxyx +
        gam.betaz * dgxzx) + dtgxx) / (2. * gam.alpha);

    gam.kxy = -(-dbetadownxy - dbetadownyx + gam.betax * dgxxy -
      gam.betaz * dgxyz + gam.betaz * dgxzy + gam.betay * dgyyx +
      gam.betaz * dgyzx + dtgxy) / (2. * gam.alpha);

    gam.kxz = -(-dbetadownxz - dbetadownzx + gam.betax * dgxxz +
      gam.betay * dgxyz - gam.betay * dgxzy + gam.betay * dgyzx +
      gam.betaz * dgzzx + dtgxz) / (2. * gam.alpha);

    gam.kyy = -(-2 * dbetadownyy - gam.betax * dgyyx - gam.betay * dgyyy -
      gam.betaz * dgyyz + 2 * (gam.betax * dgxyy + gam.betay * dgyyy +
        gam.betaz * dgyzy) + dtgyy) / (2. * gam.alpha);

    gam.kyz = -(-dbetadownyz - dbetadownzy + gam.betax * dgxyz +
      gam.betax * dgxzy + gam.betay * dgyyz - gam.betax * dgyzx +
      gam.betaz * dgzzy + dtgyz) / (2. * gam.alpha);

    gam.kzz = -(-2 * dbetadownzz - gam.betax * dgzzx - gam.betay * dgzzy -
      gam.betaz * dgzzz + 2 * (gam.betax * dgxzz + gam.betay * dgyzz +
        gam.betaz * dgzzz) + dtgzz) / (2. * gam.alpha);
  }
  return 0;
}

void LoadTrajectoryTable(const std::string &fname) {
  std::ifstream fin(fname);
  if (!fin.is_open()) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "could not open trajectory file: '" << fname << "'"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  bbh_table = bbh_traj_table();
  std::string line;
  std::size_t lineno = 0;
  while (std::getline(fin, line)) {
    ++lineno;
    auto p = line.find_first_not_of(" \t\r\n");
    if (p == std::string::npos || line[p] == '#')
      continue;
    std::istringstream iss(line);
    Real c[21];
    for (int i = 0; i < 21; ++i) {
      if (!(iss >> c[i]) || !std::isfinite(c[i])) {
        std::cout << "### FATAL ERROR in " << __FILE__ << " at line "
                  << __LINE__ << std::endl
                  << "bad trajectory value in '" << fname << "' line " << lineno
                  << std::endl;
        std::exit(EXIT_FAILURE);
      }
    }
    if (!(c[1] > 0.0) || !(c[2] > 0.0) ||
        !SpinVectorWithinExtremality(c[9], c[10], c[11]) ||
        !SpinVectorWithinExtremality(c[12], c[13], c[14])) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "invalid mass or spin in '" << fname << "' line " << lineno
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
    bbh_table.t.push_back(c[0]);
    bbh_table.m1.push_back(c[1]);
    bbh_table.m2.push_back(c[2]);
    bbh_table.x1.push_back(c[3]);
    bbh_table.y1.push_back(c[4]);
    bbh_table.z1.push_back(c[5]);
    bbh_table.x2.push_back(c[6]);
    bbh_table.y2.push_back(c[7]);
    bbh_table.z2.push_back(c[8]);
    bbh_table.ax1.push_back(c[9]);
    bbh_table.ay1.push_back(c[10]);
    bbh_table.az1.push_back(c[11]);
    bbh_table.ax2.push_back(c[12]);
    bbh_table.ay2.push_back(c[13]);
    bbh_table.az2.push_back(c[14]);
    bbh_table.vx1.push_back(c[15]);
    bbh_table.vy1.push_back(c[16]);
    bbh_table.vz1.push_back(c[17]);
    bbh_table.vx2.push_back(c[18]);
    bbh_table.vy2.push_back(c[19]);
    bbh_table.vz2.push_back(c[20]);
  }
  if (bbh_table.t.size() < 2) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "trajectory file has fewer than 2 rows" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  for (std::size_t i = 1; i < bbh_table.t.size(); ++i)
    if (!(bbh_table.t[i] > bbh_table.t[i - 1])) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "trajectory times must increase" << std::endl;
      std::exit(EXIT_FAILURE);
    }
  bbh_table.active_segment = 0;
  if (global_variable::my_rank == 0)
    std::cout << "Loaded BBH trajectory table '" << fname << "' with "
              << bbh_table.t.size() << " rows" << std::endl;
}

void find_traj_t(Real t, Real bbh_t[NTRAJ]) {
  Real dbbh_t[NTRAJ];
  find_traj_t_with_deriv(t, bbh_t, dbbh_t);
}

bbh_traj_state find_traj_state(Real t) {
  bbh_traj_state state;
  find_traj_t_with_deriv(t, state.q, state.dq);
  return state;
}

void find_traj_t_with_deriv(Real t, Real bbh_t[NTRAJ], Real dbbh_t[NTRAJ]) {
  if (bbh.single_black_hole) {
    for (int n=0; n<NTRAJ; ++n) bbh_t[n] = dbbh_t[n] = 0.0;
    bbh_t[M1T] = 1.0;
    return;
  }
  if (!bbh.use_traj_table) {
    Real r1 = bbh.q / (1.0 + bbh.q) * bbh.sep, r2 = -bbh.sep / (1.0 + bbh.q),
         c = std::cos(bbh.om * t), s = std::sin(bbh.om * t),
         om2 = bbh.om * bbh.om;
    bbh_t[X1] = r1 * c;
    bbh_t[Y1] = r1 * s;
    bbh_t[Z1] = 0;
    bbh_t[X2] = r2 * c;
    bbh_t[Y2] = r2 * s;
    bbh_t[Z2] = 0;
    bbh_t[VX1] = -r1 * bbh.om * s;
    bbh_t[VY1] = r1 * bbh.om * c;
    bbh_t[VZ1] = 0;
    bbh_t[VX2] = -r2 * bbh.om * s;
    bbh_t[VY2] = r2 * bbh.om * c;
    bbh_t[VZ2] = 0;
    Real spin_factor = 1.0, dspin_factor = 0.0;
    if (bbh.spin_ramp) {
      spin_factor = SmoothRamp01(t, bbh.spin_ramp_start_time,
                                 bbh.spin_ramp_timescale, &dspin_factor);
    }
    Real e1x = std::sin(bbh.th_a1) * std::cos(bbh.ph_a1);
    Real e1y = std::sin(bbh.th_a1) * std::sin(bbh.ph_a1);
    Real e1z = std::cos(bbh.th_a1);
    Real e2x = std::sin(bbh.th_a2) * std::cos(bbh.ph_a2);
    Real e2y = std::sin(bbh.th_a2) * std::sin(bbh.ph_a2);
    Real e2z = std::cos(bbh.th_a2);
    bbh_t[AX1] = bbh.a1 * spin_factor * e1x;
    bbh_t[AY1] = bbh.a1 * spin_factor * e1y;
    bbh_t[AZ1] = bbh.a1 * spin_factor * e1z;
    bbh_t[AX2] = bbh.a2 * spin_factor * e2x;
    bbh_t[AY2] = bbh.a2 * spin_factor * e2y;
    bbh_t[AZ2] = bbh.a2 * spin_factor * e2z;
    bbh_t[M1T] = 1.0 / (bbh.q + 1.0);
    bbh_t[M2T] = 1.0 - bbh_t[M1T];
    dbbh_t[X1] = bbh_t[VX1];
    dbbh_t[Y1] = bbh_t[VY1];
    dbbh_t[Z1] = 0;
    dbbh_t[X2] = bbh_t[VX2];
    dbbh_t[Y2] = bbh_t[VY2];
    dbbh_t[Z2] = 0;
    dbbh_t[VX1] = -om2 * bbh_t[X1];
    dbbh_t[VY1] = -om2 * bbh_t[Y1];
    dbbh_t[VZ1] = 0;
    dbbh_t[VX2] = -om2 * bbh_t[X2];
    dbbh_t[VY2] = -om2 * bbh_t[Y2];
    dbbh_t[VZ2] = 0;
    dbbh_t[AX1] = bbh.a1 * dspin_factor * e1x;
    dbbh_t[AY1] = bbh.a1 * dspin_factor * e1y;
    dbbh_t[AZ1] = bbh.a1 * dspin_factor * e1z;
    dbbh_t[AX2] = bbh.a2 * dspin_factor * e2x;
    dbbh_t[AY2] = bbh.a2 * dspin_factor * e2y;
    dbbh_t[AZ2] = bbh.a2 * dspin_factor * e2z;
    dbbh_t[M1T] = dbbh_t[M2T] = 0;
    return;
  }
  const auto &T = bbh_table.t;
  Real trange = T.back() - T.front();
  Real tol = 64.0 * std::numeric_limits<Real>::epsilon() *
             std::max({1.0, std::abs(T.front()), std::abs(T.back()), trange});
  if (t < T.front() - tol || t > T.back() + tol) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "requested time outside trajectory-table range" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  std::size_t i0, i1;
  std::size_t cached = std::min(bbh_table.active_segment, T.size() - 2);
  if (t >= T[cached] && t <= T[cached + 1]) {
    i0 = cached;
    i1 = cached + 1;
  } else {
    auto it = std::upper_bound(T.begin(), T.end(), t);
    if (it == T.begin()) {
      i0 = 0;
      i1 = 1;
    } else if (it == T.end()) {
      i0 = T.size() - 2;
      i1 = T.size() - 1;
    } else {
      i1 = it - T.begin();
      i0 = i1 - 1;
    }
    bbh_table.active_segment = i0;
  }
  Real dt = T[i1] - T[i0], w = (t - T[i0]) / dt;
  auto H = [w, dt](Real p0, Real v0, Real p1, Real v1, Real *p, Real *dp,
                   Real *ddp) {
    Real w2 = w * w, w3 = w2 * w;
    *p = (2 * w3 - 3 * w2 + 1) * p0 + (w3 - 2 * w2 + w) * dt * v0 +
         (-2 * w3 + 3 * w2) * p1 + (w3 - w2) * dt * v1;
    *dp = ((6 * w2 - 6 * w) * p0 + (3 * w2 - 4 * w + 1) * dt * v0 +
           (-6 * w2 + 6 * w) * p1 + (3 * w2 - 2 * w) * dt * v1) /
          dt;
    *ddp = ((12 * w - 6) * p0 + (6 * w - 4) * dt * v0 + (-12 * w + 6) * p1 +
            (6 * w - 2) * dt * v1) /
           (dt * dt);
  };
  H(bbh_table.x1[i0], bbh_table.vx1[i0], bbh_table.x1[i1], bbh_table.vx1[i1],
    &bbh_t[X1], &bbh_t[VX1], &dbbh_t[VX1]);
  H(bbh_table.y1[i0], bbh_table.vy1[i0], bbh_table.y1[i1], bbh_table.vy1[i1],
    &bbh_t[Y1], &bbh_t[VY1], &dbbh_t[VY1]);
  H(bbh_table.z1[i0], bbh_table.vz1[i0], bbh_table.z1[i1], bbh_table.vz1[i1],
    &bbh_t[Z1], &bbh_t[VZ1], &dbbh_t[VZ1]);
  H(bbh_table.x2[i0], bbh_table.vx2[i0], bbh_table.x2[i1], bbh_table.vx2[i1],
    &bbh_t[X2], &bbh_t[VX2], &dbbh_t[VX2]);
  H(bbh_table.y2[i0], bbh_table.vy2[i0], bbh_table.y2[i1], bbh_table.vy2[i1],
    &bbh_t[Y2], &bbh_t[VY2], &dbbh_t[VY2]);
  H(bbh_table.z2[i0], bbh_table.vz2[i0], bbh_table.z2[i1], bbh_table.vz2[i1],
    &bbh_t[Z2], &bbh_t[VZ2], &dbbh_t[VZ2]);
  dbbh_t[X1] = bbh_t[VX1];
  dbbh_t[Y1] = bbh_t[VY1];
  dbbh_t[Z1] = bbh_t[VZ1];
  dbbh_t[X2] = bbh_t[VX2];
  dbbh_t[Y2] = bbh_t[VY2];
  dbbh_t[Z2] = bbh_t[VZ2];
  auto linear = [w](Real f0, Real f1) { return (1.0 - w) * f0 + w * f1; };
  auto linear_deriv = [dt](Real f0, Real f1) { return (f1 - f0) / dt; };
  bbh_t[AX1] = linear(bbh_table.ax1[i0], bbh_table.ax1[i1]);
  bbh_t[AY1] = linear(bbh_table.ay1[i0], bbh_table.ay1[i1]);
  bbh_t[AZ1] = linear(bbh_table.az1[i0], bbh_table.az1[i1]);
  bbh_t[AX2] = linear(bbh_table.ax2[i0], bbh_table.ax2[i1]);
  bbh_t[AY2] = linear(bbh_table.ay2[i0], bbh_table.ay2[i1]);
  bbh_t[AZ2] = linear(bbh_table.az2[i0], bbh_table.az2[i1]);
  bbh_t[M1T] = linear(bbh_table.m1[i0], bbh_table.m1[i1]);
  bbh_t[M2T] = linear(bbh_table.m2[i0], bbh_table.m2[i1]);
  dbbh_t[AX1] = linear_deriv(bbh_table.ax1[i0], bbh_table.ax1[i1]);
  dbbh_t[AY1] = linear_deriv(bbh_table.ay1[i0], bbh_table.ay1[i1]);
  dbbh_t[AZ1] = linear_deriv(bbh_table.az1[i0], bbh_table.az1[i1]);
  dbbh_t[AX2] = linear_deriv(bbh_table.ax2[i0], bbh_table.ax2[i1]);
  dbbh_t[AY2] = linear_deriv(bbh_table.ay2[i0], bbh_table.ay2[i1]);
  dbbh_t[AZ2] = linear_deriv(bbh_table.az2[i0], bbh_table.az2[i1]);
  dbbh_t[M1T] = linear_deriv(bbh_table.m1[i0], bbh_table.m1[i1]);
  dbbh_t[M2T] = linear_deriv(bbh_table.m2[i0], bbh_table.m2[i1]);
}

template <typename T>
KOKKOS_FORCEINLINE_FUNCTION T BoostGammaMinusOneOverV2(const T v2, const T gamma) {
  if (value_of(v2) < 1.0e-12) {
    return T(0.5) + T(0.375) * v2 + T(0.3125) * v2 * v2;
  }
  return (gamma - T(1.0)) / v2;
}

template <typename T>
KOKKOS_FORCEINLINE_FUNCTION void BuildBoostJacobian(T vx, T vy, T vz,
                                               T J[NDIM][NDIM]) {
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      J[i][j] = T(0.0);
  T v2 = vx * vx + vy * vy + vz * vz;
  T g = T(1.0) / metric_sqrt(T(1.0) - v2);
  T q = BoostGammaMinusOneOverV2(v2, g);
  J[0][0] = g;
  J[0][1] = -g * vx;
  J[0][2] = -g * vy;
  J[0][3] = -g * vz;
  J[1][0] = J[0][1];
  J[2][0] = J[0][2];
  J[3][0] = J[0][3];
  J[1][1] = T(1.0) + q * vx * vx;
  J[1][2] = q * vx * vy;
  J[1][3] = q * vx * vz;
  J[2][1] = J[1][2];
  J[2][2] = T(1.0) + q * vy * vy;
  J[2][3] = q * vy * vz;
  J[3][1] = J[1][3];
  J[3][2] = J[2][3];
  J[3][3] = T(1.0) + q * vz * vz;
}
template <typename T>
KOKKOS_FORCEINLINE_FUNCTION void BoostedSpatialCoordinates(T x, T y, T z, T x0, T y0,
                                                      T z0, T vx, T vy, T vz,
                                                      T *xbh, T *ybh, T *zbh) {
  T dx = x - x0, dy = y - y0, dz = z - z0;
  T v2 = vx * vx + vy * vy + vz * vz;
  T g = T(1.0) / metric_sqrt(T(1.0) - v2);
  T q = BoostGammaMinusOneOverV2(v2, g);
  T vd = vx * dx + vy * dy + vz * dz;
  *xbh = dx + q * vx * vd;
  *ybh = dy + q * vy * vd;
  *zbh = dz + q * vz * vd;
}
template <typename T>
KOKKOS_FORCEINLINE_FUNCTION void
KerrSchildPerturbation(T x, T y, T z, T ax, T ay, T az, T m, T KS[NDIM][NDIM]) {
  T rt2 = T(1.4142135623730951), irt2 = T(1.0) / rt2,
    a2 = ax * ax + ay * ay + az * az, x2 = x * x + y * y + z * z,
    ad = ax * x + ay * y + az * z, term = x2 - a2,
    rho2 = term + metric_sqrt(T(4.0) * ad * ad + term * term),
    rho = metric_sqrt(rho2),
    fac = irt2 * rho2 * rho * m / (ad * ad + T(0.25) * rho2 * rho2),
    den = a2 + T(0.5) * rho2, iden = T(1.0) / den;
  T ell[3];
  ell[0] = y * az - z * ay + rt2 * ad * ax / rho + rho * x * irt2;
  ell[1] = -x * az + z * ax + rt2 * ad * ay / rho + rho * y * irt2;
  ell[2] = x * ay - y * ax + rt2 * ad * az / rho + rho * z * irt2;
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      KS[i][j] = T(0.0);
  KS[0][0] = fac;
  #pragma unroll
  for (int i = 0; i < 3; ++i) {
    KS[0][i + 1] = fac * ell[i] * iden;
    KS[i + 1][0] = KS[0][i + 1];
  }
  #pragma unroll
  for (int i = 0; i < 3; ++i)
    #pragma unroll
    for (int j = i; j < 3; ++j) {
      KS[i + 1][j + 1] = fac * ell[i] * ell[j] * iden * iden;
      KS[j + 1][i + 1] = KS[i + 1][j + 1];
    }
}
template <typename T>
KOKKOS_FORCEINLINE_FUNCTION void AddBoostedKerrSchildHole(const T KS[NDIM][NDIM],
                                                     const T J[NDIM][NDIM],
                                                     T gcov[NDIM][NDIM]) {
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = i; j < NDIM; ++j) {
      T sum = T(0.0);
      #pragma unroll
      for (int m = 0; m < NDIM; ++m)
        #pragma unroll
        for (int n = 0; n < NDIM; ++n)
          sum = sum + J[m][i] * J[n][j] * KS[m][n];
      gcov[i][j] = gcov[i][j] + sum;
      gcov[j][i] = gcov[i][j];
    }
}
template <typename T>
KOKKOS_FORCEINLINE_FUNCTION void
SuperposedBBHTemplate(T x, T y, T z, T gcov[NDIM][NDIM], const T tr[NTRAJ],
                      const bbh_pgen b) {
  T v1x = tr[VX1], v1y = tr[VY1], v1z = tr[VZ1], v2x = tr[VX2],
    v2y = tr[VY2], v2z = tr[VZ2];
  T a1x = tr[AX1], a1y = tr[AY1], a1z = tr[AZ1], a2x = tr[AX2], a2y = tr[AY2],
    a2z = tr[AZ2];
  T m1 = tr[M1T], m2 = tr[M2T];
  a1x = a1x * m1;
  a1y = a1y * m1;
  a1z = a1z * m1;
  a2x = a2x * m2;
  a2y = a2y * m2;
  a2z = a2z * m2;
  T a1n = metric_sqrt(a1x * a1x + a1y * a1y + a1z * a1z + T(1e-40)),
    a2n = metric_sqrt(a2x * a2x + a2y * a2y + a2z * a2z + T(1e-40)),
    a1 = a1n, a2 = a2n;
  T x1, y1, z1, x2, y2, z2;
  BoostedSpatialCoordinates(x, y, z, tr[X1], tr[Y1], tr[Z1], v1x, v1y, v1z, &x1,
                            &y1, &z1);
  BoostedSpatialCoordinates(x, y, z, tr[X2], tr[Y2], tr[Z2], v2x, v2y, v2z, &x2,
                            &y2, &z2);
  T r1 = metric_norm3(x1, y1, z1),
    r2 = metric_norm3(x2, y2, z2),
    c1 = metric_sqrt(a1 * a1) * (T(1.0) + b.a1_buffer) + b.cutoff_floor,
    c2 = metric_sqrt(a2 * a2) * (T(1.0) + b.a2_buffer) + b.cutoff_floor;
  if (value_of(r1) < value_of(c1))
    z1 = (value_of(z1) > 0.0) ? c1 : -c1;
  if (value_of(r2) < value_of(c2))
    z2 = (value_of(z2) > 0.0) ? c2 : -c2;
  T KS1[NDIM][NDIM], KS2[NDIM][NDIM], J1[NDIM][NDIM], J2[NDIM][NDIM];
  KerrSchildPerturbation(x1, y1, z1, a1x, a1y, a1z, m1, KS1);
  KerrSchildPerturbation(x2, y2, z2, a2x, a2y, a2z, m2, KS2);
  BuildBoostJacobian(v1x, v1y, v1z, J1);
  BuildBoostJacobian(v2x, v2y, v2z, J2);
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      gcov[i][j] = (i == j) ? ((i == 0) ? T(-1.0) : T(1.0)) : T(0.0);
  AddBoostedKerrSchildHole(KS1, J1, gcov);
  AddBoostedKerrSchildHole(KS2, J2, gcov);
}

template <typename V>
KOKKOS_FORCEINLINE_FUNCTION void BuildBoostJacobianMixed(V vx, V vy, V vz,
                                                    V J[NDIM][NDIM]) {
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      J[i][j] = V(0.0);
  auto v2 = vx * vx + vy * vy + vz * vz;
  auto g = V(1.0) / metric_sqrt(V(1.0) - v2);
  auto q = BoostGammaMinusOneOverV2(v2, g);
  J[0][0] = g;
  J[0][1] = -g * vx;
  J[0][2] = -g * vy;
  J[0][3] = -g * vz;
  J[1][0] = J[0][1];
  J[2][0] = J[0][2];
  J[3][0] = J[0][3];
  J[1][1] = V(1.0) + q * vx * vx;
  J[1][2] = q * vx * vy;
  J[1][3] = q * vx * vz;
  J[2][1] = J[1][2];
  J[2][2] = V(1.0) + q * vy * vy;
  J[2][3] = q * vy * vz;
  J[3][1] = J[1][3];
  J[3][2] = J[2][3];
  J[3][3] = V(1.0) + q * vz * vz;
}

template <typename C, typename P, typename G>
KOKKOS_FORCEINLINE_FUNCTION void
BoostedSpatialCoordinatesMixed(C x, C y, C z, P x0, P y0, P z0,
                               P vx, P vy, P vz, G *xbh, G *ybh, G *zbh) {
  auto dx = x - x0, dy = y - y0, dz = z - z0;
  auto v2 = vx * vx + vy * vy + vz * vz;
  auto g = P(1.0) / metric_sqrt(P(1.0) - v2);
  auto q = BoostGammaMinusOneOverV2(v2, g);
  auto vd = vx * dx + vy * dy + vz * dz;
  *xbh = dx + q * vx * vd;
  *ybh = dy + q * vy * vd;
  *zbh = dz + q * vz * vd;
}

template <typename C, typename P, typename G>
KOKKOS_FORCEINLINE_FUNCTION void
KerrSchildPerturbationMixed(C x, C y, C z, P ax, P ay, P az, P m,
                            G KS[NDIM][NDIM]) {
  G rt2 = G(1.4142135623730951), irt2 = G(1.0) / rt2;
  auto a2 = ax * ax + ay * ay + az * az;
  auto x2 = x * x + y * y + z * z;
  auto ad = ax * x + ay * y + az * z;
  auto term = x2 - a2;
  auto rho2 = term + metric_sqrt(G(4.0) * ad * ad + term * term);
  auto rho = metric_sqrt(rho2);
  auto fac = irt2 * rho2 * rho * m /
             (ad * ad + G(0.25) * rho2 * rho2);
  auto den = a2 + G(0.5) * rho2;
  auto iden = G(1.0) / den;
  G ell[3];
  ell[0] = y * az - z * ay + rt2 * ad * ax / rho + rho * x * irt2;
  ell[1] = -x * az + z * ax + rt2 * ad * ay / rho + rho * y * irt2;
  ell[2] = x * ay - y * ax + rt2 * ad * az / rho + rho * z * irt2;
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      KS[i][j] = G(0.0);
  KS[0][0] = fac;
  #pragma unroll
  for (int i = 0; i < 3; ++i) {
    KS[0][i + 1] = fac * ell[i] * iden;
    KS[i + 1][0] = KS[0][i + 1];
  }
  #pragma unroll
  for (int i = 0; i < 3; ++i)
    #pragma unroll
    for (int j = i; j < 3; ++j) {
      KS[i + 1][j + 1] = fac * ell[i] * ell[j] * iden * iden;
      KS[j + 1][i + 1] = KS[i + 1][j + 1];
    }
}

template <typename K, typename J, typename G>
KOKKOS_FORCEINLINE_FUNCTION void
AddBoostedKerrSchildHoleMixed(const K KS[NDIM][NDIM],
                              const J Jmat[NDIM][NDIM],
                              G gcov[NDIM][NDIM]) {
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = i; j < NDIM; ++j) {
      G sum = G(0.0);
      #pragma unroll
      for (int m = 0; m < NDIM; ++m)
        #pragma unroll
        for (int n = 0; n < NDIM; ++n)
          sum = sum + Jmat[m][i] * Jmat[n][j] * KS[m][n];
      gcov[i][j] = gcov[i][j] + sum;
      gcov[j][i] = gcov[i][j];
    }
}

template <typename C, typename P, typename G>
KOKKOS_FORCEINLINE_FUNCTION void
SuperposedBBHTemplateMixed(C x, C y, C z, G gcov[NDIM][NDIM],
                           const P tr[NTRAJ], const bbh_pgen b) {
  auto v1x = tr[VX1], v1y = tr[VY1], v1z = tr[VZ1];
  auto v2x = tr[VX2], v2y = tr[VY2], v2z = tr[VZ2];
  auto a1x = tr[AX1], a1y = tr[AY1], a1z = tr[AZ1];
  auto a2x = tr[AX2], a2y = tr[AY2], a2z = tr[AZ2];
  auto m1 = tr[M1T];
  auto m2 = tr[M2T];
  a1x = a1x * m1;
  a1y = a1y * m1;
  a1z = a1z * m1;
  a2x = a2x * m2;
  a2y = a2y * m2;
  a2z = a2z * m2;
  auto a1 = metric_sqrt(a1x * a1x + a1y * a1y + a1z * a1z + P(1e-40));
  auto a2 = metric_sqrt(a2x * a2x + a2y * a2y + a2z * a2z + P(1e-40));

  G x1, y1, z1, x2, y2, z2;
  BoostedSpatialCoordinatesMixed<C, P, G>(
      x, y, z, tr[X1], tr[Y1], tr[Z1], v1x, v1y, v1z, &x1, &y1, &z1);
  BoostedSpatialCoordinatesMixed<C, P, G>(
      x, y, z, tr[X2], tr[Y2], tr[Z2], v2x, v2y, v2z, &x2, &y2, &z2);

  auto r1 = metric_norm3(x1, y1, z1);
  auto r2 = metric_norm3(x2, y2, z2);
  auto c1 = metric_sqrt(a1 * a1) * (P(1.0) + b.a1_buffer) + b.cutoff_floor;
  auto c2 = metric_sqrt(a2 * a2) * (P(1.0) + b.a2_buffer) + b.cutoff_floor;
  if (value_of(r1) < value_of(c1))
    z1 = (value_of(z1) > 0.0) ? c1 : -c1;
  if (value_of(r2) < value_of(c2))
    z2 = (value_of(z2) > 0.0) ? c2 : -c2;

  using JType = decltype(v1x + v1y + v1z);
  G KS1[NDIM][NDIM], KS2[NDIM][NDIM];
  JType J1[NDIM][NDIM], J2[NDIM][NDIM];
  KerrSchildPerturbationMixed<G, P, G>(x1, y1, z1, a1x, a1y, a1z, m1, KS1);
  KerrSchildPerturbationMixed<G, P, G>(x2, y2, z2, a2x, a2y, a2z, m2, KS2);
  BuildBoostJacobianMixed(v1x, v1y, v1z, J1);
  BuildBoostJacobianMixed(v2x, v2y, v2z, J2);
  #pragma unroll
  for (int i = 0; i < NDIM; ++i)
    #pragma unroll
    for (int j = 0; j < NDIM; ++j)
      gcov[i][j] = (i == j) ? ((i == 0) ? G(-1.0) : G(1.0)) : G(0.0);
  AddBoostedKerrSchildHoleMixed(KS1, J1, gcov);
  AddBoostedKerrSchildHoleMixed(KS2, J2, gcov);
}
template<typename T>
KOKKOS_INLINE_FUNCTION
void EvaluateBBHMetric(const T x, const T y, const T z, T gcov[NDIM][NDIM],
                       const Real tr[NTRAJ], const bbh_pgen b) {
  SuperposedBBHTemplateMixed<T,Real,T>(x,y,z,gcov,tr,b);
  if (!b.corotating) return;
  T vx = -b.frame_omega*y, vy = b.frame_omega*x;
  T gtt = gcov[TT][TT]+2.0*(gcov[TT][XX]*vx+gcov[TT][YY]*vy)
            +gcov[XX][XX]*vx*vx+2.0*gcov[XX][YY]*vx*vy+gcov[YY][YY]*vy*vy;
  T gt[3];
  for (int a=1; a<NDIM; ++a) {
    gt[a-1] = gcov[TT][a]+gcov[XX][a]*vx+gcov[YY][a]*vy;
  }
  gcov[TT][TT] = gtt;
  for (int a=1; a<NDIM; ++a) gcov[TT][a] = gcov[a][TT] = gt[a-1];
}

KOKKOS_INLINE_FUNCTION
void
SuperposedBBH(const Real time, const Real x, const Real y, const Real z,
              Real gcov[][NDIM], const Real traj_array[NTRAJ], const bbh_pgen b)
{
  (void)time;
  EvaluateBBHMetric<Real>(x, y, z, gcov, traj_array, b);
}

KOKKOS_FORCEINLINE_FUNCTION
void FillMetricValue(const dual1_real gcov[NDIM][NDIM], struct dd_sym &g) {
  g.tt = value_of(gcov[TT][TT]);
  g.tx = value_of(gcov[TT][XX]);
  g.ty = value_of(gcov[TT][YY]);
  g.tz = value_of(gcov[TT][ZZ]);
  g.xx = value_of(gcov[XX][XX]);
  g.xy = value_of(gcov[XX][YY]);
  g.xz = value_of(gcov[XX][ZZ]);
  g.yy = value_of(gcov[YY][YY]);
  g.yz = value_of(gcov[YY][ZZ]);
  g.zz = value_of(gcov[ZZ][ZZ]);
}

KOKKOS_FORCEINLINE_FUNCTION
void FillMetricDerivative(const dual1_real gcov[NDIM][NDIM],
                          struct dd_sym &dg) {
  dg.tt = deriv_of(gcov[TT][TT]);
  dg.tx = deriv_of(gcov[TT][XX]);
  dg.ty = deriv_of(gcov[TT][YY]);
  dg.tz = deriv_of(gcov[TT][ZZ]);
  dg.xx = deriv_of(gcov[XX][XX]);
  dg.xy = deriv_of(gcov[XX][YY]);
  dg.xz = deriv_of(gcov[XX][ZZ]);
  dg.yy = deriv_of(gcov[YY][YY]);
  dg.yz = deriv_of(gcov[YY][ZZ]);
  dg.zz = deriv_of(gcov[ZZ][ZZ]);
}

KOKKOS_INLINE_FUNCTION
void DifferenceMetric(const struct dd_sym &plus, const struct dd_sym &minus,
                      const Real denom, struct dd_sym &dg) {
  Real inv = 1.0/denom;
  dg.tt = (plus.tt - minus.tt)*inv;
  dg.tx = (plus.tx - minus.tx)*inv;
  dg.ty = (plus.ty - minus.ty)*inv;
  dg.tz = (plus.tz - minus.tz)*inv;
  dg.xx = (plus.xx - minus.xx)*inv;
  dg.xy = (plus.xy - minus.xy)*inv;
  dg.xz = (plus.xz - minus.xz)*inv;
  dg.yy = (plus.yy - minus.yy)*inv;
  dg.yz = (plus.yz - minus.yz)*inv;
  dg.zz = (plus.zz - minus.zz)*inv;
}

KOKKOS_INLINE_FUNCTION
void numerical_4metric(const Real t, const Real x, const Real y,
                       const Real z, struct four_metric &outmet,
                       const Real traj_m[NTRAJ], const Real traj_0[NTRAJ],
                       const Real traj_p[NTRAJ], const Real hm, const Real hp,
                       const bbh_pgen b) {
  struct four_metric met_m, met_p;
  Real hx = b.metric_fd_step;

  get_metric(t, x, y, z, outmet, traj_0, b);

  if (b.corotating) {
    outmet.g_t = {};
  } else if (hm > 0.0 && hp > 0.0) {
    get_metric(t - hm, x, y, z, met_m, traj_m, b);
    get_metric(t + hp, x, y, z, met_p, traj_p, b);
    DifferenceMetric(met_p.g, met_m.g, hm + hp, outmet.g_t);
  } else if (hp > 0.0) {
    get_metric(t + hp, x, y, z, met_p, traj_p, b);
    DifferenceMetric(met_p.g, outmet.g, hp, outmet.g_t);
  } else {
    get_metric(t - hm, x, y, z, met_m, traj_m, b);
    DifferenceMetric(outmet.g, met_m.g, hm, outmet.g_t);
  }

  get_metric(t, x - hx, y, z, met_m, traj_0, b);
  get_metric(t, x + hx, y, z, met_p, traj_0, b);
  DifferenceMetric(met_p.g, met_m.g, 2.0*hx, outmet.g_x);

  get_metric(t, x, y - hx, z, met_m, traj_0, b);
  get_metric(t, x, y + hx, z, met_p, traj_0, b);
  DifferenceMetric(met_p.g, met_m.g, 2.0*hx, outmet.g_y);

  get_metric(t, x, y, z - hx, met_m, traj_0, b);
  get_metric(t, x, y, z + hx, met_p, traj_0, b);
  DifferenceMetric(met_p.g, met_m.g, 2.0*hx, outmet.g_z);
}

void TimeMetricAD(const Real x, const Real y, const Real z,
                  const Real tr[NTRAJ], const Real dtr[NTRAJ],
                  const bbh_pgen b, struct dd_sym &g, struct dd_sym &dg) {
  dual1_real gcov[NDIM][NDIM];
  if (b.corotating) {
    EvaluateBBHMetric<dual1_real>(dual1_real(x),dual1_real(y),dual1_real(z),gcov,tr,b);
    FillMetricValue(gcov, g);
    dg = {};
    return;
  }
  dual1_real td[NTRAJ];
  for (int n = 0; n < NTRAJ; ++n)
    td[n] = dual1_real(tr[n], dtr[n]);
  SuperposedBBHTemplateMixed<Real, dual1_real, dual1_real>(x, y, z, gcov, td,
                                                           b);
  FillMetricValue(gcov, g);
  FillMetricDerivative(gcov, dg);
}

KOKKOS_FORCEINLINE_FUNCTION
void SpatialMetricAD(const Real x, const Real y, const Real z, const int dir,
                     const Real tr[NTRAJ], const bbh_pgen b,
                     struct dd_sym &dg) {
  dual1_real gcov[NDIM][NDIM];
  dual1_real xd(x, dir == 0 ? 1.0 : 0.0);
  dual1_real yd(y, dir == 1 ? 1.0 : 0.0);
  dual1_real zd(z, dir == 2 ? 1.0 : 0.0);
  EvaluateBBHMetric<dual1_real>(xd, yd, zd, gcov, tr, b);
  FillMetricDerivative(gcov, dg);
}

KOKKOS_FORCEINLINE_FUNCTION void
get_metric_and_derivatives(const Real t, const Real x, const Real y,
                           const Real z, struct four_metric &met,
                           const Real tr[NTRAJ], const Real dtr[NTRAJ],
                           const bbh_pgen b) {
  (void)t;
  TimeMetricAD(x, y, z, tr, dtr, b, met.g, met.g_t);
  SpatialMetricAD(x, y, z, 0, tr, b, met.g_x);
  SpatialMetricAD(x, y, z, 1, tr, b, met.g_y);
  SpatialMetricAD(x, y, z, 2, tr, b, met.g_z);
}

KOKKOS_INLINE_FUNCTION
void get_metric(const Real t, const Real x, const Real y, const Real z,
                struct four_metric &met, const Real bbh_traj_loc[NTRAJ],
                const bbh_pgen bbh_) {
  Real gcov[NDIM][NDIM];

  SuperposedBBH(t, x, y, z, gcov, bbh_traj_loc, bbh_);

  met.g.tt = gcov[TT][TT];
  met.g.tx = gcov[TT][XX];
  met.g.ty = gcov[TT][YY];
  met.g.tz = gcov[TT][ZZ];
  met.g.xx = gcov[XX][XX];
  met.g.xy = gcov[XX][YY];
  met.g.xz = gcov[XX][ZZ];
  met.g.yy = gcov[YY][YY];
  met.g.yz = gcov[YY][ZZ];
  met.g.zz = gcov[ZZ][ZZ];

  return;
}

// refine region within a certain distance from each compact object
void RefineAlphaMin(MeshBlockPack *pmbp) {
  Mesh *pmesh       = pmbp->pmesh;
  int nmb           = pmbp->nmb_thispack;
  int mbs           = pmesh->gids_eachrank[global_variable::my_rank];
  auto &refine_flag = pmesh->pmr->refine_flag;
  auto &indcs       = pmesh->mb_indcs;
  int &is = indcs.is, nx1 = indcs.nx1;
  int &js = indcs.js, nx2 = indcs.nx2;
  int &ks = indcs.ks, nx3 = indcs.nx3;
  const int nkji = nx3 * nx2 * nx1;
  const int nji  = nx2 * nx1;
  auto &u0       = pmbp->padm->u_adm;
  int I_ADM_ALPHA  = pmbp->padm->I_ADM_ALPHA;
  // note: we need this to prevent capture by this in the lambda expr.

  // note: we need this to prevent capture by this in the lambda expr.
  auto bbh_ = bbh;

  par_for_outer(
  "AMR::AlphaMin", DevExeSpace(), 0, 0, 0, (nmb - 1),
  KOKKOS_LAMBDA(TeamMember_t tmember, const int m) {
    Real team_dmin;
    Kokkos::parallel_reduce(
      Kokkos::TeamThreadRange(tmember, nkji),
      [=](const int idx, Real &dmin) {
        int k = (idx) / nji;
        int j = (idx - k * nji) / nx1;
        int i = (idx - k * nji - j * nx1) + is;
        j += js;
        k += ks;
        dmin = fmin(u0(m, I_ADM_ALPHA, k, j, i), dmin);
      },
      Kokkos::Min<Real>(team_dmin));

    if (team_dmin < bbh_.alpha_thr) {
      refine_flag.d_view(m + mbs) = 1;
    }
    if (team_dmin > 1.25 * bbh_.alpha_thr) {
      refine_flag.d_view(m + mbs) = -1;
    }
  });

  // sync host and device
  refine_flag.template modify<DevExeSpace>();
  refine_flag.template sync<HostMemSpace>();
}

void RefineTracker(MeshBlockPack *pmbp) {
  Mesh *pmesh       = pmbp->pmesh;
  auto &refine_flag = pmesh->pmr->refine_flag;
  auto &size        = pmbp->pmb->mb_size;
  int nmb           = pmbp->nmb_thispack;
  int mbs           = pmesh->gids_eachrank[global_variable::my_rank];

  Real bbh_traj[NTRAJ];

  Real tt = pmesh->time;
  find_traj_t(tt, bbh_traj);
  Real x1_BH1 = bbh_traj[X1];
  Real x2_BH1 = bbh_traj[Y1];
  Real x3_BH1 = bbh_traj[Z1];
  Real x1_BH2 = bbh_traj[X2];
  Real x2_BH2 = bbh_traj[Y2];
  Real x3_BH2 = bbh_traj[Z2];
  const Real tracker_radius1 = bbh_ref.tracker_radius[0];
  const Real tracker_radius2 = bbh_ref.tracker_radius[1];
  const int tracker_reflevel1 = bbh_ref.tracker_reflevel[0];
  const int tracker_reflevel2 = bbh_ref.tracker_reflevel[1];
  for (int m = 0; m < nmb; ++m) {

    int level = pmesh->lloc_eachmb[m + mbs].level - pmesh->root_level;

    // extract MeshBlock bounds
    Real &x1min = size.h_view(m).x1min;
    Real &x1max = size.h_view(m).x1max;
    Real &x2min = size.h_view(m).x2min;
    Real &x2max = size.h_view(m).x2max;
    Real &x3min = size.h_view(m).x3min;
    Real &x3max = size.h_view(m).x3max;

    Real dx1_bh1 = std::max(std::max(x1min - x1_BH1, 0.0), x1_BH1 - x1max);
    Real dx2_bh1 = std::max(std::max(x2min - x2_BH1, 0.0), x2_BH1 - x2max);
    Real dx3_bh1 = std::max(std::max(x3min - x3_BH1, 0.0), x3_BH1 - x3max);
    Real dx1_bh2 = std::max(std::max(x1min - x1_BH2, 0.0), x1_BH2 - x1max);
    Real dx2_bh2 = std::max(std::max(x2min - x2_BH2, 0.0), x2_BH2 - x2max);
    Real dx3_bh2 = std::max(std::max(x3min - x3_BH2, 0.0), x3_BH2 - x3max);
    Real dmin2_bh1 = SQR(dx1_bh1) + SQR(dx2_bh1) + SQR(dx3_bh1);
    Real dmin2_bh2 = SQR(dx1_bh2) + SQR(dx2_bh2) + SQR(dx3_bh2);

    bool in_tracker1 = dmin2_bh1 < SQR(tracker_radius1);
    bool in_tracker2 = dmin2_bh2 < SQR(tracker_radius2);
    bool unlimited = (in_tracker1 && tracker_reflevel1 < 0) ||
                     (in_tracker2 && tracker_reflevel2 < 0);
    int target_level = -1;
    if (in_tracker1) target_level = std::max(target_level, tracker_reflevel1);
    if (in_tracker2) target_level = std::max(target_level, tracker_reflevel2);

    if (unlimited) {
      refine_flag.h_view(m + mbs) = 1;
    } else if (target_level >= 0) {
      if (level < target_level) {
        refine_flag.h_view(m + mbs) = 1;
      } else if (level == target_level) {
        refine_flag.h_view(m + mbs) = 0;
      } else {
        refine_flag.h_view(m + mbs) = -1;
      }
    } else {
      refine_flag.h_view(m + mbs) = -1;
    }
  }

  // sync host and device
  refine_flag.template modify<HostMemSpace>();
  refine_flag.template sync<DevExeSpace>();
}

// Enforce some minimum resolution within a certain spherical region
void RefineRadii(MeshBlockPack *pmbp) {
  Mesh *pmesh       = pmbp->pmesh;
  auto &refine_flag = pmesh->pmr->refine_flag;
  auto &size        = pmbp->pmb->mb_size;
  int nmb           = pmbp->nmb_thispack;
  int mbs           = pmesh->gids_eachrank[global_variable::my_rank];

  for (int m = 0; m < nmb; ++m) {
    // current refinement level
    int level = pmesh->lloc_eachmb[m + mbs].level - pmesh->root_level;

    // extract MeshBlock bounds
    Real &x1min = size.h_view(m).x1min;
    Real &x1max = size.h_view(m).x1max;
    Real &x2min = size.h_view(m).x2min;
    Real &x2max = size.h_view(m).x2max;
    Real &x3min = size.h_view(m).x3min;
    Real &x3max = size.h_view(m).x3max;

    Real r2[8] = {
      SQR(x1min) + SQR(x2min) + SQR(x3min),
      SQR(x1max) + SQR(x2min) + SQR(x3min),
      SQR(x1min) + SQR(x2max) + SQR(x3min),
      SQR(x1max) + SQR(x2max) + SQR(x3min),
      SQR(x1min) + SQR(x2min) + SQR(x3max),
      SQR(x1max) + SQR(x2min) + SQR(x3max),
      SQR(x1min) + SQR(x2max) + SQR(x3max),
      SQR(x1max) + SQR(x2max) + SQR(x3max),
    };
    Real rmin2 = *std::min_element(&r2[0], &r2[8]);

    for (int ir = 0; ir < bbh_ref.radius.size(); ++ir) {
      if (rmin2 < SQR(bbh_ref.radius[ir])) {
        if (level < bbh_ref.reflevel[ir]) {
          refine_flag.h_view(m + mbs) = 1;
        } else if (level == bbh_ref.reflevel[ir] && refine_flag.h_view(m + mbs) == -1) {
          refine_flag.h_view(m + mbs) = 0;
        }
      }
    }
  }

  // sync host and device
  refine_flag.template modify<HostMemSpace>();
  refine_flag.template sync<DevExeSpace>();
}

// 1: refines, -1: de-refines, 0: does nothing
void Refine(MeshBlockPack *pmy_pack) {
  if (bbh_ref.AlphaMin) {
    RefineAlphaMin(pmy_pack);
  } else if (bbh_ref.Tracker) {
    RefineTracker(pmy_pack);
  }
  RefineRadii(pmy_pack);
}

//nere hardcoding zero spin
KOKKOS_INLINE_FUNCTION
static void GetBoyerLindquistCoordinates(struct bbh_pgen pgen,
                                         Real x1, Real x2, Real x3,
                                         Real *pr, Real *ptheta, Real *pphi) {
  //Real rad = sqrt(SQR(x1) + SQR(x2) + SQR(x3));
  //Real r = fmax((sqrt( SQR(rad) - SQR(pgen.spin) + sqrt(SQR(SQR(rad)-SQR(pgen.spin))
  //                    + 4.0*SQR(pgen.spin)*SQR(x3)) ) / sqrt(2.0)), 1.0);
  //*pr = r;
  //*ptheta = (fabs(x3/r) < 1.0) ? acos(x3/r) : acos(copysign(1.0, x3));
  //*pphi = atan2(r*x2-pgen.spin*x1, pgen.spin*x2+r*x1) -
  //        pgen.spin*r/(SQR(r)-2.0*r+SQR(pgen.spin));

  Real r = sqrt(SQR(x1) + SQR(x2) + SQR(x3));
  *pr = r;
  if (r > 0.0) {
    *ptheta = (fabs(x3/r) < 1.0) ? acos(x3/r) : acos(copysign(1.0, x3));
    *pphi = atan2(r*x2, r*x1);
  } else {
    *ptheta = 0.0;
    *pphi = 0.0;
  }
  return;
}


//----------------------------------------------------------------------------------------
// Function to calculate time component of contravariant four velocity in BL
// Inputs:
//   r: radial Boyer-Lindquist coordinate
//   sin_theta: sine of polar Boyer-Lindquist coordinate
// Outputs:
//   returned value: u_t

// Needs to be updated to use actual metric?

KOKKOS_INLINE_FUNCTION
static Real CalculateCovariantUT(struct bbh_pgen pgen, Real r, Real sin_theta, Real l) {
  // Compute BL metric components
  Real sigma = SQR(r);
  Real g_00 = -1.0 + 2.0*r/sigma;
  Real g_03 = 0.0;
  Real g_33 = SQR(r)*SQR(sin_theta);

  // Compute time component of covariant BL 4-velocity
  Real u_t = -sqrt(fmax((SQR(g_03) - g_00*g_33)/(g_33 + 2.0*l*g_03 + SQR(l)*g_00), 0.0));
  return u_t;
}

//----------------------------------------------------------------------------------------
// Function to calculate enthalpy in Chakrabarti torus
// Inputs:
//   r: radial Boyer-Lindquist coordinate
//   sin_theta: sine of polar Boyer-Lindquist coordinate
// Outputs:
//   returned value: log(h)
// Notes:
//   enthalpy defined here as h = p_gas/rho
//   references Chakrabarti, S. 1985, ApJ 288, 1

KOKKOS_INLINE_FUNCTION
static Real LogHAux(struct bbh_pgen pgen, Real r, Real sin_theta) {
  Real logh;
  // Chakrabarti
  Real l = CalculateL(pgen, r, sin_theta);
  Real u_t = CalculateCovariantUT(pgen, r, sin_theta, l);
  Real l_edge = CalculateL(pgen, pgen.r_edge, 1.0);
  Real u_t_edge = CalculateCovariantUT(pgen, pgen.r_edge, 1.0, l_edge);
  Real hh = u_t_edge/u_t;
  if (pgen.n_param==1.0) {
    hh *= pow(l_edge/l, SQR(pgen.c_param)/(SQR(pgen.c_param)-1.0));
  } else {
    Real pow_c = 2.0/pgen.n_param;
    Real pow_l = 2.0-2.0/pgen.n_param;
    Real pow_abs = pgen.n_param/(2.0-2.0*pgen.n_param);
    hh *= (pow(fabs(1.0 - pow(pgen.c_param, pow_c)*pow(l   , pow_l)), pow_abs) *
          pow(fabs(1.0 - pow(pgen.c_param, pow_c)*pow(l_edge, pow_l)), -1.0*pow_abs));
  }
  if (isfinite(hh) && hh >= 1.0) {
    logh = log(hh);
  } else {
    logh = -1.0;
  }
  return logh;
}

//----------------------------------------------------------------------------------------
// Function to calculate T for radiating runs, assuming pressure and temp equilibrium
// Outputs:
//   returned value: temperature (p_gas / rho)
// Notes:
//   equation has form b4 * T^4 + T + b0 = 0

KOKKOS_INLINE_FUNCTION
static Real CalculateT(struct bbh_pgen pgen, Real rho, Real ptot_over_rho) {
  // Calculate quartic coefficients
  Real b4 = pgen.arad / (3.0 * rho);
  Real b0 = -ptot_over_rho;

  // Calculate real root of z^3 - 4*b0/b4 * z - 1/b4^2 = 0
  Real delta1 = 0.25 - 64.0 * b0 * b0 * b0 * b4 / 27.0;
  if (delta1 < 0.0) {
    return 0.0;
  }
  delta1 = sqrt(delta1);
  if (delta1 < 0.5) {
    return 0.0;
  }
  Real zroot;
  if (delta1 > 1.0e11) {  // to avoid small number cancellation
    zroot = pow(delta1, -2.0/3.0) / 3.0;
  } else {
    zroot = pow(0.5 + delta1, 1.0/3.0) - pow(-0.5 + delta1, 1.0/3.0);
  }
  if (zroot < 0.0) {
    return 0.0;
  }
  zroot *= pow(b4, -2.0/3.0);

  // Calculate quartic root using cubic root
  Real rcoef = sqrt(zroot);
  Real delta2 = -zroot + 2.0 / (b4 * rcoef);
  if (delta2 < 0.0) {
    return 0.0;
  }
  delta2 = sqrt(delta2);
  Real root = 0.5 * (delta2 - rcoef);
  if (root < 0.0) {
    return 0.0;
  }
  return root;
}
//----------------------------------------------------------------------------------------
// Function for calculating c, n parameters controlling angular momentum profile
// in Chakrabarti torus, where l = c * lambda^n. edited so that n can be pre-specified
// such that the assumption of keplerian angular momentum at the inner edge is dropped

KOKKOS_INLINE_FUNCTION
static void CalculateCN(struct bbh_pgen pgen, Real *cparam, Real *nparam) {
  Real n_input = pgen.n_param;
  Real nn; // slope of angular momentum profile
  Real cc; // constant of angular momentum profile
  Real l_edge = SQR(pgen.r_edge)/(sqrt(pgen.r_edge)*(pgen.r_edge - 2.0));
  Real l_peak = SQR(pgen.r_peak)/(sqrt(pgen.r_peak)*(pgen.r_peak - 2.0));
  Real lambda_edge = sqrt((l_edge*(SQR(pgen.r_edge)*pgen.r_edge))/(l_edge*(pgen.r_edge - 2.0)));
  Real lambda_peak = sqrt((l_peak*(SQR(pgen.r_peak)*pgen.r_peak))/(l_peak*(pgen.r_peak - 2.0)));
  if (n_input == 0.0) {
    nn = log(l_peak/l_edge)/log(lambda_peak/lambda_edge);
    cc = l_edge*pow(lambda_edge, -nn);
  } else {
    nn = n_input;
    cc = l_peak*pow(lambda_peak, -nn);
  }
  *cparam = cc;
  *nparam = nn;
  return;
}

//----------------------------------------------------------------------------------------
// Function for calculating l in Chakrabarti torus
// N.B. Here assumer zero spin
KOKKOS_INLINE_FUNCTION
static Real CalculateL(struct bbh_pgen pgen, Real r, Real sin_theta) {
  // Compute BL metric components
  Real sigma = SQR(r);
  Real g_00 = -1.0 + 2.0*r/sigma;
  Real g_03 = 0.0;
  Real g_33 = sigma*SQR(sin_theta);

  // Perform bisection
  Real l_min = 1.0;
  Real l_max = 100.0;
  Real l_val = 0.5*(l_min + l_max);
  int max_iterations = 25;
  Real tol_rel = 1.0e-8;
  for (int n=0; n<max_iterations; ++n) {
    Real error_rel = 0.5*(l_max - l_min)/l_val;
    if (error_rel < tol_rel) {
      break;
    }
    Real residual = pow(l_val/pgen.c_param, 2.0/pgen.n_param) + l_val*g_33/(l_val*g_00);
    if (residual < 0.0) {
      l_min = l_val;
      l_val = 0.5 * (l_min + l_max);
    } else if (residual > 0.0) {
      l_max = l_val;
      l_val = 0.5 * (l_min + l_max);
    } else if (residual == 0.0) {
      break;
    }
  }
  return l_val;
}

KOKKOS_INLINE_FUNCTION
static void CalculateVectorPotentialInTiltedTorus(struct bbh_pgen pgen,
                                                  Real r, Real theta, Real phi,
                                                  Real *patheta, Real *paphi) {
  // Find vector potential components, accounting for tilt
  Real atheta = 0.0, aphi = 0.0;

  Real sin_theta = sin(theta);
  Real cos_theta = cos(theta);
  Real sin_phi = sin(phi);
  Real cos_phi = cos(phi);
  Real sin_vartheta;

  if (pgen.psi != 0.0) {
    Real x = sin_theta * cos_phi;
    Real y = sin_theta * sin_phi;
    Real z = cos_theta;
    Real varx = pgen.cos_psi * x - pgen.sin_psi * z;
    Real vary = y;
    sin_vartheta = sqrt(SQR(varx) + SQR(vary));
  } else {
    sin_vartheta = fabs(sin(theta));
  }

  if (pgen.is_vertical_field) {
    // Determine if we are in the torus
    Real rho;
    Real gm1 = pgen.gamma_adi - 1.0;
    bool in_torus = false;
    Real log_h = LogHAux(pgen, r, sin_vartheta) - pgen.log_h_edge;  // (FM 3.6)
    if (log_h >= 0.0) {
      in_torus = true;
      Real ptot_over_rho = gm1/pgen.gamma_adi * (exp(log_h) - 1.0);
      rho = pow(ptot_over_rho, 1.0/gm1) / pgen.rho_peak;
    }

    // more-or-less vertical geometry but falling to zero on edges
    Real cyl_radius = r * sin_vartheta;
    Real rcyl_in = pgen.r_edge;
    Real rcyl_falloff = pgen.potential_falloff;

    Real aphi_tilt = pow(cyl_radius/rcyl_in, pgen.potential_r_pow);
    if (pgen.potential_falloff != 0) {
      aphi_tilt *= exp(-cyl_radius/rcyl_falloff);
    }

    Real aphi_offset = exp(-rcyl_in/rcyl_falloff);
    if (cyl_radius < rcyl_in) {
      aphi_tilt = 0.0;
    } else {
      aphi_tilt -= aphi_offset;
    }

    if (pgen.potential_rho_pow != 0) {
      if (in_torus) {
        aphi_tilt *= pow(rho/pgen.rho_max, pgen.potential_rho_pow);
      } else {
        aphi_tilt = 0.0;
      }
    }
    if (pgen.psi != 0.0) {
      Real dvarphi_dtheta = -pgen.sin_psi * sin_phi / SQR(sin_vartheta);
      Real dvarphi_dphi = sin_theta / SQR(sin_vartheta)
          * (pgen.cos_psi * sin_theta - pgen.sin_psi * cos_theta * cos_phi);
      atheta = dvarphi_dtheta * aphi_tilt;
      aphi = dvarphi_dphi * aphi_tilt;
    } else {
      atheta = 0.0;
      aphi = aphi_tilt;
    }

  } else {
    if (r >= pgen.r_edge) {
      // Determine if we are in the torus
      Real rho;
      Real gm1 = pgen.gamma_adi-1.0;
      bool in_torus = false;
      Real log_h = LogHAux(pgen, r, sin_vartheta) - pgen.log_h_edge;  // (FM 3.6)
      if (log_h >= 0.0) {
        in_torus = true;
        Real ptot_over_rho = gm1/pgen.gamma_adi * (exp(log_h) - 1.0);
        rho = pow(ptot_over_rho, 1.0/gm1) / pgen.rho_peak;
      }

      Real aphi_tilt = 0.0;
      if (in_torus) {
        Real scaling_param = pow((r/pgen.r_edge)*sin_vartheta, pgen.potential_r_pow);
        if (pgen.potential_falloff != 0) {
          scaling_param *= exp(-r/pgen.potential_falloff);
        }
	aphi_tilt = pow(rho/pgen.rho_max, pgen.potential_rho_pow)*scaling_param;
        aphi_tilt -= pgen.potential_cutoff;
        aphi_tilt = fmax(aphi_tilt, 0.0);
        if (pgen.psi != 0.0) {
          Real dvarphi_dtheta = -pgen.sin_psi * sin_phi / SQR(sin_vartheta);
          Real dvarphi_dphi = sin_theta / SQR(sin_vartheta)
              * (pgen.cos_psi * sin_theta - pgen.sin_psi * cos_theta * cos_phi);
          atheta = dvarphi_dtheta * aphi_tilt;
          aphi = dvarphi_dphi * aphi_tilt;
        } else {
          atheta = 0.0;
          aphi = aphi_tilt;
        }
      }
    }
  }

  *patheta = atheta;
  *paphi = aphi;

  return;
}

KOKKOS_INLINE_FUNCTION
Real A1(struct bbh_pgen pgen, Real x1, Real x2, Real x3) {
  // BL coordinates
  Real r, theta, phi;
  GetBoyerLindquistCoordinates(pgen, x1, x2, x3, &r, &theta, &phi);
  if (r <= 1.0e-14) {
    return 0.0;
  }

  // calculate vector potential in spherical KS
  Real atheta, aphi;
  CalculateVectorPotentialInTiltedTorus(pgen, r, theta, phi, &atheta, &aphi);

  Real big_r = sqrt( SQR(x1) + SQR(x2) + SQR(x3) );
  Real sqrt_term =  2.0*SQR(r) - SQR(big_r) + SQR(pgen.spin);
  Real cyl2 = SQR(x1) + SQR(x2);
  Real safe_cyl2 = fmax(cyl2, 1.0e-12);
  Real isin_term = sqrt((SQR(pgen.spin)+SQR(r))/safe_cyl2);

  return atheta*(x1*x3*isin_term/(r*sqrt_term)) +
         aphi*(-x2/safe_cyl2 +
               pgen.spin*x1*r/((SQR(pgen.spin)+SQR(r))*sqrt_term));
  //return -0.5*x2;
}

//----------------------------------------------------------------------------------------
// Function to compute 2-component of vector potential. See comments for A1.

KOKKOS_INLINE_FUNCTION
Real A2(struct bbh_pgen pgen, Real x1, Real x2, Real x3) {
  // BL coordinates
  //Real r, theta, phi;
  //GetBoyerLindquistCoordinates(pgen, x1, x2, x3, &r, &theta, &phi);
  // BL coordinates
  Real r, theta, phi;
  GetBoyerLindquistCoordinates(pgen, x1, x2, x3, &r, &theta, &phi);
  if (r <= 1.0e-14) {
    return 0.0;
  }

  // calculate vector potential in spherical KS
  Real atheta, aphi;
  CalculateVectorPotentialInTiltedTorus(pgen, r, theta, phi, &atheta, &aphi);

  Real big_r = sqrt( SQR(x1) + SQR(x2) + SQR(x3) );
  Real sqrt_term =  2.0*SQR(r) - SQR(big_r) + SQR(pgen.spin);
  Real cyl2 = SQR(x1) + SQR(x2);
  Real safe_cyl2 = fmax(cyl2, 1.0e-12);
  Real isin_term = sqrt((SQR(pgen.spin)+SQR(r))/safe_cyl2);

  return atheta*(x2*x3*isin_term/(r*sqrt_term)) +
         aphi*(x1/safe_cyl2 +
               pgen.spin*x2*r/((SQR(pgen.spin)+SQR(r))*sqrt_term));
  //return 0.5*x1;
}

//----------------------------------------------------------------------------------------
// Function to compute 3-component of vector potential. See comments for A1.

KOKKOS_INLINE_FUNCTION
Real A3(struct bbh_pgen pgen, Real x1, Real x2, Real x3) {
  // BL coordinates
  Real r, theta, phi;
  GetBoyerLindquistCoordinates(pgen, x1, x2, x3, &r, &theta, &phi);
  if (r <= 1.0e-14) {
    return 0.0;
  }

  // calculate vector potential in spherical KS
  Real atheta, aphi;
  CalculateVectorPotentialInTiltedTorus(pgen, r, theta, phi, &atheta, &aphi);

  Real big_r = sqrt( SQR(x1) + SQR(x2) + SQR(x3) );
  Real sqrt_term =  2.0*SQR(r) - SQR(big_r) + SQR(pgen.spin);
  Real cyl2 = SQR(x1) + SQR(x2);
  Real safe_cyl2 = fmax(cyl2, 1.0e-12);
  Real isin_term = sqrt((SQR(pgen.spin)+SQR(r))/safe_cyl2);

  return atheta*(((1.0+SQR(pgen.spin/r))*SQR(x3)-sqrt_term)*isin_term/(r*sqrt_term)) +
         aphi*(pgen.spin*x3/(r*sqrt_term));


  return 0.0;
}

KOKKOS_INLINE_FUNCTION
static void CalculateVelocityInTiltedTorus(struct bbh_pgen pgen,
                                           Real r, Real theta, Real phi, Real *pu0,
                                           Real *pu1, Real *pu2, Real *pu3) {
  // Calculate corresponding location
  Real sin_theta = sin(theta);
  Real cos_theta = cos(theta);
  Real sin_phi = sin(phi);
  Real cos_phi = cos(phi);
  Real sin_vartheta, cos_vartheta, varphi;
  if (pgen.psi != 0.0) {
    Real x = sin_theta * cos_phi;
    Real y = sin_theta * sin_phi;
    Real z = cos_theta;
    Real varx = pgen.cos_psi * x - pgen.sin_psi * z;
    Real vary = y;
    Real varz = pgen.sin_psi * x + pgen.cos_psi * z;
    sin_vartheta = sqrt(SQR(varx) + SQR(vary));
    cos_vartheta = varz;
    varphi = atan2(vary, varx);
  } else {
    sin_vartheta = fabs(sin_theta);
    cos_vartheta = cos_theta;
    varphi = (sin_theta < 0.0) ? (phi - M_PI) : phi;
  }
  Real sin_varphi = sin(varphi);
  Real cos_varphi = cos(varphi);

  // Calculate untilted velocity
  Real u0_tilt, u3_tilt;
  CalculateVelocityInTorus(pgen, r, sin_vartheta, &u0_tilt, &u3_tilt);
  Real u1_tilt = 0.0;
  Real u2_tilt = 0.0;

  // Account for tilt
  *pu0 = u0_tilt;
  *pu1 = u1_tilt;
  if (pgen.psi != 0.0) {
    Real dtheta_dvartheta =
        (pgen.cos_psi * sin_vartheta
         + pgen.sin_psi * cos_vartheta * cos_varphi) / sin_theta;
    Real dtheta_dvarphi = -pgen.sin_psi * sin_vartheta * sin_varphi / sin_theta;
    Real dphi_dvartheta = pgen.sin_psi * sin_varphi / SQR(sin_theta);
    Real dphi_dvarphi = sin_vartheta / SQR(sin_theta)
        * (pgen.cos_psi * sin_vartheta + pgen.sin_psi * cos_vartheta * cos_varphi);
    *pu2 = dtheta_dvartheta * u2_tilt + dtheta_dvarphi * u3_tilt;
    *pu3 = dphi_dvartheta * u2_tilt + dphi_dvarphi * u3_tilt;
  } else {
    *pu2 = u2_tilt;
    *pu3 = u3_tilt;
  }
  if (sin_theta < 0.0) {
    *pu2 *= -1.0;
    *pu3 *= -1.0;
  }
  return;
}


KOKKOS_INLINE_FUNCTION
static void CalculateVelocityInTorus(struct bbh_pgen pgen,
                                    Real r, Real sin_theta, Real *pu0, Real *pu3) {
  // Compute BL metric components
  Real sin_sq_theta = SQR(sin_theta);
  Real cos_sq_theta = 1.0 - sin_sq_theta;
  Real delta = SQR(r) - 2.0*r;              // \Delta
  Real sigma = SQR(r);         // \Sigma
  Real aa = SQR(SQR(r));  // A
  Real g_00 = -(1.0 - 2.0*r/sigma); // g_tt
  //Real g_03 = 0.0;
  Real g_33 = sigma; // g_pp
  Real g00 = -aa/(delta*sigma); // g^tt
  //Real g03 = 0.0;  // g^tp

  Real u0 = 0.0, u3 = 0.0;
  // Compute non-zero components of 4-velocity
  // Chakrabarti torus
  Real l = CalculateL(pgen, r, sin_theta);
  Real u_0 = CalculateCovariantUT(pgen, r, sin_theta, l); // u_t
  Real omega = -l*g_00/g_33;
  u0 = g00*u_0; // u^t
  u3 = omega * u0; // u^p

  *pu0 = u0;
  *pu3 = u3;
  return;
}

//----------------------------------------------------------------------------------------
// Function for transforming 4-vector from Boyer-Lindquist to desired coordinates
// Inputs:
//   a0_bl,a1_bl,a2_bl,a3_bl: upper 4-vector components in Boyer-Lindquist coordinates
//   x1,x2,x3: Cartesian Kerr-Schild coordinates of point
// Outputs:
//   pa0,pa1,pa2,pa3: pointers to upper 4-vector components in desired coordinates
// Notes:
//   Schwarzschild coordinates match Boyer-Lindquist when a = 0

KOKKOS_INLINE_FUNCTION
static void TransformVector(struct bbh_pgen pgen,
                            Real a0_bl, Real a1_bl, Real a2_bl, Real a3_bl,
                            Real x1, Real x2, Real x3,
                            Real *pa0, Real *pa1, Real *pa2, Real *pa3) {
  Real rad = sqrt( SQR(x1) + SQR(x2) + SQR(x3) );
  Real r = fmax((sqrt( SQR(rad) + sqrt(SQR(SQR(rad))) ) / sqrt(2.0)), 1.0);
  Real delta = SQR(r) - 2.0*r;
  Real cyl2 = SQR(x1) + SQR(x2);
  Real safe_cyl = sqrt(fmax(cyl2, 1.0e-12));
  *pa0 = a0_bl + 2.0*r/delta * a1_bl;
  *pa1 = a1_bl * ( (r*x1)/(SQR(r))) +
         a2_bl * x1*x3/safe_cyl -
         a3_bl * x2;
  *pa2 = a1_bl * ( (r*x2)/(SQR(r))) +
         a2_bl * x2*x3/safe_cyl +
         a3_bl * x1;
  *pa3 = a1_bl * x3/r -
         a2_bl * sqrt(cyl2);
  return;
}


KOKKOS_INLINE_FUNCTION
static void GetSuperposedAndInverse(const Real t,
                            const Real x, const Real y, const Real z,
                            Real gcov[][NDIM], Real gcon[][NDIM], const Real bbh_traj_loc[NTRAJ],
                            const bbh_pgen bbh_){
  //Real gcov[NDIM][NDIM];
  //Real gcon[NDIM][NDIM];
  SuperposedBBH(t, x, y, z, gcov, bbh_traj_loc, bbh_);
  InvertMetric(gcov, gcon);

  return;
}


KOKKOS_INLINE_FUNCTION
static void InvertMetric(Real gcov[][NDIM], Real gcon[][NDIM]){
  Real A2323 = gcov[YY][YY] * gcov[ZZ][ZZ] - gcov[YY][ZZ] * gcov[ZZ][YY] ;
  Real A1323 = gcov[YY][XX] * gcov[ZZ][ZZ] - gcov[YY][ZZ] * gcov[ZZ][XX] ;
  Real A1223 = gcov[YY][XX] * gcov[ZZ][YY] - gcov[YY][YY] * gcov[ZZ][XX] ;
  Real A0323 = gcov[YY][TT] * gcov[ZZ][ZZ] - gcov[YY][ZZ] * gcov[ZZ][TT] ;
  Real A0223 = gcov[YY][TT] * gcov[ZZ][YY] - gcov[YY][YY] * gcov[ZZ][TT] ;
  Real A0123 = gcov[YY][TT] * gcov[ZZ][XX] - gcov[YY][XX] * gcov[ZZ][TT] ;
  Real A2313 = gcov[XX][YY] * gcov[ZZ][ZZ] - gcov[XX][ZZ] * gcov[ZZ][YY] ;
  Real A1313 = gcov[XX][XX] * gcov[ZZ][ZZ] - gcov[XX][ZZ] * gcov[ZZ][XX] ;
  Real A1213 = gcov[XX][XX] * gcov[ZZ][YY] - gcov[XX][YY] * gcov[ZZ][XX] ;
  Real A2312 = gcov[XX][YY] * gcov[YY][ZZ] - gcov[XX][ZZ] * gcov[YY][YY] ;
  Real A1312 = gcov[XX][XX] * gcov[YY][ZZ] - gcov[XX][ZZ] * gcov[YY][XX] ;
  Real A1212 = gcov[XX][XX] * gcov[YY][YY] - gcov[XX][YY] * gcov[YY][XX] ;
  Real A0313 = gcov[XX][TT] * gcov[ZZ][ZZ] - gcov[XX][ZZ] * gcov[ZZ][TT] ;
  Real A0213 = gcov[XX][TT] * gcov[ZZ][YY] - gcov[XX][YY] * gcov[ZZ][TT] ;
  Real A0312 = gcov[XX][TT] * gcov[YY][ZZ] - gcov[XX][ZZ] * gcov[YY][TT] ;
  Real A0212 = gcov[XX][TT] * gcov[YY][YY] - gcov[XX][YY] * gcov[YY][TT] ;
  Real A0113 = gcov[XX][TT] * gcov[ZZ][XX] - gcov[XX][XX] * gcov[ZZ][TT] ;
  Real A0112 = gcov[XX][TT] * gcov[YY][XX] - gcov[XX][XX] * gcov[YY][TT] ;

  Real det = gcov[TT][TT] * ( gcov[XX][XX] * A2323 - gcov[XX][YY] * A1323 + gcov[XX][ZZ] * A1223 )
    - gcov[TT][XX] * ( gcov[XX][TT] * A2323 - gcov[XX][YY] * A0323 + gcov[XX][ZZ] * A0223 )
    + gcov[TT][YY] * ( gcov[XX][TT] * A1323 - gcov[XX][XX] * A0323 + gcov[XX][ZZ] * A0123 )
    - gcov[TT][ZZ] * ( gcov[XX][TT] * A1223 - gcov[XX][XX] * A0223 + gcov[XX][YY] * A0123 ) ;
  det = 1 / det;

   gcon[TT][TT] = det *   ( gcov[XX][XX] * A2323 - gcov[XX][YY] * A1323 + gcov[XX][ZZ] * A1223 );
   gcon[TT][XX] = det * - ( gcov[TT][XX] * A2323 - gcov[TT][YY] * A1323 + gcov[TT][ZZ] * A1223 );
   gcon[TT][YY] = det *   ( gcov[TT][XX] * A2313 - gcov[TT][YY] * A1313 + gcov[TT][ZZ] * A1213 );
   gcon[TT][ZZ] = det * - ( gcov[TT][XX] * A2312 - gcov[TT][YY] * A1312 + gcov[TT][ZZ] * A1212 );
   gcon[XX][TT] = det * - ( gcov[XX][TT] * A2323 - gcov[XX][YY] * A0323 + gcov[XX][ZZ] * A0223 );
   gcon[XX][XX] = det *   ( gcov[TT][TT] * A2323 - gcov[TT][YY] * A0323 + gcov[TT][ZZ] * A0223 );
   gcon[XX][YY] = det * - ( gcov[TT][TT] * A2313 - gcov[TT][YY] * A0313 + gcov[TT][ZZ] * A0213 );
   gcon[XX][ZZ] = det *   ( gcov[TT][TT] * A2312 - gcov[TT][YY] * A0312 + gcov[TT][ZZ] * A0212 );
   gcon[YY][TT] = det *   ( gcov[XX][TT] * A1323 - gcov[XX][XX] * A0323 + gcov[XX][ZZ] * A0123 );
   gcon[YY][XX] = det * - ( gcov[TT][TT] * A1323 - gcov[TT][XX] * A0323 + gcov[TT][ZZ] * A0123 );
   gcon[YY][YY] = det *   ( gcov[TT][TT] * A1313 - gcov[TT][XX] * A0313 + gcov[TT][ZZ] * A0113 );
   gcon[YY][ZZ] = det * - ( gcov[TT][TT] * A1312 - gcov[TT][XX] * A0312 + gcov[TT][ZZ] * A0112 );
   gcon[ZZ][TT] = det * - ( gcov[XX][TT] * A1223 - gcov[XX][XX] * A0223 + gcov[XX][YY] * A0123 );
   gcon[ZZ][XX] = det *   ( gcov[TT][TT] * A1223 - gcov[TT][XX] * A0223 + gcov[TT][YY] * A0123 );
   gcon[ZZ][YY] = det * - ( gcov[TT][TT] * A1213 - gcov[TT][XX] * A0213 + gcov[TT][YY] * A0113 );
   gcon[ZZ][ZZ] = det *   ( gcov[TT][TT] * A1212 - gcov[TT][XX] * A0212 + gcov[TT][YY] * A0112 );

   return;
}

KOKKOS_INLINE_FUNCTION
Real SmoothExcisionBWeight(Real w) {
  return fmin(fmax(w, 0.0), 1.0);
}

KOKKOS_INLINE_FUNCTION
Real StrictSmoothExcisionBWeight(const Real w0, const Real w1) {
  if (!isfinite(w0) || !isfinite(w1)) return 0.0;
  return SmoothExcisionBWeight(fmin(w0, w1));
}

KOKKOS_INLINE_FUNCTION
Real StrictSmoothExcisionBWeight(const Real w0, const Real w1,
                                 const Real w2, const Real w3) {
  if (!isfinite(w0) || !isfinite(w1) || !isfinite(w2) || !isfinite(w3)) {
    return 0.0;
  }
  return SmoothExcisionBWeight(fmin(fmin(w0, w1), fmin(w2, w3)));
}

template <typename WeightView>
KOKKOS_INLINE_FUNCTION Real EdgeWeightX1D(const WeightView &w, const int m,
                                          const int k, const int j, const int i) {
  return StrictSmoothExcisionBWeight(w(m,k,j,i), w(m,k,j,i-1));
}

template <typename WeightView>
KOKKOS_INLINE_FUNCTION Real EdgeWeightX1(const WeightView &w, const int m, const int k,
                                         const int j, const int i) {
  return StrictSmoothExcisionBWeight(w(m,k,j,i), w(m,k,j-1,i),
                                     w(m,k-1,j,i), w(m,k-1,j-1,i));
}

template <typename WeightView>
KOKKOS_INLINE_FUNCTION Real EdgeWeightX2(const WeightView &w, const int m, const int k,
                                         const int j, const int i) {
  return StrictSmoothExcisionBWeight(w(m,k,j,i), w(m,k-1,j,i),
                                     w(m,k,j,i-1), w(m,k-1,j,i-1));
}

template <typename WeightView>
KOKKOS_INLINE_FUNCTION Real EdgeWeightX3(const WeightView &w, const int m, const int k,
                                         const int j, const int i) {
  return StrictSmoothExcisionBWeight(w(m,k,j,i), w(m,k,j-1,i),
                                     w(m,k,j,i-1), w(m,k,j-1,i-1));
}

KOKKOS_INLINE_FUNCTION
Real SmoothExcisionDampingEta(const RegionSize &size, const bool multi_d,
                              const bool three_d, const Real eta0,
                              const Real cfl_cap, const Real dt) {
  Real eta = eta0;
  if (cfl_cap > 0.0 && dt > 0.0) {
    Real dxmin = size.dx1;
    if (multi_d) dxmin = fmin(dxmin, size.dx2);
    if (three_d) dxmin = fmin(dxmin, size.dx3);
    eta = fmin(eta, cfl_cap*SQR(dxmin)/dt);
  }
  return eta;
}

//! \fn void AddSmoothExcisionMagneticDamping(Mesh *pm, DvceEdgeFld4D<Real> &efld)
//! \brief Add a smooth-excision resistive EMF, E_damp = eta W curl(B), at edges.
void AddSmoothExcisionMagneticDamping(Mesh *pm, DvceEdgeFld4D<Real> &efld) {
  MeshBlockPack *pmbp = pm->pmb_pack;
  if (pmbp->pmhd == nullptr || !(bbh.smooth_b_damping_eta > 0.0)) return;

  auto &indcs = pm->mb_indcs;
  int is = indcs.is, ie = indcs.ie;
  int js = indcs.js, je = indcs.je;
  int ks = indcs.ks, ke = indcs.ke;
  int ncells1 = indcs.nx1 + 2*(indcs.ng);
  int nmb1 = pmbp->nmb_thispack - 1;
  auto b0 = pmbp->pmhd->b0;
  auto weight = pmbp->pcoord->excision_weight;
  auto e1 = efld.x1e;
  auto e2 = efld.x2e;
  auto e3 = efld.x3e;
  auto &mbsize = pmbp->pmb->mb_size;
  bool multi_d = pm->multi_d;
  bool three_d = pm->three_d;
  Real eta0 = bbh.smooth_b_damping_eta;
  Real cfl_cap = bbh.smooth_b_damping_cfl;
  Real dt = pm->dt;

  int scr_level = 0;
  size_t scr_size = ScrArray1D<Real>::shmem_size(ncells1) * 3;

  if (pm->one_d) {
    par_for_outer("dynbbh_b_damp1", DevExeSpace(), scr_size, scr_level, 0, nmb1,
    KOKKOS_LAMBDA(TeamMember_t member, const int m) {
      ScrArray1D<Real> j1(member.team_scratch(scr_level), ncells1);
      ScrArray1D<Real> j2(member.team_scratch(scr_level), ncells1);
      ScrArray1D<Real> j3(member.team_scratch(scr_level), ncells1);
      auto size = mbsize.d_view(m);
      Real eta = SmoothExcisionDampingEta(size, multi_d, three_d, eta0, cfl_cap, dt);
	      CurrentDensity(member, m, ks, js, is, ie+1, b0, size, j1, j2, j3);
	      par_for_inner(member, is, ie+1, [&](const int i) {
	        Real w = EdgeWeightX1D(weight, m, ks, js, i);
	        if (w > 0.0 && isfinite(w)) {
	          Real damp = eta*w;
	          e2(m,ks,  js,i) += damp*j2(i);
	          e2(m,ke+1,js,i) += damp*j2(i);
	          e3(m,ks,  js,i) += damp*j3(i);
	          e3(m,ks,je+1,i) += damp*j3(i);
	        }
	      });
	    });
    return;
  }

  if (pm->two_d) {
    par_for_outer("dynbbh_b_damp2", DevExeSpace(), scr_size, scr_level, 0, nmb1, js, je+1,
    KOKKOS_LAMBDA(TeamMember_t member, const int m, const int j) {
      ScrArray1D<Real> j1(member.team_scratch(scr_level), ncells1);
      ScrArray1D<Real> j2(member.team_scratch(scr_level), ncells1);
      ScrArray1D<Real> j3(member.team_scratch(scr_level), ncells1);
      auto size = mbsize.d_view(m);
      Real eta = SmoothExcisionDampingEta(size, multi_d, three_d, eta0, cfl_cap, dt);
	      CurrentDensity(member, m, ks, j, is, ie+1, b0, size, j1, j2, j3);
	      par_for_inner(member, is, ie+1, [&](const int i) {
	        Real w1 = StrictSmoothExcisionBWeight(weight(m,ks,j,i),
	                                             weight(m,ks,j-1,i));
	        if (w1 > 0.0 && isfinite(w1)) {
	          e1(m,ks,  j,i) += eta*w1*j1(i);
	          e1(m,ke+1,j,i) += eta*w1*j1(i);
	        }
	        Real w2 = EdgeWeightX1D(weight, m, ks, j, i);
	        if (w2 > 0.0 && isfinite(w2)) {
	          e2(m,ks,  j,i) += eta*w2*j2(i);
	          e2(m,ke+1,j,i) += eta*w2*j2(i);
	        }
	        Real w3 = EdgeWeightX3(weight, m, ks, j, i);
	        if (w3 > 0.0 && isfinite(w3)) {
	          e3(m,ks,  j,i) += eta*w3*j3(i);
	        }
	      });
	    });
    return;
  }

  par_for_outer("dynbbh_b_damp3", DevExeSpace(), scr_size, scr_level,
                0, nmb1, ks, ke+1, js, je+1,
  KOKKOS_LAMBDA(TeamMember_t member, const int m, const int k, const int j) {
    ScrArray1D<Real> j1(member.team_scratch(scr_level), ncells1);
    ScrArray1D<Real> j2(member.team_scratch(scr_level), ncells1);
    ScrArray1D<Real> j3(member.team_scratch(scr_level), ncells1);
    auto size = mbsize.d_view(m);
	    Real eta = SmoothExcisionDampingEta(size, multi_d, three_d, eta0, cfl_cap, dt);
	    CurrentDensity(member, m, k, j, is, ie+1, b0, size, j1, j2, j3);
	    par_for_inner(member, is, ie+1, [&](const int i) {
	      Real w1 = EdgeWeightX1(weight, m, k, j, i);
	      if (w1 > 0.0 && isfinite(w1)) {
	        e1(m,k,j,i) += eta*w1*j1(i);
	      }
	      Real w2 = EdgeWeightX2(weight, m, k, j, i);
	      if (w2 > 0.0 && isfinite(w2)) {
	        e2(m,k,j,i) += eta*w2*j2(i);
	      }
	      Real w3 = EdgeWeightX3(weight, m, k, j, i);
	      if (w3 > 0.0 && isfinite(w3)) {
	        e3(m,k,j,i) += eta*w3*j3(i);
	      }
	    });
	  });
	}

void AddDynBBHUserSources(Mesh *pm, const Real bdt) {
  if (bbh.cooling_source == CoolingSource::ism) {
    AddValenciaGRCooling(pm, bdt);
  } else if (bbh.cooling_source == CoolingSource::thin_disk) {
    AddThinDiskCooling(pm, bdt);
  }
}

void AddThinDiskCooling(Mesh *pm, const Real bdt) {
  MeshBlockPack *pmbp = pm->pmb_pack;
  if (bbh.cooling_source != CoolingSource::thin_disk ||
      pmbp->pmhd == nullptr || pmbp->padm == nullptr) {
    return;
  }

  auto &indcs = pm->mb_indcs;
  int is = indcs.is, ie = indcs.ie;
  int js = indcs.js, je = indcs.je;
  int ks = indcs.ks, ke = indcs.ke;
  int nmb = pmbp->nmb_thispack;

  auto &adm = pmbp->padm->adm;
  auto &w0 = pmbp->pmhd->w0;
  auto &u0 = pmbp->pmhd->u0;
  auto &size = pmbp->pmb->mb_size;
  auto eos = pmbp->pmhd->peos->eos_data;
  Real gamma_adi = eos.gamma;
  Real gm1 = gamma_adi - 1.0;
  Real rho_floor = eos.dfloor;
  Real p_floor = eos.pfloor;
  Real h_over_r = bbh.thin_cooling_h_over_r;
  Real tcool_orbits = bbh.thin_cooling_timescale_orbits;
  Real cfl_limit = bbh.thin_cooling_cfl;
  Real r_inner = bbh.thin_cooling_r_inner;
  Real r_outer = bbh.thin_cooling_r_outer;
  Real two_pi = 2.0*M_PI;
  auto pgen = bbh;

  constexpr Real tiny = 1.0e-30;

  par_for("dynbbh_thin_disk_cooling", DevExeSpace(),
          0, nmb-1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(int m, int k, int j, int i) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real x1v = CellCenterX(i-is, indcs.nx1, x1min, x1max);

    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real x2v = CellCenterX(j-js, indcs.nx2, x2min, x2max);

    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x3v = CellCenterX(k-ks, indcs.nx3, x3min, x3max);

    Real r, theta, phi;
    GetBoyerLindquistCoordinates(pgen, x1v, x2v, x3v, &r, &theta, &phi);
    if (!isfinite(r)) return;
    if (!(r >= r_inner && r <= r_outer)) return;

    Real rho = w0(m,IDN,k,j,i);
    if (!(rho > rho_floor) || !isfinite(rho)) return;

    Real pres = w0(m,IPR,k,j,i);
    Real e_int = pres / gm1;
    Real e_floor = p_floor / gm1;
    if (!(e_int > e_floor) || !isfinite(e_int)) return;

    Real vk2 = 1.0 / fmax(r, 1.0);
    Real p_target = rho*SQR(h_over_r)*vk2 / gamma_adi;
    Real e_target = fmax(p_target/gm1, e_floor);
    if (e_int <= e_target) return;

    Real tcool = tcool_orbits*two_pi*pow(fmax(r, 1.0), 1.5);
    Real de = (e_int - e_target) * (1.0 - exp(-bdt/tcool));
    if (cfl_limit > 0.0) {
      de = fmin(de, cfl_limit*(e_int - e_floor));
    }
    de = fmin(de, e_int - e_floor);
    if (de <= 0.0) return;

    Real gxx = adm.g_dd(m,0,0,k,j,i);
    Real gxy = adm.g_dd(m,0,1,k,j,i);
    Real gxz = adm.g_dd(m,0,2,k,j,i);
    Real gyy = adm.g_dd(m,1,1,k,j,i);
    Real gyz = adm.g_dd(m,1,2,k,j,i);
    Real gzz = adm.g_dd(m,2,2,k,j,i);

    Real detg = adm::SpatialDet(gxx, gxy, gxz, gyy, gyz, gzz);
    if (!(detg > tiny) || !isfinite(detg)) return;
    detg = fmax(detg, tiny);
    Real sqrt_gamma = sqrt(detg);
    Real alpha = adm.alpha(m,k,j,i);
    if (!(alpha > tiny) || !isfinite(alpha)) return;
    alpha = fmax(alpha, tiny);

    Real u1p = w0(m,IVX,k,j,i);
    Real u2p = w0(m,IVY,k,j,i);
    Real u3p = w0(m,IVZ,k,j,i);
    if (!isfinite(u1p) || !isfinite(u2p) || !isfinite(u3p)) return;
    Real u_sq = gxx*u1p*u1p + 2.0*gxy*u1p*u2p + 2.0*gxz*u1p*u3p
              + gyy*u2p*u2p + 2.0*gyz*u2p*u3p + gzz*u3p*u3p;
    if (!isfinite(u_sq)) return;
    Real W = sqrt(fmax(1.0 + u_sq, 1.0));

    Real u1_cov = gxx*u1p + gxy*u2p + gxz*u3p;
    Real u2_cov = gxy*u1p + gyy*u2p + gyz*u3p;
    Real u3_cov = gxz*u1p + gyz*u2p + gzz*u3p;

    Real q_dt = de * (W / alpha);
    if (!isfinite(q_dt)) return;
    u0(m,IEN,k,j,i) -= sqrt_gamma * alpha * W * q_dt;
    u0(m,IM1,k,j,i) -= sqrt_gamma * alpha * u1_cov * q_dt;
    u0(m,IM2,k,j,i) -= sqrt_gamma * alpha * u2_cov * q_dt;
    u0(m,IM3,k,j,i) -= sqrt_gamma * alpha * u3_cov * q_dt;
  });
}

void AddValenciaGRCooling(Mesh *pm, const Real bdt) {
  MeshBlockPack *pmbp = pm->pmb_pack;
  if (pmbp->pmhd == nullptr || pmbp->padm == nullptr) {
    return;
  }

  // ---- Units ----
  Real temp_unit     = pmbp->punit->temperature_cgs();
  Real density_unit  = pmbp->punit->density_cgs();
  Real time_unit     = pmbp->punit->time_cgs();
  Real pressure_unit = pmbp->punit->pressure_cgs();

  Real mu  = pmbp->punit->mu();
  Real amu = pmbp->punit->atomic_mass_unit_cgs;

  Real n_unit = density_unit / (mu * amu);
  Real cooling_unit = pressure_unit / time_unit / (n_unit * n_unit);

  // ---- Indices ----
  auto &indcs = pm->mb_indcs;
  int is = indcs.is, ie = indcs.ie;
  int js = indcs.js, je = indcs.je;
  int ks = indcs.ks, ke = indcs.ke;
  int nmb = pmbp->nmb_thispack;

  // ---- Accessors ----
  auto &adm = pmbp->padm->adm;
  auto &w0  = pmbp->pmhd->w0;  // primitives
  auto &u0  = pmbp->pmhd->u0;  // conserved

  // ---- EOS ----
  auto &eos_data = pmbp->pmhd->peos->eos_data;
  Real gamma_adi = eos_data.gamma;
  Real gm1       = gamma_adi - 1.0;
  Real rho_floor = eos_data.dfloor;
  Real p_floor   = eos_data.pfloor;

  // ---- Stability Control ----
  // Use the simulation's global CFL number for consistency
  // instead of a hardcoded "by-hand" value.
  Real cfl_limit = pm->cfl_no;

  constexpr int  max_sub  = 64;
  constexpr Real tiny     = 1.0e-30;

  par_for("Valencia_IsotropicCooling", DevExeSpace(),
          0, nmb-1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(int m, int k, int j, int i) {

    // --- metric gamma_ij and sqrt(gamma) ---
    Real gxx = adm.g_dd(m,0,0,k,j,i);
    Real gxy = adm.g_dd(m,0,1,k,j,i);
    Real gxz = adm.g_dd(m,0,2,k,j,i);
    Real gyy = adm.g_dd(m,1,1,k,j,i);
    Real gyz = adm.g_dd(m,1,2,k,j,i);
    Real gzz = adm.g_dd(m,2,2,k,j,i);

    Real detg = adm::SpatialDet(gxx, gxy, gxz, gyy, gyz, gzz);
    if (!(detg > tiny) || !isfinite(detg)) return;
    detg = fmax(detg, tiny);
    Real sqrt_gamma = sqrt(detg);

    Real alpha = adm.alpha(m,k,j,i);
    if (!(alpha > tiny) || !isfinite(alpha)) return;

    // --- primitive state ---
    Real rho  = w0(m,IDN,k,j,i);
    if (!(rho > rho_floor) || !isfinite(rho)) return;

    Real pres = w0(m,IPR,k,j,i);
    if (!isfinite(pres)) return;

    // primitive stores u^{i'}
    Real u1p = w0(m,IVX,k,j,i);
    Real u2p = w0(m,IVY,k,j,i);
    Real u3p = w0(m,IVZ,k,j,i);
    if (!isfinite(u1p) || !isfinite(u2p) || !isfinite(u3p)) return;

    // W = sqrt(1 + gamma_ij u^{i'} u^{j'})
    Real u_sq = gxx*u1p*u1p + 2.0*gxy*u1p*u2p + 2.0*gxz*u1p*u3p
              + gyy*u2p*u2p + 2.0*gyz*u2p*u3p + gzz*u3p*u3p;
    if (!isfinite(u_sq)) return;
    Real W = sqrt(fmax(1.0 + u_sq, 1.0));

    // covariant spatial components u_i
    Real u1_cov = gxx*u1p + gxy*u2p + gxz*u3p;
    Real u2_cov = gxy*u1p + gyy*u2p + gyz*u3p;
    Real u3_cov = gxz*u1p + gyz*u2p + gzz*u3p;

    // comoving internal energy density
    Real e_int = pres / gm1;
    Real e_floor = p_floor / gm1;
    if (!(e_int > e_floor) || !isfinite(e_int)) return;

    // Subcycling in coordinate time
    Real dt_rem = bdt;

    // Accumulated conserved decrements
    Real dTau_total = 0.0;
    Real dS1_total  = 0.0;
    Real dS2_total  = 0.0;
    Real dS3_total  = 0.0;

    for (int n = 0; n < max_sub && dt_rem > 0.0; ++n) {
      // Temperature proxy
      Real T_cgs = ( (e_int * gm1) / rho ) * temp_unit;
      if (!isfinite(T_cgs)) break;

      // Determine Cooling Rate
      Real Lambda_cgs = 0.0;
      if (T_cgs >= eos_data.tfloor * temp_unit) {
         Lambda_cgs = ISMCoolFn(T_cgs);
      }

      // q = n^2 Lambda
      Real q = (rho * rho) * (Lambda_cgs / cooling_unit); // code units

      if (!(q > 0.0) || !isfinite(q)) break;

      // Coordinate-time cooling rate for e_int: de_int/dt = -(alpha/W) q
      Real rate_e_dt = (alpha / W) * q;
      if (!isfinite(rate_e_dt)) break;

      // === DYNAMIC CLAMP (Based on CFL) ===
      // Max allowed rate is one that removes 'cfl_limit' fraction of e_int
      // over the full timestep 'bdt'.
      // This ensures operator splitting doesn't shock the hydro solver.
      Real rate_max = (cfl_limit * e_int) / (bdt + tiny);

      rate_e_dt = fmin(rate_e_dt, rate_max);
      // ====================================

      // Choose substep using the same CFL limit
      Real dt_sub = cfl_limit * e_int / (rate_e_dt + tiny);
      dt_sub = fmin(dt_sub, dt_rem);
      dt_sub = fmax(dt_sub, tiny * bdt);

      // Proposed decrement
      Real de = rate_e_dt * dt_sub;
      if (!isfinite(de)) break;

      // Enforce floor on e_int
      Real de_applied = de;
      if (e_int - de_applied < e_floor) {
        de_applied = e_int - e_floor;
        e_int = e_floor;
      } else {
        e_int -= de_applied;
      }

      if (de_applied <= 0.0) break;

      // Convert applied decrement back to q*dt (source term magnitude)
      Real q_dt = de_applied * (W / alpha);
      if (!isfinite(q_dt)) break;

      // Valencia isotropic cooling sources:
      Real dTau = sqrt_gamma * alpha * W * q_dt;
      Real dS1  = sqrt_gamma * alpha * u1_cov * q_dt;
      Real dS2  = sqrt_gamma * alpha * u2_cov * q_dt;
      Real dS3  = sqrt_gamma * alpha * u3_cov * q_dt;

      dTau_total += dTau;
      dS1_total  += dS1;
      dS2_total  += dS2;
      dS3_total  += dS3;

      dt_rem -= dt_sub;
    }

    // Apply to conserved variables
    u0(m,IEN,k,j,i) -= dTau_total;
    u0(m,IM1,k,j,i) -= dS1_total;
    u0(m,IM2,k,j,i) -= dS2_total;
    u0(m,IM3,k,j,i) -= dS3_total;
  });
}


}//namespace
